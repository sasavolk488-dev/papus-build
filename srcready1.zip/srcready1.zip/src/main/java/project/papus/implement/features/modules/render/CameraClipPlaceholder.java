package project.papus.implement.features.modules.render;

public class CameraClipPlaceholder {
}
