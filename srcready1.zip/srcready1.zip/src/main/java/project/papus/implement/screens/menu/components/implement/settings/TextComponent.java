package project.papus.implement.screens.menu.components.implement.settings;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;
import project.papus.api.feature.module.setting.implement.TextSetting;
import project.papus.api.system.font.FontRenderer;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.render.ScissorManager;
import project.papus.core.Main;

public class TextComponent extends AbstractSettingComponent {
   public static boolean typing;
   private final TextSetting setting;
   private float rectX;
   private float rectY;
   private float rectWidth;
   private float rectHeight;
   private boolean dragging;
   private int cursorPosition = 0;
   private int selectionStart = -1;
   private int selectionEnd = -1;
   private long lastClickTime = 0L;
   private float xOffset = 0.0F;
   private String text = "";

   public TextComponent(TextSetting var1) {
      super(var1);
      this.setting = var1;
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      FontRenderer var6 = Fonts.getSize(12);
      this.height = 18.0F;
      this.rectX = this.x + this.width - 61.5F;
      this.rectY = this.y + 6.0F;
      this.rectWidth = 53.0F;
      this.rectHeight = 12.0F;
      rectangle.render(
         ShapeProperties.create(var5, this.rectX, this.rectY, this.rectWidth, this.rectHeight)
            .round(2.0F)
            .thickness(2.0F)
            .outlineColor(ColorUtil.getOutlineColor())
            .color(ColorUtil.getClientColor(1.0F))
            .build()
      );
      Fonts.getSize(14, Fonts.Type.BOLD).drawString(var1.getMatrices(), this.setting.getName(), this.x + 9.0F, this.y + 6.0F, -2828575);
      this.updateXOffset(var6, this.cursorPosition);
      ScissorManager var7 = Main.getInstance().getScissorManager();
      var7.push(var5.peek().getPositionMatrix(), this.rectX + 1.0F, window.getScaledHeight() / 2.0F - 96.0F, this.rectWidth - 3.0F, 220.0F);
      if (typing && this.selectionStart != -1 && this.selectionEnd != -1 && this.selectionStart != this.selectionEnd) {
         int var8 = Math.max(0, Math.min(this.getStartOfSelection(), this.text.length()));
         int var9 = Math.max(0, Math.min(this.getEndOfSelection(), this.text.length()));
         if (var8 < var9) {
            float var10 = this.rectX + 3.0F - this.xOffset + var6.getStringWidth(this.text.substring(0, var8));
            float var11 = this.rectX + 3.0F - this.xOffset + var6.getStringWidth(this.text.substring(0, var9));
            float var12 = var11 - var10;
            rectangle.render(ShapeProperties.create(var5, var10, this.rectY + this.rectHeight / 2.0F - 4.0F, var12, 8.0).color(-11172376).build());
         }
      }

      var6.drawString(var1.getMatrices(), this.text, this.rectX + 3.0F - this.xOffset, this.rectY + this.rectHeight / 2.0F - 1.0F, typing ? -1 : -7894892);
      if (!typing && this.text.isEmpty()) {
         var6.drawString(var1.getMatrices(), this.text = this.setting.getText(), this.rectX + 3.0F, this.rectY + this.rectHeight / 2.0F - 1.0F, -7894892);
      }

      var7.pop();
      long var13 = System.currentTimeMillis();
      boolean var14 = typing && var13 % 1000L < 500L;
      if (var14 && (this.selectionStart == -1 || this.selectionStart == this.selectionEnd)) {
         float var15 = var6.getStringWidth(this.text.substring(0, this.cursorPosition));
         rectangle.render(
            ShapeProperties.create(var5, this.rectX + 3.0F - this.xOffset + var15, this.rectY + this.rectHeight / 2.0F - 3.5F, 0.5, 7.0).color(-1).build()
         );
      }

      if (this.dragging) {
         this.cursorPosition = this.getCursorIndexAt(var2);
         if (this.selectionStart == -1) {
            this.selectionStart = this.cursorPosition + 1;
         }

         this.selectionEnd = this.cursorPosition;
      }
   }

   @Override
   public boolean mouseDragged(double var1, double var3, int var5, double var6, double var8) {
      this.dragging = true;
      return super.mouseDragged(var1, var3, var5, var6, var8);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (MathUtil.isHovered(var1, var3, this.rectX, this.rectY, this.rectWidth, this.rectHeight) && var5 == 0) {
         long var6 = System.currentTimeMillis();
         if (var6 - this.lastClickTime < 250L) {
            this.selectionStart = 0;
            this.selectionEnd = this.text.length();
         } else {
            typing = true;
            this.dragging = true;
            this.lastClickTime = var6;
            this.cursorPosition = this.getCursorIndexAt(var1);
            this.selectionStart = this.cursorPosition;
            this.selectionEnd = this.cursorPosition;
         }
      } else {
         typing = false;
         this.clearSelection();
      }

      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.dragging = false;
      return super.mouseReleased(var1, var3, var5);
   }

   @Override
   public boolean charTyped(char var1, int var2) {
      if (typing && this.text.length() < this.setting.getMax()) {
         this.deleteSelectedText();
         this.text = this.text.substring(0, this.cursorPosition) + var1 + this.text.substring(this.cursorPosition);
         this.cursorPosition++;
         this.clearSelection();
      }

      return super.charTyped(var1, var2);
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      if (typing) {
         if (Screen.hasControlDown()) {
            switch (var1) {
               case 65:
                  this.selectAllText();
                  break;
               case 67:
                  this.copyToClipboard();
                  break;
               case 86:
                  this.pasteFromClipboard();
            }
         } else {
            switch (var1) {
               case 257:
               case 259:
                  this.handleBackspaceOrEnter(var1);
               case 258:
               case 260:
               case 261:
               default:
                  break;
               case 262:
               case 263:
                  this.moveCursor(var1);
            }
         }
      }

      return super.keyPressed(var1, var2, var3);
   }

   private void pasteFromClipboard() {
      String var1 = GLFW.glfwGetClipboardString(window.getHandle());
      if (var1 != null) {
         this.replaceText(this.cursorPosition, this.cursorPosition, var1);
      }
   }

   private void copyToClipboard() {
      if (this.hasSelection()) {
         GLFW.glfwSetClipboardString(window.getHandle(), this.getSelectedText());
      }
   }

   private void selectAllText() {
      this.selectionStart = 0;
      this.selectionEnd = this.text.length();
   }

   private void handleBackspaceOrEnter(int var1) {
      if (var1 == 259) {
         if (this.hasSelection()) {
            this.replaceText(this.getStartOfSelection(), this.getEndOfSelection(), "");
         } else if (this.cursorPosition > 0) {
            this.replaceText(this.cursorPosition - 1, this.cursorPosition, "");
         }
      } else if (var1 == 257 && this.text.length() >= this.setting.getMin() && this.text.length() <= this.setting.getMax()) {
         this.setting.setText(this.text);
         typing = false;
      }
   }

   private void moveCursor(int var1) {
      if (var1 == 263 && this.cursorPosition > 0) {
         this.cursorPosition--;
      } else if (var1 == 262 && this.cursorPosition < this.text.length()) {
         this.cursorPosition++;
      }

      this.updateSelectionAfterMove();
   }

   private void updateSelectionAfterMove() {
      if (Screen.hasShiftDown()) {
         if (this.selectionStart == -1) {
            this.selectionStart = this.cursorPosition;
         }

         this.selectionEnd = this.cursorPosition;
      } else {
         this.clearSelection();
      }
   }

   private void replaceText(int var1, int var2, String var3) {
      if (var1 < 0) {
         var1 = 0;
      }

      if (var2 > this.text.length()) {
         var2 = this.text.length();
      }

      if (var1 > var2) {
         var1 = var2;
      }

      this.text = this.text.substring(0, var1) + var3 + this.text.substring(var2);
      this.cursorPosition = var1 + var3.length();
      this.clearSelection();
   }

   private boolean hasSelection() {
      return this.selectionStart != -1 && this.selectionEnd != -1 && this.selectionStart != this.selectionEnd;
   }

   private String getSelectedText() {
      return this.text.substring(this.getStartOfSelection(), this.getEndOfSelection());
   }

   private int getStartOfSelection() {
      return Math.min(this.selectionStart, this.selectionEnd);
   }

   private int getEndOfSelection() {
      return Math.max(this.selectionStart, this.selectionEnd);
   }

   private void clearSelection() {
      this.selectionStart = -1;
      this.selectionEnd = -1;
   }

   private int getCursorIndexAt(double var1) {
      FontRenderer var3 = Fonts.getSize(12, Fonts.Type.BOLD);
      float var4 = (float)var1 - this.rectX - 3.0F + this.xOffset;

      int var5;
      for (var5 = 0; var5 < this.text.length(); var5++) {
         float var6 = var3.getStringWidth(this.text.substring(0, var5 + 1));
         if (var6 > var4) {
            break;
         }
      }

      return var5;
   }

   private void updateXOffset(FontRenderer var1, int var2) {
      float var3 = var1.getStringWidth(this.text.substring(0, var2));
      if (var3 < this.xOffset) {
         this.xOffset = var3;
      } else if (var3 - this.xOffset > this.rectWidth - 7.0F) {
         this.xOffset = var3 - (this.rectWidth - 7.0F);
      }
   }

   private void deleteSelectedText() {
      if (this.hasSelection()) {
         this.replaceText(this.getStartOfSelection(), this.getEndOfSelection(), "");
      }
   }
}
