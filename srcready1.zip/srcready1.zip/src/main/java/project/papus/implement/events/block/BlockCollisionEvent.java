package project.papus.implement.events.block;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import project.papus.api.event.events.Event;

public record BlockCollisionEvent(BlockPos blockPos, BlockState state) implements Event {
}
