package project.papus.implement.events.container;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.screen.slot.Slot;
import project.papus.api.event.events.Event;

public class HandledScreenEvent implements Event {
   private DrawContext drawContext;
   private Slot focusedSlot;
   private int backgroundWidth;
   private int backgroundHeight;

   public DrawContext getDrawContext() {
      return this.drawContext;
   }

   public Slot getFocusedSlot() {
      return this.focusedSlot;
   }

   public int getBackgroundWidth() {
      return this.backgroundWidth;
   }

   public int getBackgroundHeight() {
      return this.backgroundHeight;
   }

   public HandledScreenEvent(DrawContext var1, Slot var2, int var3, int var4) {
      this.drawContext = var1;
      this.focusedSlot = var2;
      this.backgroundWidth = var3;
      this.backgroundHeight = var4;
   }
}
