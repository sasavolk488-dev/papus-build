package project.papus.implement.screens.menu.components.implement.other;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.system.animation.Animation;
import project.papus.api.system.animation.Direction;
import project.papus.api.system.animation.implement.DecelerateAnimation;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.render.ScissorManager;
import project.papus.core.Main;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class CheckComponent extends AbstractComponent {
   private boolean state;
   private Runnable action;
   private final Animation alphaAnimation = new DecelerateAnimation().setMs(300).setValue(255.0);
   private final Animation stencilAnimation = new DecelerateAnimation().setMs(200).setValue(8.0);

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      this.alphaAnimation.setDirection(this.state ? Direction.FORWARDS : Direction.BACKWARDS);
      this.stencilAnimation.setDirection(this.state ? Direction.FORWARDS : Direction.BACKWARDS);
      if (this.state) {
         ColorUtil.getFriendColor();
      } else {
         ColorUtil.getClientColor(1.0F);
      }

      int var6 = this.state ? ColorUtil.getFriendColor() : ColorUtil.getOutlineColor();
      int var7 = this.alphaAnimation.getOutput().intValue();
      rectangle.renderOutline(
         ShapeProperties.create(var5, this.x, this.y, 9.0, 9.0)
            .round(2.0F)
            .softness(0.0F)
            .outlineColor(ColorUtil.getColor(255, 255, 255, 25))
            .color(ColorUtil.getColor(0, 0, 0, 0))
            .build(),
         1.5F
      );
      ScissorManager var8 = Main.getInstance().getScissorManager();
      var8.push(var5.peek().getPositionMatrix(), this.x, window.getScaledHeight() / 2.0F - 96.0F, this.stencilAnimation.getOutput().intValue(), 220.0F);
      rectangle.render(
         ShapeProperties.create(var5, this.x + 3.6F - 1.0F + 0.4F, this.y + 3.0F, 3.0, 3.0)
            .round(1.5F)
            .thickness(0.0F)
            .softness(0.5F)
            .outlineColor(ColorUtil.getColor(100, 100, 100, 255))
            .color(MathUtil.applyOpacity(ColorUtil.getColor(62, 62, 62, 255), var7))
            .build()
      );
      var8.pop();
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (MathUtil.isHovered(var1, var3, this.x, this.y, 8.0, 8.0) && var5 == 0) {
         this.action.run();
      }

      return super.mouseClicked(var1, var3, var5);
   }

   public CheckComponent setState(boolean var1) {
      this.state = var1;
      return this;
   }

   public CheckComponent setAction(Runnable var1) {
      this.action = var1;
      return this;
   }
}
