package project.papus.implement.events.render;

import project.papus.api.event.events.callables.EventCancellable;

public class FogEvent extends EventCancellable {
   private float distance;
   private int color;

   public float getDistance() {
      return this.distance;
   }

   public int getColor() {
      return this.color;
   }

   public void setDistance(float var1) {
      this.distance = var1;
   }

   public void setColor(int var1) {
      this.color = var1;
   }
}
