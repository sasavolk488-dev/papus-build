package project.papus.implement.events.player;

import net.minecraft.entity.player.PlayerEntity;
import project.papus.api.event.events.callables.EventCancellable;

public class KeepSprintEvent extends EventCancellable {
   private PlayerEntity player;

   public PlayerEntity getPlayer() {
      return this.player;
   }

   public KeepSprintEvent(PlayerEntity var1) {
      this.player = var1;
   }
}
