package project.papus.implement.screens.menu.components.implement.settings;

import net.minecraft.client.gui.DrawContext;
import project.papus.api.feature.module.setting.implement.BooleanSetting;
import project.papus.api.system.font.Fonts;
import project.papus.implement.screens.menu.components.implement.other.SwitchComponent;

public class CheckboxComponent extends AbstractSettingComponent {
   private static final float RIGHT_MARGIN = 14.0F;
   private static final float SWITCH_WIDTH = 18.0F;
   private final SwitchComponent switchComponent = new SwitchComponent();
   private final BooleanSetting setting;

   public CheckboxComponent(BooleanSetting var1) {
      super(var1);
      this.setting = var1;
      this.switchComponent.setSwitchSize(18.0F, 10.0F);
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      this.height = 18.0F;
      Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(var1.getMatrices(), this.setting.getName(), this.x + 11.0F, this.y + 8.0F, -2828575);
      float var5 = this.x + this.width - 14.0F - 18.0F;
      ((SwitchComponent)this.switchComponent.position(var5, this.y + 4.0F))
         .setAction(() -> this.setting.setValue(!this.setting.isValue()))
         .setState(this.setting.isValue())
         .render(var1, var2, var3, var4);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      this.switchComponent.mouseClicked(var1, var3, var5);
      return super.mouseClicked(var1, var3, var5);
   }
}
