package project.papus.implement.events.block;

import net.minecraft.util.math.BlockPos;
import project.papus.api.event.events.Event;

public record BreakBlockEvent(BlockPos blockPos) implements Event {
}
