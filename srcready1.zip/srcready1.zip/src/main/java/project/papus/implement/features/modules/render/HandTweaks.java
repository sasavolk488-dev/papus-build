package project.papus.implement.features.modules.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.implement.events.item.HandAnimationEvent;
import project.papus.implement.events.item.HandOffsetEvent;
import project.papus.implement.events.item.SwingDurationEvent;

public class HandTweaks extends Module {
   private final SelectSetting animationModeSetting = new SelectSetting("\u0410\u043d\u0438\u043c\u0430\u0446\u0438\u0438 \u0420\u0443\u043a\u0438", "")
      .value("\u041e\u0431\u044b\u0447\u043d\u044b\u0439", "\u041f\u0443\u043b\u044c\u0441", "\u0420\u044b\u0432\u043e\u043a")
      .selected("\u041e\u0431\u044b\u0447\u043d\u044b\u0439");
   private final ValueSetting xOffsetSetting = new ValueSetting("X", "").setValue(0.0F).range(-1.0F, 1.5F);
   private final ValueSetting yOffsetSetting = new ValueSetting("Y", "").setValue(0.0F).range(-1.0F, 1.0F);
   private final ValueSetting zOffsetSetting = new ValueSetting("Z", "").setValue(0.0F).range(-2.5F, 2.5F);
   private final ValueSetting handScaleSetting = new ValueSetting("\u0420\u0430\u0437\u043c\u0435\u0440 \u0440\u0443\u043a", "")
      .setValue(1.0F)
      .range(0.5F, 2.0F);
   private final ValueSetting speedSetting = new ValueSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", "").setValue(1.0F).range(0.5F, 2.0F);
   private final ValueSetting animScaleSetting = new ValueSetting("\u0420\u0430\u0437\u043c\u0435\u0440 \u0430\u043d\u0438\u043c.", "")
      .setValue(1.0F)
      .range(0.1F, 1.5F);

   public HandTweaks() {
      super("Hand Tweaks", "Hand Tweaks", ModuleCategory.RENDER);
      this.setup(
         this.animationModeSetting,
         this.xOffsetSetting,
         this.yOffsetSetting,
         this.zOffsetSetting,
         this.handScaleSetting,
         this.speedSetting,
         this.animScaleSetting
      );
   }

   @EventHandler
   public void onSwingDuration(SwingDurationEvent var1) {
      var1.setAnimation(this.speedSetting.getValue());
      var1.cancel();
   }

   @EventHandler
   public void onHandAnimation(HandAnimationEvent var1) {
      if (var1.getHand().equals(Hand.MAIN_HAND)) {
         MatrixStack var2 = var1.getMatrices();
         float var3 = var1.getSwingProgress();
         int var4 = mc.player.getMainArm().equals(Arm.RIGHT) ? 1 : -1;
         float var5 = MathHelper.sin(var3 * var3 * (float) Math.PI);
         float var6 = MathHelper.sin(MathHelper.sqrt(var3) * (float) Math.PI);
         String var7 = this.animationModeSetting.getSelected();
         float var8 = this.animScaleSetting.getValue();
         var5 *= var8;
         var6 *= var8;
         switch (var7) {
            case "\u041f\u0443\u043b\u044c\u0441":
               var2.translate(var4 * 0.56F, -0.42F, -0.72F);
               var2.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var4 * (45.0F + var5 * -20.0F)));
               var2.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var4 * var6 * -20.0F));
               var2.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var6 * -80.0F));
               var2.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var4 * -45.0F));
               var2.translate(0.0, -0.1, 0.0);
               var1.cancel();
               break;
            case "\u0420\u044b\u0432\u043e\u043a":
               var2.translate(0.56F * var4, -0.32F, -0.72F);
               var2.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(70 * var4));
               var2.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-20 * var4));
               var2.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var6 * var5 * -5.0F * var8));
               var2.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var6 * var5 * -120.0F * var8));
               var2.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-70.0F));
               var1.cancel();
               break;
            default:
               return;
         }
      }
   }

   @EventHandler
   public void onHandOffset(HandOffsetEvent var1) {
      Hand var2 = var1.getHand();
      MatrixStack var3 = var1.getMatrices();
      float var4 = this.xOffsetSetting.getValue();
      float var5 = this.yOffsetSetting.getValue();
      float var6 = this.zOffsetSetting.getValue();
      float var7 = var2.equals(Hand.MAIN_HAND) ? var4 : -var4;
      var3.translate(var7, var5, var6);
      float var8 = this.handScaleSetting.getValue();
      var3.scale(var8, var8, var8);
   }
}
