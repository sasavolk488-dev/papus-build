package project.papus.implement.screens.menu.components.implement.other;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.common.util.entity.PlayerInventoryComponent;
import project.papus.implement.screens.menu.MenuScreen;
import project.papus.implement.screens.menu.components.AbstractComponent;
import project.papus.implement.screens.menu.components.implement.category.CategoryComponent;
import project.papus.implement.screens.menu.components.implement.settings.TextComponent;

public class CategoryContainerComponent extends AbstractComponent {
   private final List<CategoryComponent> categoryComponents = new ArrayList<>();

   public void initializeCategoryComponents() {
      this.categoryComponents.clear();

      for (ModuleCategory var4 : ModuleCategory.values()) {
         this.categoryComponents.add(new CategoryComponent(var4));
      }
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      float var5 = 0.0F;

      for (CategoryComponent var7 : this.categoryComponents) {
         var7.x = this.x + 7.4F;
         var7.y = this.y + 43.0F + 16.0F + var5 - 15.0F;
         var7.width = 25.0F;
         var7.height = 17.0F;
         var7.render(var1, var2, var3, var4);
         var5 += var7.height + 10.0F;
      }
   }

   @Override
   public void tick() {
      if (!TextComponent.typing && !MenuScreen.getInstance().getBackgroundComponent().isTyping()) {
         PlayerInventoryComponent.updateMoveKeys();
      } else {
         PlayerInventoryComponent.unPressMoveKeys();
      }

      this.categoryComponents.forEach(AbstractComponent::tick);
      super.tick();
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      this.categoryComponents.forEach(var5x -> var5x.mouseClicked(var1, var3, var5));
      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.categoryComponents.forEach(var5x -> var5x.mouseReleased(var1, var3, var5));
      return super.mouseReleased(var1, var3, var5);
   }

   @Override
   public boolean mouseDragged(double var1, double var3, int var5, double var6, double var8) {
      this.categoryComponents.forEach(var9 -> var9.mouseDragged(var1, var3, var5, var6, var8));
      return super.mouseDragged(var1, var3, var5, var6, var8);
   }

   @Override
   public boolean mouseScrolled(double var1, double var3, double var5) {
      this.categoryComponents.forEach(var6 -> var6.mouseScrolled(var1, var3, var5));
      return super.mouseScrolled(var1, var3, var5);
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      for (CategoryComponent var5 : this.categoryComponents) {
         if (var5.keyPressed(var1, var2, var3)) {
            return true;
         }
      }

      return super.keyPressed(var1, var2, var3);
   }

   @Override
   public boolean charTyped(char var1, int var2) {
      this.categoryComponents.forEach(var2x -> var2x.charTyped(var1, var2));
      return super.charTyped(var1, var2);
   }
}
