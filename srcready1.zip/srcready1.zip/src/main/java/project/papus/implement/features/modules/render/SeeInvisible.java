package project.papus.implement.features.modules.render;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.common.util.other.Instance;

public class SeeInvisible extends Module {
   private final MultiSelectSetting targetsSetting = new MultiSelectSetting("\u0426\u0435\u043b\u0438", "")
      .value("\u0418\u0433\u0440\u043e\u043a\u0438", "\u041c\u043e\u0431\u044b", "\u0414\u0440\u0443\u0437\u044c\u044f");
   private final ValueSetting alphaSetting = new ValueSetting("\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c", "")
      .range(0.1F, 1.0F)
      .setValue(0.5F);

   public static SeeInvisible getInstance() {
      return Instance.get(SeeInvisible.class);
   }

   public SeeInvisible() {
      super("SeeInvisible", "See Invisible", ModuleCategory.RENDER);
      this.setup(this.targetsSetting, this.alphaSetting);
      this.targetsSetting.getSelected().add("\u0418\u0433\u0440\u043e\u043a\u0438");
      this.targetsSetting.getSelected().add("\u041c\u043e\u0431\u044b");
      this.targetsSetting.getSelected().add("\u0414\u0440\u0443\u0437\u044c\u044f");
   }

   public float getAlpha() {
      return this.alphaSetting.getValue();
   }

   public boolean shouldSee(Entity var1) {
      if (var1 instanceof ArmorStandEntity) {
         return false;
      } else if (var1 instanceof LivingEntity var2) {
         if (var2 instanceof PlayerEntity) {
            boolean var3 = FriendUtils.getFriends().stream().anyMatch(var1x -> var1x.getName().equals(var2.getName().getString()));
            return var3
               ? this.targetsSetting.isSelected("\u0414\u0440\u0443\u0437\u044c\u044f")
               : this.targetsSetting.isSelected("\u0418\u0433\u0440\u043e\u043a\u0438");
         } else {
            return this.targetsSetting.isSelected("\u041c\u043e\u0431\u044b");
         }
      } else {
         return false;
      }
   }
}
