package project.papus.implement.screens.menu.components.implement.window;

import net.minecraft.client.gui.DrawContext;
import project.papus.api.system.animation.Animation;
import project.papus.api.system.animation.Direction;
import project.papus.api.system.animation.implement.DecelerateAnimation;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public abstract class AbstractWindow extends AbstractComponent {
   public boolean dragging;
   public boolean draggable;
   public int dragX;
   public int dragY;
   private final Animation scaleAnimation = new DecelerateAnimation().setValue(1.0).setMs(200);

   public AbstractWindow() {
      this.scaleAnimation.setDirection(Direction.FORWARDS);
   }

   public AbstractWindow setDraggable(boolean var1) {
      this.draggable = var1;
      return this;
   }

   public AbstractWindow size(float var1, float var2) {
      this.width = var1;
      this.height = var2;
      return this;
   }

   public AbstractWindow position(float var1, float var2) {
      this.x = var1;
      this.y = var2;
      return this;
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (this.isHovered(var1, var3) && var5 == 0 && this.draggable) {
         this.dragging = true;
         this.dragX = (int)(this.x - var1);
         this.dragY = (int)(this.y - var3);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      if (this.dragging && this.draggable) {
         this.x = var2 + this.dragX;
         this.y = var3 + this.dragY;
      }

      float var5 = this.scaleAnimation.getOutput().floatValue();
      MathUtil.scale(var1.getMatrices(), this.x + this.width / 2.0F, this.y + this.height / 2.0F, var5, () -> this.renderWindow(var1, var2, var3, var4));
   }

   protected abstract void renderWindow(DrawContext var1, int var2, int var3, float var4);

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.dragging = false;
      return true;
   }

   public boolean isHovered(double var1, double var3) {
      return var1 >= this.x && var1 <= this.x + this.width && var3 >= this.y && var3 <= this.y + this.height;
   }

   public void startCloseAnimation() {
      this.scaleAnimation.setDirection(Direction.BACKWARDS);
   }

   public boolean isCloseAnimationFinished() {
      return this.scaleAnimation.isFinished(Direction.BACKWARDS);
   }

   public Animation getScaleAnimation() {
      return this.scaleAnimation;
   }
}
