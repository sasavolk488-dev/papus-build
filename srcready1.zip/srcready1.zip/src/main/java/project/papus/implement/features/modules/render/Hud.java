package project.papus.implement.features.modules.render;

import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.common.util.other.Instance;

public class Hud extends Module {
   public final MultiSelectSetting elementsSetting = new MultiSelectSetting("\u042d\u043b\u0435\u043c\u0435\u043d\u0442\u044b", "")
      .value("Target Hud", "Notifications", "Hot Keys", "Potions", "Watermark");

   public Hud() {
      super("Hud", "Hud", ModuleCategory.RENDER);
      this.setup(this.elementsSetting);
      this.elementsSetting.getSelected().add("Target Hud");
      this.elementsSetting.getSelected().add("Notifications");
      this.elementsSetting.getSelected().add("Hot Keys");
      this.elementsSetting.getSelected().add("Potions");
      this.elementsSetting.getSelected().add("Watermark");
   }

   public static Hud getInstance() {
      return Instance.get(Hud.class);
   }

   public float getBlurStrength() {
      return 0.8F;
   }
}
