package project.papus.implement.features.modules.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.common.util.other.Instance;
import project.papus.implement.events.player.TickEvent;

public class NoRender extends Module {
   public static NoRender getInstance() {
      return Instance.get(NoRender.class);
   }

   public NoRender() {
      super("No Render", ModuleCategory.RENDER);
      this.state = true;
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      if (mc.player != null) {
         StatusEffectInstance var2 = mc.player.getStatusEffect(StatusEffects.DARKNESS);
         if (var2 != null) {
            mc.player.removeStatusEffect(StatusEffects.DARKNESS);
            ParticleManager var3 = MinecraftClient.getInstance().particleManager;
            var3.clearAtlas();
         }
      }
   }
}
