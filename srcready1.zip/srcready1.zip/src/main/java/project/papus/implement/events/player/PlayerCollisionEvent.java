package project.papus.implement.events.player;

import net.minecraft.entity.Entity;
import project.papus.api.event.events.callables.EventCancellable;

public class PlayerCollisionEvent extends EventCancellable {
   private final Entity entity;

   public PlayerCollisionEvent(Entity var1) {
      this.entity = var1;
   }

   public Entity getEntity() {
      return this.entity;
   }
}
