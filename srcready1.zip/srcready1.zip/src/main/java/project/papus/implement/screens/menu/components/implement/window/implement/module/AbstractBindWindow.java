package project.papus.implement.screens.menu.components.implement.window.implement.module;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.other.StringUtil;
import project.papus.implement.screens.menu.components.implement.window.AbstractWindow;

public abstract class AbstractBindWindow extends AbstractWindow {
   private boolean binding;

   protected abstract int getKey();

   protected abstract void setKey(int var1);

   protected abstract int getType();

   protected abstract void setType(int var1);

   @Override
   public void renderWindow(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      rectangle.render(ShapeProperties.create(var5, this.x, this.y, this.width, this.height).round(4.0F).softness(25.0F).color(838860800).build());
      rectangle.render(
         ShapeProperties.create(var5, this.x, this.y, this.width, this.height)
            .round(4.0F)
            .thickness(2.0F)
            .outlineColor(ColorUtil.getClientColor(0.8F, 1.0F))
            .color(ColorUtil.getFriendColor(1.0F))
            .build()
      );
      Fonts.getSize(14).drawString(var5, "Binding module", this.x + 5.0F, this.y + 8.0F, -1);
      image.setTexture("textures/trash.png").render(ShapeProperties.create(var5, this.x + this.width - 13.0F, this.y + 5.3F, 8.0, 8.0).build());
      this.drawKeyButton(var5);
      this.drawTypeButton(var5);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (var5 == 0) {
         if (MathUtil.isHovered(var1, var3, this.x + this.width - 57.0F, this.y + 37.0F, 52.0, 13.0)) {
            this.setType(this.getType() != 1 ? 1 : 0);
         }

         float var6 = Fonts.getSize(14).getStringWidth(StringUtil.getShortBindName(this.getKey()));
         if (MathUtil.isHovered(var1, var3, this.x + this.width - var6 - 15.0F, this.y + 18.8F, var6 + 10.0F, 13.0)) {
            this.binding = !this.binding;
         }

         if (MathUtil.isHovered(var1, var3, this.x + this.width - 13.0F, this.y + 5.3F, 8.0, 8.0)) {
            this.setKey(-1);
         }
      }

      if (this.binding && var5 > 1) {
         this.setKey(var5);
         this.binding = false;
      }

      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      int var4 = var1 != 261 && var1 != 256 ? var1 : -1;
      if (this.binding) {
         this.setKey(var4);
         this.binding = false;
      }

      return super.keyPressed(var1, var2, var3);
   }

   private void drawKeyButton(MatrixStack var1) {
      float var2 = Fonts.getSize(14).getStringWidth(StringUtil.getShortBindName(this.getKey()));
      rectangle.render(
         ShapeProperties.create(var1, this.x + this.width - var2 - 15.0F, this.y + 18.8F, var2 + 10.0F, 13.0)
            .round(2.0F)
            .thickness(2.0F)
            .softness(1.0F)
            .outlineColor(ColorUtil.getClientColor(0.8F, 1.0F))
            .color(ColorUtil.getClientColor(0.1F, 1.0F))
            .build()
      );
      int var3 = this.binding ? -8288257 : -2828575;
      Fonts.getSize(14).drawString(var1, StringUtil.getShortBindName(this.getKey()), this.x + this.width - 10.0F - var2, this.y + 23.6F, var3);
      Fonts.getSize(14).drawString(var1, "Key", (int)(this.x + 5.0F), (int)(this.y + 24.3), -2828575);
   }

   private void drawTypeButton(MatrixStack var1) {
      rectangle.render(
         ShapeProperties.create(var1, this.x + this.width - 57.0F, this.y + 37.0F, 52.0, 13.0)
            .round(2.0F)
            .thickness(2.0F)
            .softness(1.0F)
            .outlineColor(ColorUtil.getClientColor(0.8F, 1.0F))
            .color(ColorUtil.getClientColor(0.1F, 1.0F))
            .build()
      );
      if (this.getType() == 1) {
         rectangle.render(
            ShapeProperties.create(var1, this.x + this.width - 34.0F, this.y + 37.0F, 29.0, 13.0).round(2.0F, 2.0F, 0.0F, 0.0F).color(-8288257).build()
         );
      } else {
         rectangle.render(
            ShapeProperties.create(var1, this.x + this.width - 57.0F, this.y + 37.0F, 23.0, 13.0).round(0.0F, 0.0F, 2.0F, 2.0F).color(-8288257).build()
         );
      }

      Fonts.getSize(12).drawString(var1, "HOLD", this.x + 52.0F, this.y + 42.3, -2828575);
      Fonts.getSize(12).drawString(var1, "TOGGLE", this.x + 73.0F, this.y + 42.3, -2828575);
      Fonts.getSize(14).drawString(var1, "Bind mode", (int)(this.x + 5.0F), (int)(this.y + 42.3F), -2828575);
   }
}
