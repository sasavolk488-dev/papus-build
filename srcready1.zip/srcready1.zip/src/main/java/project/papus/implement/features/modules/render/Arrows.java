package project.papus.implement.features.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import java.util.stream.StreamSupport;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.other.Instance;
import project.papus.common.util.render.Render2DUtil;
import project.papus.implement.events.render.DrawEvent;

public class Arrows extends Module {
   private final ValueSetting offsetSetting = new ValueSetting("\u041e\u0442\u0441\u0442\u0443\u043f", "").setValue(30.0F).range(10, 100);
   private final ValueSetting sizeSetting = new ValueSetting("\u0420\u0430\u0437\u043c\u0435\u0440", "").setValue(10.0F).range(4, 24);
   private final MultiSelectSetting targetsSetting = new MultiSelectSetting("\u0426\u0435\u043b\u0438", "")
      .value("\u0418\u0433\u0440\u043e\u043a\u0438", "\u041c\u043e\u0431\u044b", "\u0414\u0440\u0443\u0437\u044c\u044f");
   private static final Identifier ARROW_TEXTURE = Identifier.of("papus", "textures/arrow.png");

   public static Arrows getInstance() {
      return Instance.get(Arrows.class);
   }

   public Arrows() {
      super("Arrows", "Arrows", ModuleCategory.RENDER);
      this.setup(this.offsetSetting, this.sizeSetting, this.targetsSetting);
      this.targetsSetting.getSelected().add("\u041c\u043e\u0431\u044b");
   }

   @EventHandler
   public void onDraw(DrawEvent var1) {
      if (mc.player != null && mc.world != null) {
         Camera var2 = mc.gameRenderer.getCamera();
         Vec3d var3 = var2.getPos();
         float var4 = var2.getYaw();
         RenderTickCounter var5 = mc.getRenderTickCounter();
         float var6 = var5.getTickDelta(true);
         double var7 = 64.0;
         List<Entity> var9 = StreamSupport.<Entity>stream(mc.world.getEntities().spliterator(), false)
            .filter(var0 -> var0 != null && var0 instanceof LivingEntity && var0 != mc.player)
            .filter(var0 -> ((LivingEntity)var0).isAlive())
            .filter(var3x -> var3x.squaredDistanceTo(var3.x, var3.y, var3.z) <= var7 * var7)
            .filter(
               var1x -> {
                  if (var1x instanceof LivingEntity var2x) {
                     if (var2x instanceof PlayerEntity) {
                        boolean var3x = FriendUtils.getFriends().stream().anyMatch(var1xx -> var1xx.getName().equals(var2x.getName().getString()));
                        return var3x
                           ? this.targetsSetting.isSelected("\u0414\u0440\u0443\u0437\u044c\u044f")
                           : this.targetsSetting.isSelected("\u0418\u0433\u0440\u043e\u043a\u0438");
                     } else {
                        return this.targetsSetting.isSelected("\u041c\u043e\u0431\u044b");
                     }
                  } else {
                     return false;
                  }
               }
            )
            .toList();
         if (!var9.isEmpty()) {
            float var10 = window.getScaledWidth() / 2.0F;
            float var11 = window.getScaledHeight() / 2.0F;
            float var12 = this.offsetSetting.getValue();
            float var13 = this.sizeSetting.getValue();
            MatrixStack var14 = var1.getDrawContext().getMatrices();

            for (Entity var16 : var9) {
               LivingEntity var17 = (LivingEntity)var16;
               Vec3d var18 = var16.getLerpedPos(var6);
               double var19 = var18.x - var3.x;
               double var21 = var18.z - var3.z;
               float var23 = (float)(Math.toDegrees(Math.atan2(var21, var19)) - 90.0);
               float var24 = MathHelper.wrapDegrees(var23 - var4);
               double var25 = Math.toRadians(var24);
               float var27 = var10 + (float)Math.sin(var25) * var12;
               float var28 = var11 - (float)Math.cos(var25) * var12;
               int var29 = this.getEntityColor(var17);
               var14.push();
               var14.translate(var27, var28, 0.0F);
               var14.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var24));
               var14.translate(-var13 / 2.0F, -var13 / 2.0F, 0.0F);
               RenderSystem.setShaderColor(ColorUtil.redf(var29), ColorUtil.greenf(var29), ColorUtil.bluef(var29), ColorUtil.alphaf(var29));
               Render2DUtil.drawTexture(var1.getDrawContext(), ARROW_TEXTURE, 0.0F, 0.0F, (int)var13);
               RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
               var14.pop();
            }
         }
      }
   }

   private int getEntityColor(LivingEntity var1) {
      if (var1 instanceof PlayerEntity) {
         boolean var2 = FriendUtils.getFriends().stream().anyMatch(var1x -> var1x.getName().equals(var1.getName().getString()));
         if (var2) {
            return ColorUtil.getColor(50, 255, 50, 255);
         }
      }

      return ColorUtil.getColor(255, 255, 255, 255);
   }
}
