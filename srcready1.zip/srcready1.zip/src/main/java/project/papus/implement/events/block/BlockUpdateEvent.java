package project.papus.implement.events.block;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import project.papus.api.event.events.Event;

public record BlockUpdateEvent(BlockState state, BlockPos pos, BlockUpdateEvent.Type type) implements Event {
   public static enum Type {
      LOAD,
      UNLOAD,
      UPDATE;
   }
}
