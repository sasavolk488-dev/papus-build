package project.papus.implement.events.block;

import project.papus.api.event.events.callables.EventCancellable;

public class PushEvent extends EventCancellable {
   private PushEvent.Type type;

   public PushEvent.Type getType() {
      return this.type;
   }

   public PushEvent(PushEvent.Type var1) {
      this.type = var1;
   }

   public static enum Type {
      COLLISION,
      BLOCK,
      WATER;
   }
}
