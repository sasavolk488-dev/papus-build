package project.papus.implement.events.player;

import project.papus.api.event.events.Event;

public class RotationUpdateEvent implements Event {
   byte type;

   public byte getType() {
      return this.type;
   }

   public RotationUpdateEvent(byte var1) {
      this.type = var1;
   }
}
