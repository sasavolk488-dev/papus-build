package project.papus.implement.events.player;

import net.minecraft.util.math.Vec3d;
import project.papus.api.event.events.Event;

public class FovMultiplierEvent implements Event {
   public Vec3d velocity;

   public FovMultiplierEvent(Vec3d var1) {
      this.velocity = var1;
   }

   public Vec3d getVelocity() {
      return this.velocity;
   }

   public void setVelocity(Vec3d var1) {
      this.velocity = var1;
   }
}
