package project.papus.implement.features.modules.player;

import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.BindSetting;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.common.util.entity.PlayerInventoryUtil;
import project.papus.common.util.other.StopWatch;
import project.papus.common.util.task.scripts.Script;
import project.papus.implement.events.keyboard.HotBarScrollEvent;
import project.papus.implement.events.keyboard.KeyEvent;
import project.papus.implement.events.player.KeyboardInputEvent;
import project.papus.implement.events.player.TickEvent;

public class ClickPearl extends Module {
   private final BindSetting keySetting = new BindSetting("Key", "");
   private final SelectSetting modeSetting = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "")
      .value("FunTime", "\u0414\u0440\u0443\u0433\u0438\u0435 \u0441\u0435\u0440\u0432\u0435\u0440\u0430")
      .selected("FunTime");
   private static final int SCROLL_LOCK_DURATION = 48;
   private final Script script = new Script();
   private final StopWatch stopWatch = new StopWatch();
   private final Random random = new Random();
   private boolean slownessActive = false;
   private int savedHotbarSlot = -1;
   private int scrollLockTicks = -1;
   private int pearlTicks = -1;
   private String pendingAction = null;

   public ClickPearl() {
      super("Click Pearl", "Click Pearl", ModuleCategory.PLAYER);
      this.setup(this.keySetting, this.modeSetting);
   }

   @Override
   public void deactivate() {
      this.resetState();
      super.deactivate();
   }

   private void resetState() {
      this.slownessActive = false;
      this.savedHotbarSlot = -1;
      this.scrollLockTicks = -1;
      this.pearlTicks = -1;
      this.pendingAction = null;
      this.script.cleanup();
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      this.script.update();
      if (this.slownessActive && mc.player != null) {
         mc.player.setSprinting(false);
      }
   }

   @EventHandler
   public void onKeyboardInput(KeyboardInputEvent var1) {
      if (this.slownessActive) {
         var1.resetDirectional();
      }
   }

   @EventHandler
   public void onHotBarScroll(HotBarScrollEvent var1) {
      if (this.slownessActive) {
         var1.setCancelled(true);
      }
   }

   @EventHandler
   public void onKey(KeyEvent var1) {
      if (var1.action() == 1 && mc.player != null) {
         if (mc.currentScreen == null) {
            if (!this.slownessActive && this.script.isFinished()) {
               if (this.stopWatch.every(1.0)) {
                  if (var1.key() == this.keySetting.getKey()) {
                     if (!this.modeSetting.getSelected().equals("\u0414\u0440\u0443\u0433\u0438\u0435 \u0441\u0435\u0440\u0432\u0435\u0440\u0430")
                        || mc.player.isOnGround()) {
                        int var2 = this.findEnderPearlSlot();
                        if (var2 != -1) {
                           int var4 = mc.player.inventory.selectedSlot;
                           ItemStack var5 = mc.player.inventory.getStack(var4);
                           this.pendingAction = var5.isEmpty() ? "empty" : var5.getName().getString().toLowerCase();
                           this.scrollLockTicks = var4;
                           this.savedHotbarSlot = var2;
                           this.script.cleanup();
                           this.slownessActive = true;
                           if (var2 < 9) {
                              byte var6 = 10;
                              this.script
                                 .addTickStep(var6 + this.random.nextInt(8), () -> mc.player.inventory.selectedSlot = var2)
                                 .addTickStep(var6 + this.random.nextInt(8), () -> {
                                    mc.player.swingHand(Hand.MAIN_HAND);
                                    mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                                 })
                                 .addTickStep(var6 + this.random.nextInt(8), () -> {
                                    mc.player.inventory.selectedSlot = var4;
                                    mc.player.setSprinting(false);
                                    this.resetState();
                                    this.stopWatch.reset();
                                 });
                           } else {
                              byte var8 = 48;
                              this.script
                                 .addTickStep(var8 + this.random.nextInt(15), () -> PlayerInventoryUtil.clickSlot(var2, var4, SlotActionType.SWAP, false))
                                 .addTickStep(var8 + this.random.nextInt(15), () -> {
                                    mc.player.swingHand(Hand.MAIN_HAND);
                                    mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                                 })
                                 .addTickStep(var8 + this.random.nextInt(20), () -> {
                                    ItemStack var3 = mc.player.inventory.getStack(var2);
                                    if (!var3.isEmpty()) {
                                       PlayerInventoryUtil.clickSlot(var2, var4, SlotActionType.SWAP, false);
                                    }

                                    mc.player.setSprinting(false);
                                    this.resetState();
                                    this.stopWatch.reset();
                                 });
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private int findEnderPearlSlot() {
      for (int var1 = 0; var1 < 36; var1++) {
         ItemStack var2 = mc.player.inventory.getStack(var1);
         if (!var2.isEmpty()) {
            String var3 = var2.getItem().toString();
            if (var3.contains("ender_pearl")) {
               return var1;
            }
         }
      }

      return -1;
   }

   private int findItemInRange(String var1, int var2, int var3) {
      if (var1 == null) {
         return -1;
      } else {
         for (int var4 = var2; var4 < var3; var4++) {
            ItemStack var5 = mc.player.inventory.getStack(var4);
            if (!var5.isEmpty() && var5.getName().getString().toLowerCase().contains(var1.toLowerCase())) {
               return var4;
            }
         }

         return -1;
      }
   }
}
