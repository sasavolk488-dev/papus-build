package project.papus.implement.screens.menu.components.implement.other;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class ButtonComponent extends AbstractComponent {
   private String text;
   private Runnable action;
   private int color = -8288257;

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      this.width = Fonts.getSize(12).getStringWidth(this.text) + 13.0F;
      this.height = 12.0F;
      rectangle.render(ShapeProperties.create(var5, this.x, this.y, this.width, this.height).round(2.0F).color(this.color).build());
      Fonts.getSize(12, Fonts.Type.BOLD).drawCenteredString(var5, this.text, this.x + this.width / 2.0, this.y + 5.0F, -1);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height) && var5 == 0) {
         this.action.run();
      }

      return super.mouseClicked(var1, var3, var5);
   }

   public ButtonComponent setText(String var1) {
      this.text = var1;
      return this;
   }

   public ButtonComponent setAction(Runnable var1) {
      this.action = var1;
      return this;
   }

   public ButtonComponent setColor(int var1) {
      this.color = var1;
      return this;
   }
}
