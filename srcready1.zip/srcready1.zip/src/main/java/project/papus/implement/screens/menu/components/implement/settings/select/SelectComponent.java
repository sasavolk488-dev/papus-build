package project.papus.implement.screens.menu.components.implement.settings.select;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.api.system.animation.Animation;
import project.papus.api.system.animation.Direction;
import project.papus.api.system.animation.implement.DecelerateAnimation;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class SelectComponent extends AbstractComponent {
   private final SelectSetting setting;
   private final String text;
   private final Animation alphaAnimation = new DecelerateAnimation().setMs(250).setValue(1.0);
   private float opacity = 1.0F;

   public SelectComponent(SelectSetting var1, String var2) {
      this.setting = var1;
      this.text = var2;
   }

   public SelectComponent setOpacity(float var1) {
      this.opacity = var1;
      return this;
   }

   public String getText() {
      return this.text;
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      boolean var6 = this.setting.getSelected().equals(this.text);
      boolean var7 = MathUtil.isHovered(var2, var3, this.x, this.y, this.width, this.height);
      this.alphaAnimation.setDirection(!var7 && !var6 ? Direction.BACKWARDS : Direction.FORWARDS);
      int var8;
      int var9;
      if (var6) {
         var8 = ColorUtil.getColor(170, 60, 255, (int)(255.0F * this.opacity));
         var9 = -1;
      } else {
         var8 = ColorUtil.getColor(80, 80, 80, (int)(180.0F * this.opacity));
         var9 = ColorUtil.getColor(150, 150, 150, 255);
      }

      float var10 = Fonts.getSize(12, Fonts.Type.DEFAULT).getStringWidth(this.text);
      this.width = var10 + 18.0F;
      this.height = 15.0F;
      rectangle.renderOutline(
         ShapeProperties.create(var5, this.x, this.y, this.width, this.height - 4.0F).round(3.5F).softness(0.0F).quality(64.0F).outlineColor(var8).build(),
         1.5F
      );
      float var11 = this.x + (this.width - var10) / 2.0F;
      float var12 = this.y + (this.height - 4.0F - 8.0F) / 2.0F + 2.5F;
      Fonts.getSize(12, Fonts.Type.DEFAULT).drawString(var5, this.text, var11, var12, var9);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height) && var5 == 0) {
         this.setting.setSelected(this.text);
         return true;
      } else {
         return super.mouseClicked(var1, var3, var5);
      }
   }
}
