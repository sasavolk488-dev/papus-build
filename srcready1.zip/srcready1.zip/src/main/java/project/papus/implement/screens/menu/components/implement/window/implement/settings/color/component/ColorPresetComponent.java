package project.papus.implement.screens.menu.components.implement.window.implement.settings.color.component;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import project.papus.api.feature.module.setting.implement.ColorSetting;
import project.papus.api.system.font.Fonts;
import project.papus.implement.screens.menu.components.AbstractComponent;
import project.papus.implement.screens.menu.components.implement.window.implement.settings.color.ColorPresetButton;

public class ColorPresetComponent extends AbstractComponent {
   private final List<ColorPresetButton> presetButtons = new ArrayList<>();
   private final ColorSetting setting;
   private float windowHeight;
   private float windowWidth;

   public ColorPresetComponent(ColorSetting var1) {
      this.setting = var1;
      int[] var2 = var1.getPresets();
      if (var2 != null) {
         for (int var6 : var2) {
            this.presetButtons.add(new ColorPresetButton(var1, var6));
         }
      }
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      if (!this.presetButtons.isEmpty()) {
         Fonts.getSize(11).drawString(var1.getMatrices(), "Prepared swatches", this.x + 6.0F, this.y + 112.0F, -1);
      }

      byte var5 = 0;
      int var6 = 0;
      int var7 = 0;
      byte var8 = 13;

      for (ColorPresetButton var10 : this.presetButtons) {
         var10.x = this.x + 6.0F + var5;
         var10.y = this.y + 120.0F + var6;
         var10.render(var1, var2, var3, var4);
         var5 += var8;
         if (++var7 >= 11) {
            var7 = 0;
            var5 = 0;
            var6 += var8 - 1;
         }
      }

      this.windowHeight = this.presetButtons.isEmpty() ? 132.0F : 156 + var6 - var6 / 2.0F;
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      this.presetButtons.forEach(var5x -> var5x.mouseClicked(var1, var3, var5));
      return super.mouseClicked(var1, var3, var5);
   }

   public List<ColorPresetButton> getPresetButtons() {
      return this.presetButtons;
   }

   public ColorSetting getSetting() {
      return this.setting;
   }

   public float getWindowHeight() {
      return this.windowHeight;
   }

   public float getWindowWidth() {
      return this.windowWidth;
   }
}
