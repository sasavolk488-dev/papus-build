package project.papus.implement.features.modules.misc;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.BindSetting;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.implement.events.keyboard.KeyEvent;

public class ClickFriend extends Module {
   private final BindSetting keySetting = new BindSetting("Key", "Key");

   public ClickFriend() {
      super("ClickFriend", "Click Friend", ModuleCategory.MISC);
      this.setup(this.keySetting);
   }

   @EventHandler
   public void onKey(KeyEvent var1) {
      if (var1.key() == this.keySetting.getKey() && var1.action() == 1) {
         if (mc.player != null && mc.world != null) {
            if (mc.crosshairTarget instanceof EntityHitResult var2 && var2.getEntity() instanceof PlayerEntity var4 && var4 != mc.player) {
               String var5 = ((LivingEntity)var4).getName().getString();
               boolean var6 = FriendUtils.getFriends().stream().anyMatch(var1x -> var1x.getName().equals(var5));
               if (var6) {
                  FriendUtils.removeFriend(var5);
                  this.toggleFriend("\u00a7c" + var5 + " \u00a77\u0443\u0434\u0430\u043b\u0451\u043d \u0438\u0437 \u0434\u0440\u0443\u0437\u0435\u0439!");
               } else {
                  FriendUtils.addFriend(var5);
                  this.toggleFriend(
                     "\u00a7a" + var5 + " \u00a77\u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0432 \u0434\u0440\u0443\u0437\u044c\u044f!"
                  );
               }
            }
         }
      }
   }

   private void toggleFriend(String var1) {
      if (mc.player != null) {
         mc.player.sendMessage(Text.literal("\u00a7f\u00a77[Papus]\u00a7f " + var1), false);
      }
   }
}
