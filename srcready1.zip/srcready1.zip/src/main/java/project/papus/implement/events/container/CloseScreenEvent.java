package project.papus.implement.events.container;

import net.minecraft.client.gui.screen.Screen;
import project.papus.api.event.events.callables.EventCancellable;

public class CloseScreenEvent extends EventCancellable {
   private Screen screen;

   @Override
   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else if (var1 instanceof CloseScreenEvent var2) {
         if (!var2.canEqual(this)) {
            return false;
         } else if (!super.equals(var1)) {
            return false;
         } else {
            Screen var3 = this.getScreen();
            Screen var4 = var2.getScreen();
            return var3 == null ? var4 == null : var3.equals(var4);
         }
      } else {
         return false;
      }
   }

   protected boolean canEqual(Object var1) {
      return var1 instanceof CloseScreenEvent;
   }

   @Override
   public int hashCode() {
      byte var1 = 59;
      int var2 = super.hashCode();
      Screen var3 = this.getScreen();
      return var2 * 59 + (var3 == null ? 43 : var3.hashCode());
   }

   public Screen getScreen() {
      return this.screen;
   }

   public void setScreen(Screen var1) {
      this.screen = var1;
   }

   @Override
   public String toString() {
      return "CloseScreenEvent(screen=" + this.getScreen() + ")";
   }

   public CloseScreenEvent(Screen var1) {
      this.screen = var1;
   }
}
