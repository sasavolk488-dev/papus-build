package project.papus.implement.screens.menu.components.implement.window.implement.settings.color;

import net.minecraft.client.gui.DrawContext;
import project.papus.api.feature.module.setting.implement.ColorSetting;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class ColorPresetButton extends AbstractComponent {
   private final ColorSetting setting;
   private final int color;

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      rectangle.render(ShapeProperties.create(var1.getMatrices(), this.x, this.y, 8.0, 8.0).round(2.0F).color(this.color).build());
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (MathUtil.isHovered(var1, var3, this.x, this.y, 8.0, 8.0) && var5 == 0) {
         this.setting.setColor(this.color);
      }

      return super.mouseClicked(var1, var3, var5);
   }

   public ColorPresetButton(ColorSetting var1, int var2) {
      this.setting = var1;
      this.color = var2;
   }
}
