package project.papus.implement.events.player;

import project.papus.api.event.events.Event;

public class RotatedMovementInputEvent implements Event {
   private float forward;
   private float sideways;

   public RotatedMovementInputEvent(float var1, float var2) {
      this.forward = var1;
      this.sideways = var2;
   }

   public float getForward() {
      return this.forward;
   }

   public float getSideways() {
      return this.sideways;
   }

   public void setForward(float var1) {
      this.forward = var1;
   }

   public void setSideways(float var1) {
      this.sideways = var1;
   }

   @Override
   public String toString() {
      return "RotatedMovementInputEvent(forward=" + this.getForward() + ", sideways=" + this.getSideways() + ")";
   }

   @Override
   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else if (var1 instanceof RotatedMovementInputEvent var2) {
         if (!var2.canEqual(this)) {
            return false;
         } else {
            return Float.compare(this.getForward(), var2.getForward()) != 0 ? false : Float.compare(this.getSideways(), var2.getSideways()) == 0;
         }
      } else {
         return false;
      }
   }

   protected boolean canEqual(Object var1) {
      return var1 instanceof RotatedMovementInputEvent;
   }

   @Override
   public int hashCode() {
      byte var1 = 59;
      int var2 = 1;
      var2 = var2 * 59 + Float.floatToIntBits(this.getForward());
      return var2 * 59 + Float.floatToIntBits(this.getSideways());
   }
}
