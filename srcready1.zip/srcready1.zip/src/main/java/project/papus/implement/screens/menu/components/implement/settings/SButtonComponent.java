package project.papus.implement.screens.menu.components.implement.settings;

import net.minecraft.client.gui.DrawContext;
import project.papus.api.feature.module.setting.implement.ButtonSetting;
import project.papus.api.system.font.Fonts;
import project.papus.implement.screens.menu.components.implement.other.ButtonComponent;

public class SButtonComponent extends AbstractSettingComponent {
   private final ButtonComponent buttonComponent = new ButtonComponent();
   private final ButtonSetting setting;

   public SButtonComponent(ButtonSetting var1) {
      super(var1);
      this.setting = var1;
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      this.height = 18.0F;
      Fonts.getSize(14, Fonts.Type.BOLD).drawString(var1.getMatrices(), this.setting.getName(), this.x + 9.0F, this.y + 6.0F, -2828575);
      ((ButtonComponent)this.buttonComponent
            .setText("Click on me")
            .setAction(this.setting.getRunnable())
            .position(this.x + this.width - 9.0F - this.buttonComponent.width, this.y + 5.0F))
         .render(var1, var2, var3, var4);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      this.buttonComponent.mouseClicked(var1, var3, var5);
      return super.mouseClicked(var1, var3, var5);
   }
}
