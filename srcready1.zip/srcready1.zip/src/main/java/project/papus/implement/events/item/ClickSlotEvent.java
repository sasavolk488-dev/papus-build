package project.papus.implement.events.item;

import net.minecraft.screen.slot.SlotActionType;
import project.papus.api.event.events.callables.EventCancellable;

public class ClickSlotEvent extends EventCancellable {
   private int syncId;
   private int slotId;
   private int button;
   private SlotActionType actionType;

   public int getSyncId() {
      return this.syncId;
   }

   public int getSlotId() {
      return this.slotId;
   }

   public int getButton() {
      return this.button;
   }

   public SlotActionType getActionType() {
      return this.actionType;
   }

   public void setSyncId(int var1) {
      this.syncId = var1;
   }

   public void setSlotId(int var1) {
      this.slotId = var1;
   }

   public void setButton(int var1) {
      this.button = var1;
   }

   public void setActionType(SlotActionType var1) {
      this.actionType = var1;
   }

   public ClickSlotEvent(int var1, int var2, int var3, SlotActionType var4) {
      this.syncId = var1;
      this.slotId = var2;
      this.button = var3;
      this.actionType = var4;
   }
}
