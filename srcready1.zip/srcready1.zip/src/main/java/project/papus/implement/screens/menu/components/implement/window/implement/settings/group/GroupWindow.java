package project.papus.implement.screens.menu.components.implement.window.implement.settings.group;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import project.papus.api.feature.module.setting.SettingComponentAdder;
import project.papus.api.feature.module.setting.implement.GroupSetting;
import project.papus.api.system.font.Fonts;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.render.ScissorManager;
import project.papus.core.Main;
import project.papus.implement.screens.menu.components.AbstractComponent;
import project.papus.implement.screens.menu.components.implement.settings.AbstractSettingComponent;
import project.papus.implement.screens.menu.components.implement.window.AbstractWindow;

public class GroupWindow extends AbstractWindow {
   private final List<AbstractSettingComponent> components = new ArrayList<>();
   private final GroupSetting setting;

   public GroupWindow(GroupSetting var1) {
      this.setting = var1;
      new SettingComponentAdder().addSettingComponent(var1.getSubSettings(), this.components);
   }

   @Override
   public void renderWindow(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      ScissorManager var6 = Main.getInstance().getScissorManager();
      this.height = MathHelper.clamp(this.getComponentHeight(), 0, 200);
      Fonts.getSize(15, Fonts.Type.BOLD).drawString(var1.getMatrices(), "Settings " + this.setting.getName(), this.x + 9.0F, this.y + 10.0F, -1);
      boolean var7 = MathHelper.clamp(this.height, 0.0F, 200.0F) == 200.0F;
      if (var7) {
         var6.push(var5.peek().getPositionMatrix(), this.x, this.y + 23.0F, this.width, this.height - 28.0F);
      }

      float var8 = 0.0F;
      int var9 = 0;

      for (int var10 = this.components.size() - 1; var10 >= 0; var10--) {
         AbstractSettingComponent var11 = this.components.get(var10);
         Supplier var12 = var11.getSetting().getVisible();
         if (var12 == null || (Boolean)var12.get()) {
            var11.x = this.x;
            var11.y = (float)(this.y + 19.0F + var8 + (this.getComponentHeight() - 25 - var11.height) + this.smoothedScroll);
            var11.width = this.width;
            var11.render(var1, var2, var3, var4);
            var8 -= var11.height;
            var9 += (int)var11.height;
         }
      }

      if (var7) {
         var6.pop();
      }

      int var13 = (int)Math.max(0.0F, var9 - (this.height - 23.0F));
      this.scroll = MathHelper.clamp(this.scroll, -var13, 0.0);
      this.smoothedScroll = MathHelper.lerp(0.1F, this.smoothedScroll, this.scroll);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      this.setDraggable(MathUtil.isHovered(var1, var3, this.x, this.y, this.width, 19.0) && var5 == 0);
      boolean var6 = this.components.stream().anyMatch(var4 -> var4.isHover(var1, var3));
      if (var6) {
         this.components.forEach(var5x -> {
            if (var5x.isHover(var1, var3)) {
               var5x.mouseClicked(var1, var3, var5);
            }
         });
         return super.mouseClicked(var1, var3, var5);
      } else {
         this.components.forEach(var5x -> var5x.mouseClicked(var1, var3, var5));
         return super.mouseClicked(var1, var3, var5);
      }
   }

   @Override
   public boolean isHover(double var1, double var3) {
      this.components.forEach(var4 -> var4.isHover(var1, var3));

      for (AbstractComponent var6 : this.components) {
         if (var6.isHover(var1, var3)) {
            return true;
         }
      }

      return super.isHover(var1, var3);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.components.forEach(var5x -> var5x.mouseReleased(var1, var3, var5));
      return super.mouseReleased(var1, var3, var5);
   }

   @Override
   public boolean mouseScrolled(double var1, double var3, double var5) {
      boolean var7 = MathHelper.clamp(this.height, 0.0F, 200.0F) == 200.0F && MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height);
      if (var7) {
         this.scroll += var5 * 20.0;
      }

      this.components.forEach(var6 -> var6.mouseScrolled(var1, var3, var5));
      return var7;
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      this.components.forEach(var3x -> var3x.keyPressed(var1, var2, var3));
      return super.keyPressed(var1, var2, var3);
   }

   @Override
   public boolean charTyped(char var1, int var2) {
      this.components.forEach(var2x -> var2x.charTyped(var1, var2));
      return super.charTyped(var1, var2);
   }

   public int getComponentHeight() {
      float var1 = 0.0F;

      for (AbstractSettingComponent var3 : this.components) {
         Supplier var4 = var3.getSetting().getVisible();
         if (var4 == null || (Boolean)var4.get()) {
            var1 += var3.height;
         }
      }

      return (int)(var1 + 25.0F);
   }

   public List<AbstractSettingComponent> getComponents() {
      return this.components;
   }

   public GroupSetting getSetting() {
      return this.setting;
   }
}
