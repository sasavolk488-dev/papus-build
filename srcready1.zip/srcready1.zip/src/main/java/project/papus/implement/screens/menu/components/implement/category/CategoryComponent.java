package project.papus.implement.screens.menu.components.implement.category;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix4f;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.render.ScissorManager;
import project.papus.core.Main;
import project.papus.implement.screens.menu.MenuScreen;
import project.papus.implement.screens.menu.components.AbstractComponent;
import project.papus.implement.screens.menu.components.implement.friend.ComingSoonComponent;
import project.papus.implement.screens.menu.components.implement.module.ModuleComponent;

public class CategoryComponent extends AbstractComponent {
   private final List<ModuleComponent> moduleComponents = new ArrayList<>();
   private static final Set<ModuleComponent> GLOBAL_MODULE_COMPONENTS = new HashSet<>();
   private final ModuleCategory category;
   private ComingSoonComponent comingSoonComponent;
   private float scroll = 0.0F;
   private float smoothedScroll = 0.0F;
   private double scrollbarY = 0.0;

   private void initializeModules() {
      for (Module var2 : Main.getInstance().getModuleRepository().modules()) {
         ModuleComponent var3 = new ModuleComponent(var2);
         if (GLOBAL_MODULE_COMPONENTS.add(var3)) {
            this.moduleComponents.add(var3);
         }
      }
   }

   public CategoryComponent(ModuleCategory var1) {
      this.category = var1;
      this.initializeModules();
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MenuScreen var5 = MenuScreen.getInstance();
      GLOBAL_MODULE_COMPONENTS.clear();
      Matrix4f var6 = var1.getMatrices().peek().getPositionMatrix();
      ScissorManager var7 = Main.getInstance().getScissorManager();
      if (this.category == ModuleCategory.FRIEND && var5.getCategory() == ModuleCategory.FRIEND) {
         if (this.comingSoonComponent == null) {
            this.comingSoonComponent = new ComingSoonComponent();
         }

         this.comingSoonComponent.x = var5.x + 44;
         this.comingSoonComponent.y = var5.y + 24;
         this.comingSoonComponent.width = var5.width - 58;
         this.comingSoonComponent.height = var5.height - 45;
         this.comingSoonComponent.render(var1, var2, var3, var4);
      } else {
         short var8 = 130;
         float var9 = 13.0F;
         int[] var10 = new int[2];
         int var11 = 0;
         int var12 = 0;
         float var13 = 0.0F;
         float var14 = 0.0F;
         var7.push(var6, var5.x, var5.y + var13, var5.width, var5.height - var13 - var14);

         for (int var15 = this.moduleComponents.size() - 1; var15 >= 0; var15--) {
            ModuleComponent var16 = this.moduleComponents.get(var15);
            if (this.shouldRenderComponent(var16)) {
               int var17 = var16.getComponentHeight() + 4;
               int var18 = var11 % 2;
               var16.x = var5.x + 48 + var18 * (var8 + var9);
               var16.y = var5.y + var13 + var10[var18] + this.smoothedScroll;
               var16.width = var8;
               var16.render(var1, var2, var3, var4);
               var10[var18] += var17;
               var11++;
            }
         }

         var12 = Math.max(var10[0], var10[1]);
         var7.pop();
         int var24 = Math.max(0, var12 - (int)(var5.height - var13 - var14));
         this.scroll = Math.max((float)(-var24), Math.min(0.0F, this.scroll));
         this.smoothedScroll = MathUtil.interpolateSmooth(2.0, this.smoothedScroll, this.scroll);
         if (var24 > 0) {
            float var25 = var5.height - 5.0F;
            float var26 = 2.5F;
            float var27 = var5.x + var5.width - 6;
            float var19 = var5.y + 2.0F;
            float var20 = Math.max(20.0F, var25 * ((float)var5.height / (var24 + var5.height)));
            float var21 = Math.abs(this.scroll) / var24;
            float var22 = var19 + (var25 - var20) * var21;
            this.scrollbarY = MathUtil.interpolateSmooth(2.0, this.scrollbarY, (double)var22);
            rectangle.render(
               ShapeProperties.create(var1.getMatrices(), var27 - 1.0F, var19, 4.5, var25).round(2.25F).color(ColorUtil.getColor(255, 255, 255, 5)).build()
            );
            rectangle.render(
               ShapeProperties.create(var1.getMatrices(), var27, (float)this.scrollbarY, 2.5, var20)
                  .round(1.25F)
                  .color(ColorUtil.getColor(160, 130, 255, 55))
                  .build()
            );
         }
      }
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (this.category == ModuleCategory.FRIEND && MenuScreen.getInstance().getCategory() == ModuleCategory.FRIEND) {
         return this.comingSoonComponent != null ? this.comingSoonComponent.mouseClicked(var1, var3, var5) : false;
      } else {
         for (ModuleComponent var7 : this.moduleComponents) {
            if (this.shouldRenderComponent(var7) && var7.isHover(var1, var3)) {
               var7.mouseClicked(var1, var3, var5);
               return true;
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      for (ModuleComponent var7 : this.moduleComponents) {
         if (this.shouldRenderComponent(var7)) {
            var7.mouseReleased(var1, var3, var5);
         }
      }

      return false;
   }

   @Override
   public boolean mouseScrolled(double var1, double var3, double var5) {
      MenuScreen var7 = MenuScreen.getInstance();
      if (this.category == ModuleCategory.FRIEND && var7.getCategory() == ModuleCategory.FRIEND) {
         return this.comingSoonComponent != null ? this.comingSoonComponent.mouseScrolled(var1, var3, var5) : false;
      } else {
         if (MathUtil.isHovered(var1, var3, var7.x, var7.y, var7.width, var7.height)) {
            this.scroll += (float)(var5 * 78.0);
         }

         return true;
      }
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      if (this.category == ModuleCategory.FRIEND && MenuScreen.getInstance().getCategory() == ModuleCategory.FRIEND) {
         return this.comingSoonComponent != null ? this.comingSoonComponent.keyPressed(var1, var2, var3) : false;
      } else {
         for (ModuleComponent var5 : this.moduleComponents) {
            if (this.shouldRenderComponent(var5) && var5.keyPressed(var1, var2, var3)) {
               return true;
            }
         }

         return false;
      }
   }

   @Override
   public boolean charTyped(char var1, int var2) {
      if (this.category == ModuleCategory.FRIEND && MenuScreen.getInstance().getCategory() == ModuleCategory.FRIEND) {
         return this.comingSoonComponent != null ? this.comingSoonComponent.charTyped(var1, var2) : false;
      } else {
         for (ModuleComponent var4 : this.moduleComponents) {
            if (this.shouldRenderComponent(var4)) {
               var4.charTyped(var1, var2);
            }
         }

         return false;
      }
   }

   private boolean shouldRenderComponent(ModuleComponent var1) {
      MenuScreen var2 = MenuScreen.getInstance();
      ModuleCategory var3 = var1.getModule().getCategory();
      String var4 = var2.getBackgroundComponent().getSearchText().toLowerCase();
      String var5 = var1.getModule().getVisibleName().toLowerCase();
      return var4.isEmpty() ? var3.equals(var2.getCategory()) : var5.contains(var4);
   }
}
