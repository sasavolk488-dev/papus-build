package project.papus.implement.features.modules.render;

import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.implement.events.render.AspectRatioEvent;

public class AspectRatio extends Module {
   private final ValueSetting aspectRatioSetting = new ValueSetting("\u0421\u043e\u043e\u0442\u043d\u043e\u0448\u0435\u043d\u0438\u0435", "")
      .setValue(1.5F)
      .range(0.5F, 2.0F);

   public AspectRatio() {
      super("AspectRatio", "Aspect Ratio", ModuleCategory.RENDER);
      this.setup(this.aspectRatioSetting);
   }

   @EventHandler
   public void onAspectRatio(AspectRatioEvent var1) {
      var1.setRatio(this.aspectRatioSetting.getValue());
      var1.cancel();
   }
}
