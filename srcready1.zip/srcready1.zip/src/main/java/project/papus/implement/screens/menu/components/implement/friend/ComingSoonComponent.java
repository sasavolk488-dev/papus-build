package project.papus.implement.screens.menu.components.implement.friend;

import net.minecraft.client.gui.DrawContext;
import project.papus.api.system.font.Fonts;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class ComingSoonComponent extends AbstractComponent {
   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      String var5 = "Coming soon...";
      float var6 = this.x + this.width / 2.0F;
      float var7 = this.y + this.height / 2.0F;
      Fonts.getSize(20, Fonts.Type.DEFAULT).drawCenteredString(var1.getMatrices(), var5, var6, var7 - 10.0F, ColorUtil.getColor(255, 255, 255, 100));
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      return MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height);
   }

   @Override
   public boolean isHover(double var1, double var3) {
      return MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height);
   }
}
