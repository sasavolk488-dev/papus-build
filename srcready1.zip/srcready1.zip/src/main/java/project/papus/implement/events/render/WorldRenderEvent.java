package project.papus.implement.events.render;

import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.event.events.Event;

public class WorldRenderEvent implements Event {
   private MatrixStack stack;
   private float tickDelta;

   public WorldRenderEvent(MatrixStack var1, float var2) {
      this.stack = var1;
      this.tickDelta = var2;
   }

   public MatrixStack getStack() {
      return this.stack;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }
}
