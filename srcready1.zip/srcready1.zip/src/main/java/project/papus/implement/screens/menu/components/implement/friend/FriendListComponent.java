package project.papus.implement.screens.menu.components.implement.friend;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.repository.friend.Friend;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.api.system.animation.Animation;
import project.papus.api.system.animation.Direction;
import project.papus.api.system.animation.implement.DecelerateAnimation;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class FriendListComponent extends AbstractComponent {
   private final Friend friend;
   private final Runnable onRemoveCallback;
   private final Animation scaleAnimation = new DecelerateAnimation().setMs(250).setValue(1.0);
   private final Animation colorAnimation = new DecelerateAnimation().setMs(250).setValue(1.0);

   public FriendListComponent(Friend var1, Runnable var2) {
      this.friend = var1;
      this.onRemoveCallback = var2;
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      this.height = 22.0F;
      this.width += 10.0F;
      boolean var6 = MathUtil.isHovered(var2, var3, this.x, this.y, this.width, this.height);
      int var7 = var6 ? ColorUtil.getColor(255, 255, 255, 15) : ColorUtil.getColor(8, 8, 8, 5);
      rectangle.render(ShapeProperties.create(var5, this.x, this.y, this.width, this.height).round(8.0F).color(var7).build());
      rectangle.renderOutline(
         ShapeProperties.create(var5, this.x, this.y, this.width, this.height).round(8.0F).softness(0.0F).outlineColor(ColorUtil.getOutlineColor()).build(),
         1.5F
      );
      Fonts.getSize(16, Fonts.Type.DEFAULT).drawString(var5, this.friend.getName(), this.x + 5.0F, this.y + 8.0F, ColorUtil.getColor(255, 255, 255, 255));
      float var8 = 16.0F;
      float var9 = this.x + this.width - var8 - 5.0F;
      float var10 = this.y + 3.0F;
      boolean var11 = MathUtil.isHovered(var2, var3, var9, var10, var8, var8);
      this.scaleAnimation.setDirection(var11 ? Direction.FORWARDS : Direction.BACKWARDS);
      float var12 = this.scaleAnimation.getOutput().floatValue();
      float var13 = 1.0F + var12 * 0.2F;
      this.colorAnimation.setDirection(var11 ? Direction.FORWARDS : Direction.BACKWARDS);
      float var14 = this.colorAnimation.getOutput().floatValue();
      var7 = ColorUtil.interpolateColor(ColorUtil.getColor(255, 255, 255, 10), ColorUtil.getColor(220, 50, 50, 120), var14);
      float var15 = var9 + var8 / 2.0F;
      float var16 = var10 + var8 / 2.0F;
      var5.push();
      var5.translate(var15, var16, 0.0F);
      var5.scale(var13, var13, 1.0F);
      var5.translate(-var15, -var16, 0.0F);
      rectangle.render(ShapeProperties.create(var5, var9, var10, var8, var8).round(5.0F).color(var7).build());
      rectangle.renderOutline(
         ShapeProperties.create(var5, var9, var10, var8, var8).round(5.0F).softness(0.0F).outlineColor(ColorUtil.getOutlineColor()).build(), 1.5F
      );
      Fonts.getSize(12, Fonts.Type.DEFAULT).drawCenteredString(var5, "X", var9 + var8 / 2.0F + 0.5F, var10 + 7.0F, -1);
      var5.pop();
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (var5 != 0) {
         return false;
      } else {
         float var6 = 16.0F;
         float var7 = this.x + this.width - var6 - 5.0F;
         float var8 = this.y + 3.0F;
         if (MathUtil.isHovered(var1, var3, var7, var8, var6, var6)) {
            FriendUtils.removeFriend(this.friend.getName());
            if (this.onRemoveCallback != null) {
               this.onRemoveCallback.run();
            }

            return true;
         } else {
            return false;
         }
      }
   }

   @Override
   public boolean isHover(double var1, double var3) {
      return MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height);
   }

   public Friend getFriend() {
      return this.friend;
   }
}
