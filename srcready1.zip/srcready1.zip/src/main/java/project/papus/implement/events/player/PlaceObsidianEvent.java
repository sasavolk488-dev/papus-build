package project.papus.implement.events.player;

import net.minecraft.block.Block;
import project.papus.api.event.events.callables.EventCancellable;

public class PlaceObsidianEvent extends EventCancellable {
   private Block block;

   public void setBlock(Block var1) {
      this.block = var1;
   }

   public Block getBlock() {
      return this.block;
   }

   public PlaceObsidianEvent(Block var1) {
      this.block = var1;
   }
}
