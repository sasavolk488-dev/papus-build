package project.papus.implement.screens.menu.components.implement.other;

import net.minecraft.client.gui.DrawContext;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class UserComponent extends AbstractComponent {
   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      return super.mouseClicked(var1, var3, var5);
   }
}
