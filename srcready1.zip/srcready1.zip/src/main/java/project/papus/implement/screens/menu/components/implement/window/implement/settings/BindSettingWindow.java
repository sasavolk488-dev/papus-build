package project.papus.implement.screens.menu.components.implement.window.implement.settings;

import project.papus.api.feature.module.setting.implement.BooleanSetting;
import project.papus.implement.screens.menu.components.implement.window.implement.module.AbstractBindWindow;

public class BindSettingWindow extends AbstractBindWindow {
   private final BooleanSetting setting;

   @Override
   protected int getKey() {
      return this.setting.getKey();
   }

   @Override
   protected void setKey(int var1) {
      this.setting.setKey(var1);
   }

   @Override
   protected int getType() {
      return this.setting.getType();
   }

   @Override
   protected void setType(int var1) {
      this.setting.setType(var1);
   }

   public BindSettingWindow(BooleanSetting var1) {
      this.setting = var1;
   }
}
