package project.papus.implement.features.modules.player;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.client.network.OtherClientPlayerEntity;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;

public class FakePlayer extends Module {
   private OtherClientPlayerEntity fakePlayer = null;
   private int fakeEntityId = 0;

   public FakePlayer() {
      super("FakePlayer", "Fake Player", ModuleCategory.PLAYER);
   }

   @Override
   public void activate() {
      if (mc.player != null && mc.world != null) {
         GameProfile var1 = new GameProfile(UUID.randomUUID(), "Papus");
         this.fakePlayer = new OtherClientPlayerEntity(mc.world, var1);
         this.fakePlayer.refreshPositionAndAngles(mc.player.getX(), mc.player.getY(), mc.player.getZ(), mc.player.getYaw(), mc.player.getPitch());
         this.fakePlayer.headYaw = mc.player.headYaw;
         this.fakePlayer.bodyYaw = mc.player.bodyYaw;

         try {
            mc.world.addEntity(this.fakePlayer);
         } catch (Exception var3) {
         }

         super.activate();
      } else {
         this.setStateQuietly(false);
      }
   }

   @Override
   public void deactivate() {
      if (this.fakePlayer != null) {
         try {
            this.fakePlayer.refreshPositionAndAngles(0.0, -999.0, 0.0, 0.0F, 0.0F);
         } catch (Exception var2) {
         }
      }

      this.fakePlayer = null;
      super.deactivate();
   }
}
