package project.papus.implement.features.modules.render;

import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.hit.EntityHitResult;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.BooleanSetting;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.other.Instance;
import project.papus.common.util.render.Render2DUtil;

public class CrossHair extends Module {
   private float animatedCooldown = 0.0F;
   private final ValueSetting attackIndentSetting = new ValueSetting("\u041e\u0442\u0441\u0442\u0443\u043f \u0410\u0442\u0430\u043a\u0438", "")
      .setValue(0.0F)
      .range(0, 20);
   private final ValueSetting offsetSetting = new ValueSetting("\u041e\u0442\u0441\u0442\u0443\u043f", "").setValue(0.0F).range(0, 5);
   private final BooleanSetting outlineSetting = new BooleanSetting("\u041e\u0431\u0432\u043e\u0434\u043a\u0430 \u043f\u0440\u0438\u0446\u0435\u043b\u0430", "");
   private final BooleanSetting redOnTargetSetting = new BooleanSetting(
      "\u041a\u0440\u0430\u0441\u043d\u0435\u0442\u044c \u043f\u0440\u0438 \u043d\u0430\u0432\u0435\u0434\u0435\u043d\u0438\u0438", ""
   );
   private final ValueSetting lengthXSetting = new ValueSetting("\u0414\u043b\u0438\u043d\u0430 X", "").setValue(3.0F).range(1, 15);
   private final ValueSetting lengthYSetting = new ValueSetting("\u0414\u043b\u0438\u043d\u0430 Y", "").setValue(3.0F).range(1, 15);
   private final ValueSetting thicknessSetting = new ValueSetting("\u0422\u043e\u043b\u0449\u0438\u043d\u0430", "").setValue(1.0F).range(1, 2);

   public static CrossHair getInstance() {
      return Instance.get(CrossHair.class);
   }

   public CrossHair() {
      super("CrossHair", "Cross Hair", ModuleCategory.RENDER);
      this.setup(
         this.attackIndentSetting,
         this.offsetSetting,
         this.outlineSetting,
         this.redOnTargetSetting,
         this.lengthXSetting,
         this.lengthYSetting,
         this.thicknessSetting
      );
   }

   public void renderCrossHair() {
      float var1 = 1.0F;
      if (this.redOnTargetSetting.isValue()) {
         if (mc.crosshairTarget instanceof EntityHitResult var2) {
            if (var2.getEntity() instanceof ArmorStandEntity) {
               var1 = 1.0F;
            } else {
               var1 = 5.0F;
            }
         } else {
            var1 = 1.0F;
         }
      } else {
         var1 = 1.0F;
      }

      this.animatedCooldown = MathUtil.interpolateSmooth(2.0, this.animatedCooldown, var1);
      int var14 = ColorUtil.saturate(ColorUtil.WHITE, this.animatedCooldown);
      int var3 = ColorUtil.BLACK;
      float var4 = window.getScaledWidth() / 2.0F;
      float var5 = window.getScaledHeight() / 2.0F;
      float var6 = this.attackIndentSetting.getInt()
         - this.attackIndentSetting.getInt() * mc.player.getAttackCooldownProgress(renderTickCounter.getTickDelta(false));
      float var7 = this.lengthXSetting.getValue();
      float var8 = this.lengthYSetting.getValue();
      float var9 = this.thicknessSetting.getValue();
      float var10 = var9 / 2.0F;
      float var11 = this.offsetSetting.getInt() + var6;
      if (this.outlineSetting.isValue()) {
         this.drawCross(var4, var5, var7, var8, var9, 1.0F, var11, var10, var3);
      }

      this.drawCross(var4, var5, var7, var8, var9, 0.0F, var11, var10, var14);
   }

   private void drawCross(float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, int var9) {
      Render2DUtil.drawQuad(var1 - var8 - var6 / 2.0F, var2 - var4 - var7 - var6 / 2.0F, var5 + var6, var4 + var6, var9);
      Render2DUtil.drawQuad(var1 - var8 - var6 / 2.0F, var2 + var7 - var6 / 2.0F, var5 + var6, var4 + var6, var9);
      Render2DUtil.drawQuad(var1 - var3 - var7 - var6 / 2.0F, var2 - var8 - var6 / 2.0F, var3 + var6, var5 + var6, var9);
      Render2DUtil.drawQuad(var1 + var7 - var6 / 2.0F, var2 - var8 - var6 / 2.0F, var3 + var6, var5 + var6, var9);
   }
}
