package project.papus.implement.features.modules.player;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.BooleanSetting;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.common.util.rotation.Angle;
import project.papus.common.util.rotation.AngleUtil;
import project.papus.implement.events.keyboard.MouseRotationEvent;

public class AimAssist extends Module {
   private final ValueSetting speedXSetting = new ValueSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c X", "").setValue(3.5F).range(0.0F, 10.0F);
   private final ValueSetting speedYSetting = new ValueSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c Y", "").setValue(3.5F).range(0.0F, 10.0F);
   private final ValueSetting distanceSetting = new ValueSetting("\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f", "").setValue(3.0F).range(2, 8);
   private final ValueSetting fovSetting = new ValueSetting("\u041f\u043e\u043b\u0435 \u0437\u0440\u0435\u043d\u0438\u044f", "")
      .setValue(180.0F)
      .range(10, 360);
   private final BooleanSetting testSetting = new BooleanSetting("Test", "").setValue(false);
   private final MultiSelectSetting targetsSetting = new MultiSelectSetting("\u0422\u0430\u0440\u0433\u0435\u0442\u044b", "")
      .value("\u0418\u0433\u0440\u043e\u043a\u0438", "\u041c\u043e\u0431\u044b", "\u0414\u0440\u0443\u0437\u044c\u044f");
   private final Random random = new Random();
   private float noiseYaw = 0.0F;
   private float noisePitch = 0.0F;
   private float speedFactor = 0.0F;
   private long lastNoiseUpdate = 0L;

   public AimAssist() {
      super("AimAssist", "Aim Assist", ModuleCategory.PLAYER);
      this.setup(this.speedXSetting, this.speedYSetting, this.distanceSetting, this.fovSetting, this.testSetting, this.targetsSetting);
      this.targetsSetting.getSelected().add("\u0418\u0433\u0440\u043e\u043a\u0438");
   }

   @EventHandler
   public void onMouseRotation(MouseRotationEvent var1) {
      if (!this.isSilent()) {
         if (mc.player != null && mc.world != null) {
            LivingEntity var2 = this.findTarget();
            if (var2 != null) {
               this.resetTarget();
               Vec3d var3 = mc.player.getPos().add(0.0, mc.player.getHeight(), 0.0);
               float var4 = 0.5F + this.noisePitch;
               float var5 = this.noiseYaw;
               Vec3d var6 = var2.getPos().add(var5, var2.getHeight() * var4, 0.0);
               Vec3d var7 = var6.subtract(var3);
               float var8 = (float)Math.toDegrees(Math.atan2(var7.z, var7.x)) - 90.0F;
               float var9 = (float)(-Math.toDegrees(Math.atan2(var7.y, Math.sqrt(var7.x * var7.x + var7.z * var7.z))));
               Angle var10 = AngleUtil.cameraAngle();
               float var11 = var8 - var10.getYaw();
               var11 = ((var11 + 180.0F) % 360.0F + 360.0F) % 360.0F - 180.0F;
               float var12 = var9 - var10.getPitch();
               var12 = ((var12 + 180.0F) % 360.0F + 360.0F) % 360.0F - 180.0F;
               if (!(Math.abs(var11) > this.fovSetting.getValue() / 2.0F)) {
                  if (this.testSetting.isValue() || !(Math.abs(var11) < 2.0F) || !(Math.abs(var12) < 2.0F)) {
                     float var13 = this.speedXSetting.getValue() / 40.0F;
                     float var14 = 20.0F;
                     var11 = MathHelper.clamp(var11, -var14, var14);
                     float var15 = var11 * var13 * 10.0F;
                     float var16 = this.speedYSetting.getValue() / 40.0F;
                     float var17 = 20.0F;
                     var12 = MathHelper.clamp(var12, -var17, var17);
                     float var18 = var12 * var16 * 10.0F;
                     var1.setCursorDeltaX(var1.getCursorDeltaX() + (int)var15);
                     var1.setCursorDeltaY(var1.getCursorDeltaY() + (int)var18);
                  }
               }
            }
         }
      }
   }

   private void resetTarget() {
      long var1 = System.currentTimeMillis();
      if (var1 - this.lastNoiseUpdate > 200L) {
         this.noiseYaw = (this.random.nextFloat() - 0.5F) * 0.4F;
         this.noisePitch = (this.random.nextFloat() - 0.5F) * 0.3F;
         this.speedFactor = 0.3F + this.random.nextFloat() * 0.7F;
         this.lastNoiseUpdate = var1;
      }

      if (!this.testSetting.isValue()) {
         this.noiseYaw = 0.0F;
         this.noisePitch = 0.0F;
      }
   }

   private LivingEntity findTarget() {
      LivingEntity var1 = null;
      float var2 = Float.MAX_VALUE;
      Angle var3 = AngleUtil.cameraAngle();

      for (Entity var5 : mc.world.getEntities()) {
         if (var5 instanceof LivingEntity var6
            && var6 != mc.player
            && var6.isAlive()
            && !(var6 instanceof ArmorStandEntity)
            && !(var6.distanceTo(mc.player) > this.distanceSetting.getValue())
            && (!(var6 instanceof PlayerEntity) || this.targetsSetting.isSelected("\u0418\u0433\u0440\u043e\u043a\u0438"))
            && (var6 instanceof PlayerEntity || this.targetsSetting.isSelected("\u041c\u043e\u0431\u044b"))) {
            if (var6 instanceof PlayerEntity) {
               boolean var7 = FriendUtils.getFriends().stream().anyMatch(var1x -> var1x.getName().equals(var6.getName().getString()));
               if (var7 && !this.targetsSetting.isSelected("\u0414\u0440\u0443\u0437\u044c\u044f")) {
                  continue;
               }
            }

            Vec3d var15 = mc.player.getPos().add(0.0, mc.player.getHeight(), 0.0);
            Vec3d var8 = var6.getPos().add(0.0, var6.getHeight() * 0.7, 0.0);
            RaycastContext var9 = new RaycastContext(var15, var8, ShapeType.COLLIDER, FluidHandling.NONE, mc.player);
            if (mc.world.raycast(var9).getType() == Type.MISS) {
               Vec3d var10 = var8.subtract(var15);
               float var11 = (float)Math.toDegrees(Math.atan2(var10.z, var10.x)) - 90.0F;
               float var12 = Math.abs(var11 - var3.getYaw());
               var12 = ((var12 + 180.0F) % 360.0F + 360.0F) % 360.0F - 180.0F;
               var12 = Math.abs(var12);
               if (!(var12 > this.fovSetting.getValue() / 2.0F)) {
                  float var13 = var6.distanceTo(mc.player);
                  float var14 = var12 + var13 * 0.5F;
                  if (var14 < var2) {
                     var2 = var14;
                     var1 = var6;
                  }
               }
            }
         }
      }

      return var1;
   }
}
