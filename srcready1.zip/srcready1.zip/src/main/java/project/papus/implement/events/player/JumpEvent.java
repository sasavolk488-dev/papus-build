package project.papus.implement.events.player;

import project.papus.api.event.events.callables.EventCancellable;

public class JumpEvent extends EventCancellable {
}
