package project.papus.implement.features.modules.player;

import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.common.util.other.Instance;
import project.papus.implement.events.block.PushEvent;

public class NoPush extends Module {
   private final MultiSelectSetting modesSetting = new MultiSelectSetting("\u0420\u0435\u0436\u0438\u043c\u044b", "")
      .value("\u0418\u0433\u0440\u043e\u043a\u0438", "\u0412\u043e\u0434\u0430", "\u0411\u043b\u043e\u043a\u0438");

   public static NoPush getInstance() {
      return Instance.get(NoPush.class);
   }

   public NoPush() {
      super("NoPush", "No Push", ModuleCategory.PLAYER);
      this.setup(this.modesSetting);
      this.modesSetting.getSelected().add("\u0418\u0433\u0440\u043e\u043a\u0438");
      this.modesSetting.getSelected().add("\u0412\u043e\u0434\u0430");
      this.modesSetting.getSelected().add("\u0411\u043b\u043e\u043a\u0438");
   }

   @EventHandler
   public void onPush(PushEvent var1) {
      if (mc.player != null) {
         PushEvent.Type var2 = var1.getType();
         if (var2 == PushEvent.Type.COLLISION && this.modesSetting.isSelected("\u0418\u0433\u0440\u043e\u043a\u0438")) {
            var1.setCancelled(true);
         }

         if (var2 == PushEvent.Type.WATER && this.modesSetting.isSelected("\u0412\u043e\u0434\u0430")) {
            var1.setCancelled(true);
         }

         if (var2 == PushEvent.Type.BLOCK && this.modesSetting.isSelected("\u0411\u043b\u043e\u043a\u0438")) {
            var1.setCancelled(true);
         }
      }
   }
}
