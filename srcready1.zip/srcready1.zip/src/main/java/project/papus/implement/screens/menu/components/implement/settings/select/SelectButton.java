package project.papus.implement.screens.menu.components.implement.settings.select;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.api.system.font.Fonts;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.implement.settings.AbstractSettingComponent;

public class SelectButton extends AbstractSettingComponent {
   private final List<SelectComponent> selectComponents = new ArrayList<>();
   private final SelectSetting setting;
   private float areaX;
   private float areaY;
   private float areaWidth;
   private float areaHeight;

   public SelectButton(SelectSetting var1) {
      super(var1);
      this.setting = var1;

      for (String var3 : var1.getList()) {
         this.selectComponents.add(new SelectComponent(var1, var3));
      }
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      float var6 = 18.0F;
      float var7 = 13.0F;
      float var8 = this.selectComponents.size() * var7;
      this.areaX = this.x + 7.0F;
      this.areaY = this.y + var6 + 2.0F;
      this.areaWidth = this.width - 16.0F;
      this.areaHeight = var8 - 6.0F;
      this.height = (int)(var6 + var8 - 12.0F);
      Fonts.getSize(15, Fonts.Type.GUI).drawString(var5, "H", this.x + 6.0F, this.y + 11.5F, ColorUtil.getColor(255, 255, 255, 255));
      Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(var5, this.setting.getName(), this.x + 19.0F, this.y + 11.0F, -2828575);
      this.renderOptions(var1, var2, var3, var4);
   }

   private void renderOptions(DrawContext var1, int var2, int var3, float var4) {
      float var5 = 13.0F;
      float var6 = this.areaY;
      float var7 = this.areaX;
      float var8 = this.areaWidth;
      float var9 = var7;
      float var10 = var6;

      for (SelectComponent var12 : this.selectComponents) {
         float var13 = Fonts.getSize(12, Fonts.Type.DEFAULT).getStringWidth(var12.getText()) + 16.0F;
         var12.width = Math.max(var13, 40.0F);
         var12.height = 14.0F;
         if (var9 + var12.width > var7 + var8) {
            var9 = var7;
            var10 += var5;
         }

         var12.x = var9;
         var12.y = var10;
         var12.setOpacity(1.0F);
         var12.render(var1, var2, var3, var4);
         var9 += var12.width + 2.0F;
      }
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (var5 == 0) {
         for (SelectComponent var7 : this.selectComponents) {
            if (var7.mouseClicked(var1, var3, var5)) {
               return true;
            }
         }
      }

      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean isHover(double var1, double var3) {
      return MathUtil.isHovered(var1, var3, this.areaX, this.areaY, this.areaWidth, this.areaHeight);
   }
}
