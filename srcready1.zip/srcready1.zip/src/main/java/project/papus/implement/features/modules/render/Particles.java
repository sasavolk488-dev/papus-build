package project.papus.implement.features.modules.render;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4i;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.other.Instance;
import project.papus.common.util.render.Render3DUtil;
import project.papus.implement.events.player.AttackEvent;
import project.papus.implement.events.player.TickEvent;
import project.papus.implement.events.render.WorldRenderEvent;

public class Particles extends Module {
   private final ValueSetting speedSetting = new ValueSetting("\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", "")
      .setValue(1.0F)
      .range(1, 2)
      .visible(() -> false);
   private final SelectSetting typeSetting = new SelectSetting("\u0422\u0438\u043f", "")
      .value("\u0421\u0435\u0440\u0434\u0446\u0430", "\u0421\u043d\u0435\u0436\u0438\u043d\u043a\u0438", "\u0417\u0432\u0451\u0437\u0434\u044b")
      .selected("\u0417\u0432\u0451\u0437\u0434\u044b");
   private final List<Particles.Particle> particles = new ArrayList<>();

   public static Particles getInstance() {
      return Instance.get(Particles.class);
   }

   public Particles() {
      super("HitParticles", "Hit Particles", ModuleCategory.RENDER);
      this.setup(this.typeSetting, this.speedSetting);
   }

   private int getCount() {
      return 8;
   }

   private float getSize() {
      return 1.5F;
   }

   private long getLifeTime() {
      return 1455L;
   }

   private float getSpread() {
      return 1.0F;
   }

   private float getAlphaMultiplier() {
      return 3.0F;
   }

   private void clear() {
      this.particles.clear();
   }

   @Override
   public void deactivate() {
      this.clear();
      super.deactivate();
   }

   @EventHandler
   public void onAttack(AttackEvent var1) {
      Entity var2 = var1.getEntity();
      if (!(var2 instanceof ArmorStandEntity)) {
         if (var2 != null) {
            float var3 = this.getSpread();

            for (int var4 = 0; var4 < this.getCount(); var4++) {
               this.spawnParticle(
                  this.particles,
                  new Vec3d(var2.getX(), var2.getY() + this.randomRange(0.0, var2.getHeight()), var2.getZ()),
                  new Vec3d(this.randomRange(-var3, var3), this.randomRange(-var3, var3 / 4.0F), this.randomRange(-var3, var3))
               );
            }
         }
      }
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      if (mc.player != null && mc.world != null) {
         this.removeExpiredParticles(this.particles, this.getLifeTime());
      }
   }

   @EventHandler
   public void onWorldRender(WorldRenderEvent var1) {
      if (this.isState()) {
         MatrixStack var2 = var1.getStack();
         this.renderParticles(var2, this.particles, var1.getTickDelta());
      }
   }

   private void removeExpiredParticles(List<Particles.Particle> var1, long var2) {
      var1.removeIf(var2x -> System.currentTimeMillis() - var2x.getSpawnTime() > var2);
   }

   private void renderParticles(MatrixStack var1, List<Particles.Particle> var2, float var3) {
      if (!var2.isEmpty()) {
         var1.push();

         for (Particles.Particle var5 : var2) {
            var5.update();
            long var6 = this.getLifeTime();
            float var8 = this.getAlphaMultiplier();
            long var9 = System.currentTimeMillis() - var5.getSpawnTime();
            float var11 = Math.max(0.1F, 1.0F - (float)var9 / (float)var6);
            int var12 = ColorUtil.getColor(255, 255, 255, (int)(var11 * var8 * 255.0F));
            Vec3d var13 = var5.getPos();
            float var14 = (float)var13.x;
            float var15 = (float)var13.y;
            float var16 = (float)var13.z;
            this.renderParticle(var1, var5, var14, var15, var16, var5.scale, var12, var3);
         }

         var1.pop();
      }
   }

   private void renderParticle(MatrixStack var1, Particles.Particle var2, float var3, float var4, float var5, float var6, int var7, float var8) {
      Camera var9 = mc.gameRenderer.getCamera();
      Vec3d var10 = var9.getPos();
      double var11 = var3 - var10.x;
      double var13 = var4 - var10.y;
      double var15 = var5 - var10.z;
      MatrixStack var17 = new MatrixStack();
      var17.push();
      var17.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var9.getPitch()));
      var17.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var9.getYaw() + 180.0F));
      var17.translate(var11, var13, var15);
      var17.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-var9.getYaw()));
      var17.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var9.getPitch()));
      if (var2.getType() != Particles.ParticleType.star) {
         var17.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180.0F));
      }

      if (var2.getType() == Particles.ParticleType.heart) {
         var17.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(90.0F));
      }

      if (var2.getType().isRotatable()) {
         var17.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var2.getRotationSpeed()));
      }

      var17.translate(0.0F, -var6, 0.0F);
      Render3DUtil.drawTexture(var17.peek(), var2.getType().getTexture(), -var6, -var6, var6 * 2.0F, var6 * 2.0F, new Vector4i(var7), true);
      var17.pop();
   }

   private void spawnParticle(List<Particles.Particle> var1, Vec3d var2, Vec3d var3) {
      float var4 = 0.05F + this.getSize() * 0.2F;
      int var5 = ColorUtil.getColor(255, 255, 255, 255);
      String var6 = this.typeSetting.getSelected();

      Particles.ParticleType var7 = switch (var6) {
         case "\u0421\u0435\u0440\u0434\u0446\u0430" -> Particles.ParticleType.heart;
         case "\u0421\u043d\u0435\u0436\u0438\u043d\u043a\u0438" -> Particles.ParticleType.snowflake;
         case "\u0417\u0432\u0451\u0437\u0434\u044b" -> Particles.ParticleType.star;
         default -> Particles.ParticleType.star;
      };
      Vec3d var8 = var3.multiply(0.08F);
      Particles.Particle var10 = new Particles.Particle(
         var7, var2.add(0.0, var4, 0.0), var8, var1.size(), (int)(Math.round(this.randomRange(0.0, 360.0) / 15.0) * 15L), var5, var4
      );
      var1.add(var10);
   }

   private double randomRange(double var1, double var3) {
      Random var5 = new Random();
      return var1 + (var3 - var1) * var5.nextDouble();
   }

   public static class Particle {
      private final Particles.ParticleType type;
      private Vec3d pos;
      private final Vec3d velocity;
      private final int color;
      private final int rotationSpeed;
      private final int fadeAlpha;
      public final float scale;
      private final long spawnTime;
      private Vec3d prevPos;
      private Vec3d renderPos;
      private Vec3d motion;

      public Particle(Particles.ParticleType var1, Vec3d var2, Vec3d var3, int var4, int var5, int var6, float var7) {
         this.type = var1;
         this.pos = var2;
         this.velocity = var3;
         this.color = var4;
         this.rotationSpeed = var5;
         this.fadeAlpha = var6;
         this.scale = var7;
         this.spawnTime = System.currentTimeMillis();
         this.prevPos = var2;
         this.renderPos = new Vec3d(0.0, 0.0, 0.0);
         this.motion = new Vec3d(0.0, 0.0, 0.0);
      }

      public void update() {
         this.prevPos = this.pos;
         this.motion = this.renderPos;
         Vec3d var1 = this.velocity.multiply(0.3);
         this.pos = this.pos.add(var1);
         this.renderPos = this.renderPos.add(0.01, 0.01, 0.01);
      }

      public Particles.ParticleType getType() {
         return this.type;
      }

      public Vec3d getPos() {
         return this.pos;
      }

      public Vec3d getPrevPos() {
         return this.prevPos != null ? this.prevPos : this.pos;
      }

      public Vec3d getOffset() {
         return this.renderPos != null ? this.renderPos : new Vec3d(0.0, 0.0, 0.0);
      }

      public Vec3d getPrevOffset() {
         return this.motion != null ? this.motion : this.getOffset();
      }

      public int getRotationSpeed() {
         return this.rotationSpeed;
      }

      public long getSpawnTime() {
         return this.spawnTime;
      }
   }

   public static enum ParticleType {
      star("star", true),
      heart("heart", true),
      snowflake("snow", true);

      private final String textureName;
      private final boolean rotatable;

      private ParticleType(String var3, boolean var4) {
         this.textureName = var3;
         this.rotatable = var4;
      }

      public Identifier getTexture() {
         return Identifier.of("papus", "textures/particles/" + this.textureName + ".png");
      }

      public boolean isRotatable() {
         return this.rotatable;
      }
   }
}
