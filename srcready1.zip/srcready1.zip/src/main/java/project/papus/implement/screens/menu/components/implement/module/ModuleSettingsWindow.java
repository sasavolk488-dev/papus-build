package project.papus.implement.screens.menu.components.implement.module;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.setting.SettingComponentAdder;
import project.papus.api.system.animation.Animation;
import project.papus.api.system.animation.Direction;
import project.papus.api.system.animation.implement.DecelerateAnimation;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.render.ScissorManager;
import project.papus.core.Main;
import project.papus.implement.screens.menu.components.implement.settings.AbstractSettingComponent;
import project.papus.implement.screens.menu.components.implement.window.AbstractWindow;

public class ModuleSettingsWindow extends AbstractWindow {
   private final List<AbstractSettingComponent> components = new ArrayList<>();
   public final Module module;
   private final Animation scaleAnimation = new DecelerateAnimation().setMs(150).setValue(1.0);

   public ModuleSettingsWindow(Module var1) {
      this.module = var1;
      new SettingComponentAdder().addSettingComponent(var1.settings(), this.components);
      this.setDraggable(false);
      this.scaleAnimation.setDirection(Direction.FORWARDS);
   }

   @Override
   public void startCloseAnimation() {
      this.scaleAnimation.setDirection(Direction.BACKWARDS);
   }

   @Override
   public boolean isCloseAnimationFinished() {
      return this.scaleAnimation.isFinished(Direction.BACKWARDS);
   }

   @Override
   public void renderWindow(DrawContext var1, int var2, int var3, float var4) {
      if (!this.scaleAnimation.isFinished(Direction.BACKWARDS)) {
         float var5 = this.scaleAnimation.getOutput().floatValue();
         if (!(var5 <= 0.01F)) {
            MatrixStack var6 = var1.getMatrices();
            ScissorManager var7 = Main.getInstance().getScissorManager();
            this.height = MathHelper.clamp(this.getComponentHeight() + 8, 0, 200);
            float var8 = this.x + this.width / 2.0F;
            float var9 = this.y + this.height / 2.0F;
            var6.push();
            var6.translate(var8, var9, 0.0);
            var6.scale(var5, var5, 1.0F);
            var6.translate(-var8, -var9, 0.0);
            blur.render(
               ShapeProperties.create(var6, this.x, this.y + 18.0F, this.width + 1.5F, this.height - 18.0F)
                  .round(11.0F)
                  .softness(2.0F)
                  .quality(20.0F)
                  .color(ColorUtil.getColor(12, 4, 18, 245))
                  .build()
            );
            boolean var10 = MathHelper.clamp(this.height, 0.0F, 200.0F) == 200.0F;
            if (var10) {
               var7.push(var6.peek().getPositionMatrix(), this.x, this.y + 22.0F, this.width, this.height - 24.0F);
            }

            float var11 = 0.0F;
            int var12 = 0;

            for (int var13 = this.components.size() - 1; var13 >= 0; var13--) {
               AbstractSettingComponent var14 = this.components.get(var13);
               Supplier var15 = var14.getSetting().getVisible();
               if (var15 == null || (Boolean)var15.get()) {
                  var14.x = this.x;
                  var14.y = (float)(this.y + 24.0F + var11 + (this.getComponentHeight() - 25 - var14.height) + this.smoothedScroll);
                  var14.width = this.width;
                  var14.render(var1, var2, var3, var4);
                  var11 -= var14.height;
                  var12 += (int)var14.height;
               }
            }

            if (var10) {
               var7.pop();
            }

            int var16 = (int)Math.max(0.0F, var12 - (this.height - 30.0F));
            this.scroll = MathHelper.clamp(this.scroll, -var16, 0.0);
            this.smoothedScroll = MathUtil.interpolateSmooth(10.0, this.smoothedScroll, this.scroll);
            var6.pop();
         }
      }
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      for (AbstractSettingComponent var7 : this.components) {
         if (var7.isHover(var1, var3)) {
            var7.mouseClicked(var1, var3, var5);
            return true;
         }
      }

      return false;
   }

   @Override
   public boolean isHover(double var1, double var3) {
      for (AbstractSettingComponent var6 : this.components) {
         if (var6.isHover(var1, var3)) {
            return true;
         }
      }

      return super.isHovered(var1, var3);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.components.forEach(var5x -> var5x.mouseReleased(var1, var3, var5));
      return super.mouseReleased(var1, var3, var5);
   }

   @Override
   public boolean mouseScrolled(double var1, double var3, double var5) {
      this.scroll += var5 * 15.0;
      return true;
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      for (AbstractSettingComponent var5 : this.components) {
         if (var5.keyPressed(var1, var2, var3)) {
            return true;
         }
      }

      return super.keyPressed(var1, var2, var3);
   }

   @Override
   public boolean charTyped(char var1, int var2) {
      this.components.forEach(var2x -> var2x.charTyped(var1, var2));
      return super.charTyped(var1, var2);
   }

   public int getComponentHeight() {
      float var1 = 0.0F;

      for (AbstractSettingComponent var3 : this.components) {
         Supplier var4 = var3.getSetting().getVisible();
         if (var4 == null || (Boolean)var4.get()) {
            var1 += var3.height;
         }
      }

      return (int)(var1 + 24.0F);
   }
}
