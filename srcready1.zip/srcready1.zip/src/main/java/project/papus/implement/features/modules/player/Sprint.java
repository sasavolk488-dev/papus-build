package project.papus.implement.features.modules.player;

import net.minecraft.entity.effect.StatusEffects;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.common.util.other.Instance;
import project.papus.implement.events.player.ListsCheckEvent;
import project.papus.implement.events.player.TickEvent;
import project.papus.implement.events.render.WorldLoadEvent;

public class Sprint extends Module {
   private int waterTicks = 0;
   private boolean inWater = false;
   private long sprintStopTime = 0L;

   public static Sprint getInstance() {
      return Instance.get(Sprint.class);
   }

   public Sprint() {
      super("Sprint", "Sprint", ModuleCategory.PLAYER);
   }

   @EventHandler
   public void onWorldLoad(WorldLoadEvent var1) {
      this.waterTicks = 3;
      this.inWater = false;
      this.sprintStopTime = 0L;
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      if (mc.player != null) {
         if (this.inWater) {
            if (System.currentTimeMillis() - this.sprintStopTime < 0L) {
               return;
            }

            this.inWater = false;
         }

         boolean var2 = mc.player.horizontalCollision && !mc.player.collidedSoftly;
         boolean var3 = mc.player.isSneaking() && !mc.player.isSwimming();
         if (this.waterTicks > 0 || var3) {
            mc.player.setSprinting(false);
         } else if (this.hasMovement() && !var2 && !mc.options.sprintKey.isPressed()) {
            mc.player.setSprinting(true);
         }

         this.waterTicks--;
      }
   }

   @EventHandler
   public void onListsCheck(ListsCheckEvent var1) {
      if (mc.player != null) {
         this.inWater = true;
         this.sprintStopTime = System.currentTimeMillis();
      }
   }

   private boolean hasMovement() {
      if (mc.player == null) {
         return false;
      } else {
         boolean var1 = mc.player.hasStatusEffect(StatusEffects.BLINDNESS);
         return !mc.player.isSprinting() && mc.player.input.hasForwardMovement() && !var1 && !mc.player.isGliding();
      }
   }
}
