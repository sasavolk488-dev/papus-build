package project.papus.implement.events.chat;

import project.papus.api.event.events.callables.EventCancellable;

public class TabCompleteEvent extends EventCancellable {
   public final String prefix;
   public String[] completions;

   public TabCompleteEvent(String var1) {
      this.prefix = var1;
      this.completions = null;
   }
}
