package project.papus.implement.screens.menu.components.implement.module;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.ColorHelper;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.setting.SettingComponentAdder;
import project.papus.api.system.animation.Animation;
import project.papus.api.system.animation.Direction;
import project.papus.api.system.animation.implement.DecelerateAnimation;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.other.StringUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;
import project.papus.implement.screens.menu.components.implement.other.SwitchComponent;
import project.papus.implement.screens.menu.components.implement.settings.AbstractSettingComponent;

public class ModuleComponent extends AbstractComponent {
   private final List<AbstractSettingComponent> components = new ArrayList<>();
   private final SwitchComponent switchComponent = new SwitchComponent();
   private final Module module;
   private boolean binding;
   private final Animation offsetAnimation = new DecelerateAnimation().setMs(400).setValue(9.0);
   private final Animation alphaAnimation = new DecelerateAnimation().setMs(400).setValue(105.0);

   public ModuleComponent(Module var1) {
      this.module = var1;
      new SettingComponentAdder().addSettingComponent(var1.settings(), this.components);
      this.offsetAnimation.setDirection(var1.isState() ? Direction.FORWARDS : Direction.BACKWARDS);
      this.alphaAnimation.setDirection(var1.isState() ? Direction.FORWARDS : Direction.BACKWARDS);
      this.offsetAnimation.reset();
      this.alphaAnimation.reset();
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      String var5 = ModuleDescription.getDescription(this.module);
      this.offsetAnimation.setDirection(this.module.isState() ? Direction.FORWARDS : Direction.BACKWARDS);
      this.alphaAnimation.setDirection(this.module.isState() ? Direction.FORWARDS : Direction.BACKWARDS);
      int var6 = 150 + this.alphaAnimation.getOutput().intValue();
      this.height = 25.0F;
      rectangle.render(
         ShapeProperties.create(var1.getMatrices(), this.x, this.y, this.width, this.height).round(6.0F).color(ColorUtil.getColor(255, 255, 255, 10)).build()
      );
      rectangle.renderOutline(
         ShapeProperties.create(var1.getMatrices(), this.x, this.y, this.width, this.height)
            .round(6.0F)
            .softness(0.0F)
            .outlineColor(ColorUtil.getOutlineColor())
            .build(),
         1.5F
      );
      this.switchComponent.x = this.x + this.width - 24.0F;
      this.switchComponent.y = this.y + 8.0F;
      this.switchComponent.setSwitchSize(18.0F, 9.0F);
      this.switchComponent.setAction(this.module::switchState);
      this.switchComponent.setState(this.module.isState());
      this.switchComponent.render(var1, var2, var3, var4);
      String var7 = this.isBindHidden() ? "N/A" : StringUtil.getShortBindName(this.module.getKey());
      String var8 = this.binding ? "Press any key..." : this.module.getVisibleName();
      float var9 = -0.5F;
      Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(var1.getMatrices(), var8, this.x + 7.0F, this.y + 7.0F, new Color(255, 255, 255, var6).getRGB());
      Fonts.getSize(14, Fonts.Type.DEFAULT)
         .drawString(var1.getMatrices(), "Bind: " + var7, this.x + 7.0F, this.y + 15.0F, new Color(255, 255, 255, var6).getRGB());
   }

   private boolean isBindHidden() {
      String var1 = this.module.getName();
      return "CustomScoreboard".equals(var1);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      System.out.println("[Module] mouseClicked: button=" + var5 + " binding=" + this.binding + " module=" + this.module.getName());
      if (var5 == 2 && !this.isBindHidden()) {
         this.binding = !this.binding;
         System.out.println("[Module] Binding toggled: " + this.binding);
         return true;
      } else if (var5 == 1 && !this.module.settings().isEmpty()) {
         boolean var6 = windowManager.getWindows()
            .stream()
            .anyMatch(var1x -> var1x instanceof ModuleSettingsWindow && ((ModuleSettingsWindow)var1x).module.equals(this.module));
         if (!var6) {
            windowManager.getWindows()
               .stream()
               .filter(var0 -> var0 instanceof ModuleSettingsWindow)
               .forEach(var0 -> ((ModuleSettingsWindow)var0).startCloseAnimation());
            ModuleSettingsWindow var7 = new ModuleSettingsWindow(this.module);
            short var8 = 420;
            short var9 = 280;
            int var10 = mc.getWindow().getScaledWidth() / 2 - var8 / 2;
            int var11 = mc.getWindow().getScaledHeight() / 2 - var9 / 2;
            var7.position(var10 + var8 - 30, var11 + 35).size(160.0F, (float)var7.getComponentHeight());
            windowManager.add(var7);
         }

         return true;
      } else if (this.binding && var5 != 2) {
         this.module.setKey(var5);
         this.binding = false;
         return true;
      } else if (var5 == 0) {
         this.switchComponent.mouseClicked(var1, var3, var5);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean isHover(double var1, double var3) {
      return MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height);
   }

   @Override
   public void tick() {
      this.components.forEach(AbstractComponent::tick);
      super.tick();
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      if (this.binding) {
         if (var1 == 256) {
            this.module.setKey(-1);
            this.binding = false;
            return true;
         } else {
            int var4 = var1 != 261 ? var1 : -1;
            this.module.setKey(var4);
            this.binding = false;
            return true;
         }
      } else {
         return super.keyPressed(var1, var2, var3);
      }
   }

   public int getComponentHeight() {
      return 25;
   }

   private void renderBind(DrawContext var1, float var2) {
      String var3 = StringUtil.getShortBindName(this.module.getKey());
      String var4 = this.binding ? "..." : var3;
      float var5 = this.module.getKey() < 0 && !this.binding ? 10.0F : Fonts.getSize(12, Fonts.Type.DEFAULT).getStringWidth(var4);
      float var6 = this.x + this.width - 37.5F - var5;
      float var7 = this.y + var2 + 6.0F + 23.75F;
      rectangle.render(
         ShapeProperties.create(var1.getMatrices(), var6 + 0.25F, var7, var5 + 6.0F, 10.0)
            .round(4.0F)
            .outlineColor(new Color(155, 155, 165, 255).getRGB())
            .color(
               new Color(61, 67, 71, 80).getRGB(), new Color(71, 77, 81, 80).getRGB(), new Color(81, 87, 91, 80).getRGB(), new Color(91, 97, 101, 80).getRGB()
            )
            .build()
      );
      int var8 = ColorHelper.getArgb(255, 135, 136, 148);
      float var9 = this.x + this.width - 34.5F - var5;
      float var10 = this.y + var2 + 6.0F + 28.0F;
      if (this.module.getKey() >= 0 || this.binding) {
         Fonts.getSize(12, Fonts.Type.DEFAULT).drawString(var1.getMatrices(), var4, var9, var10, var8);
      }
   }

   @Override
   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         ModuleComponent var2 = (ModuleComponent)var1;
         return this.module.equals(var2.module);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.module);
   }

   public List<AbstractSettingComponent> getComponents() {
      return this.components;
   }

   public SwitchComponent getSwitchComponent() {
      return this.switchComponent;
   }

   public Module getModule() {
      return this.module;
   }

   public boolean isBinding() {
      return this.binding;
   }

   public Animation getOffsetAnimation() {
      return this.offsetAnimation;
   }

   public Animation getAlphaAnimation() {
      return this.alphaAnimation;
   }
}
