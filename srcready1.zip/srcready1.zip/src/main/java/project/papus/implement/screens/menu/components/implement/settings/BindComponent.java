package project.papus.implement.screens.menu.components.implement.settings;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ColorHelper;
import project.papus.api.feature.module.setting.implement.BindSetting;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.other.StringUtil;

public class BindComponent extends AbstractSettingComponent {
   private final BindSetting setting;
   private boolean binding;

   public BindComponent(BindSetting var1) {
      super(var1);
      this.setting = var1;
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      String var6 = StringUtil.getShortBindName(this.setting.getKey());
      String var7 = this.binding ? "(" + var6 + ") ..." : var6;
      float var8 = Fonts.getSize(13, Fonts.Type.BOLD).getStringWidth(var7) - 2.0F;
      this.height = 18.0F;
      rectangle.renderOutline(
         ShapeProperties.create(var5, this.x + this.width - var8 - 17.0F, this.y + 5.0F, var8 + 10.0F, 12.0)
            .round(4.0F)
            .thickness(2.0F)
            .outlineColor(ColorUtil.getOutlineColor())
            .color(ColorUtil.getClientColor(1.0F))
            .build(),
         1.5F
      );
      int var9 = ColorHelper.getArgb(255, 135, 136, 148);
      Fonts.getSize(13, Fonts.Type.BOLD).drawString(var5, var7, this.x + this.width - 12.0F - var8 - 1.0F, this.y + 9.5, var9);
      Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(var5, this.setting.getName(), this.x + 12.0F, this.y + 9.5F, -2828575);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (var5 == 0) {
         if (MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height)) {
            this.binding = !this.binding;
         } else {
            this.binding = false;
         }
      }

      if (this.binding && var5 > 1) {
         this.setting.setKey(var5);
         this.binding = false;
      }

      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      int var4 = var1 != 261 && var1 != 256 ? var1 : -1;
      if (this.binding) {
         this.setting.setKey(var4);
         this.binding = false;
         if (var1 == 256) {
            return true;
         }
      }

      return super.keyPressed(var1, var2, var3);
   }
}
