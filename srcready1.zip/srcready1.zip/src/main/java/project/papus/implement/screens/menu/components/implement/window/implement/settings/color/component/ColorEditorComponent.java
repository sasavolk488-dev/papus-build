package project.papus.implement.screens.menu.components.implement.window.implement.settings.color.component;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import project.papus.api.feature.module.setting.implement.ColorSetting;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class ColorEditorComponent extends AbstractComponent {
   private final ColorSetting setting;

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      rectangle.render(
         ShapeProperties.create(var5, this.x + 6.0F, this.y + 90.5F, 31.0, 14.0)
            .round(1.5F)
            .thickness(2.0F)
            .outlineColor(ColorUtil.getSecondaryGuiColor(0.8F))
            .color(ColorUtil.getFriendColor(1.0F))
            .build()
      );
      Fonts.getSize(13).drawString(var1.getMatrices(), "HEX", this.x + 10.0F, this.y + 96.0F, -1);
      rectangle.render(
         ShapeProperties.create(var5, this.x + 40.0F, this.y + 90.5F, 80.0, 14.0)
            .round(1.5F)
            .thickness(2.0F)
            .outlineColor(ColorUtil.getSecondaryGuiColor(0.8F))
            .color(ColorUtil.getFriendColor(1.0F))
            .build()
      );
      Fonts.getSize(13).drawString(var1.getMatrices(), "#" + Integer.toHexString(this.setting.getColor()), this.x + 45.0F, this.y + 96.0F, -1);
      rectangle.render(
         ShapeProperties.create(var5, this.x + 122.0F, this.y + 90.5F, 22.0, 14.0)
            .round(1.5F)
            .thickness(2.0F)
            .outlineColor(ColorUtil.getSecondaryGuiColor(0.8F))
            .color(ColorUtil.getFriendColor(1.0F))
            .build()
      );
      int var6 = (int)(this.setting.getAlpha() * 100.0F);
      Fonts.getSize(13).drawCenteredString(var1.getMatrices(), var6 + "%", this.x + 133.0F, this.y + 96.0F, -1);
   }

   @Override
   public boolean mouseScrolled(double var1, double var3, double var5) {
      if (MathUtil.isHovered(var1, var3, this.x + 122.0F, this.y + 90.5F, 22.0, 14.0)) {
         this.setting.setAlpha(MathHelper.clamp((float)(this.setting.getAlpha() - var5 * 2.0 / 100.0), 0.0F, 1.0F));
      }

      return super.mouseScrolled(var1, var3, var5);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      return super.mouseReleased(var1, var3, var5);
   }

   public ColorEditorComponent(ColorSetting var1) {
      this.setting = var1;
   }
}
