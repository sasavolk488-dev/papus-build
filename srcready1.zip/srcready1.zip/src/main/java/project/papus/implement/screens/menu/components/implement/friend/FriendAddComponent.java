package project.papus.implement.screens.menu.components.implement.friend;

import java.awt.Color;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class FriendAddComponent extends AbstractComponent {
   private String nickname = "";
   private boolean focused = false;
   private final Runnable onAddCallback;
   private static final float HEIGHT = 25.0F;
   private static final float SPACING = 5.0F;
   private static final float INPUT_WIDTH = 150.0F;
   private static final float BUTTON_WIDTH = 50.0F;

   public FriendAddComponent(Runnable var1) {
      this.onAddCallback = var1;
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      this.height = 25.0F;
      this.renderInputField(var5, this.x, this.y, 150.0F, 25.0F, this.nickname.isEmpty() ? "Nickname" : this.nickname, this.focused);
      float var6 = this.x + 150.0F + 5.0F;
      this.renderAddButton(var5, var6, this.y, 50.0F, 25.0F, var2, var3);
   }

   private void renderInputField(MatrixStack var1, float var2, float var3, float var4, float var5, String var6, boolean var7) {
      int var8 = var7 ? ColorUtil.getColor(255, 255, 255, 15) : ColorUtil.getColor(255, 255, 255, 5);
      int var9 = var7 ? ColorUtil.getColor(255, 255, 255, 35) : ColorUtil.getOutlineColor();
      rectangle.render(ShapeProperties.create(var1, var2, var3, var4, var5).round(8.0F).color(var8).build());
      rectangle.renderOutline(ShapeProperties.create(var1, var2, var3, var4, var5).round(8.0F).softness(0.0F).outlineColor(var9).build(), 1.5F);
      int var10 = var6.equals("Nickname") ? new Color(150, 150, 150, 180).getRGB() : -2828575;
      Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(var1, var6, var2 + 10.0F, var3 + var5 / 2.0F - 2.0F, var10);
   }

   private void renderAddButton(MatrixStack var1, float var2, float var3, float var4, float var5, int var6, int var7) {
      boolean var8 = MathUtil.isHovered(var6, var7, var2, var3, var4, var5);
      int var9 = var8 ? ColorUtil.getColor(255, 255, 255, 15) : ColorUtil.getColor(255, 255, 255, 5);
      rectangle.render(ShapeProperties.create(var1, var2, var3, var4, var5).round(8.0F).color(var9).build());
      rectangle.renderOutline(
         ShapeProperties.create(var1, var2, var3, var4, var5).round(8.0F).softness(0.0F).outlineColor(ColorUtil.getOutlineColor()).build(), 1.5F
      );
      Fonts.getSize(14, Fonts.Type.DEFAULT).drawCenteredString(var1, "Add", var2 + var4 / 2.0F, var3 + var5 / 2.0F - 2.0F, -2828575);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (var5 != 0) {
         return false;
      } else if (MathUtil.isHovered(var1, var3, this.x, this.y, 150.0, 25.0)) {
         this.focused = true;
         return true;
      } else {
         float var6 = this.x + 150.0F + 5.0F;
         if (MathUtil.isHovered(var1, var3, var6, this.y, 50.0, 25.0)) {
            if (!this.nickname.isEmpty()) {
               FriendUtils.addFriend(this.nickname);
               this.nickname = "";
               this.focused = false;
               if (this.onAddCallback != null) {
                  this.onAddCallback.run();
               }
            }

            return true;
         } else {
            this.focused = false;
            return false;
         }
      }
   }

   @Override
   public boolean charTyped(char var1, int var2) {
      if (!this.focused) {
         return false;
      } else {
         if ((Character.isLetterOrDigit(var1) || var1 == '_') && this.nickname.length() < 16) {
            this.nickname = this.nickname + var1;
         }

         return true;
      }
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      if (!this.focused) {
         return false;
      } else if (var1 == 259) {
         if (!this.nickname.isEmpty()) {
            this.nickname = this.nickname.substring(0, this.nickname.length() - 1);
         }

         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean isHover(double var1, double var3) {
      return MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height);
   }
}
