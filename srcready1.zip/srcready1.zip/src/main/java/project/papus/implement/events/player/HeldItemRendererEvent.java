package project.papus.implement.events.player;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;
import project.papus.api.event.events.Event;

public class HeldItemRendererEvent implements Event {
   public Hand hand;
   public MatrixStack matrices;

   public HeldItemRendererEvent(Hand var1, MatrixStack var2) {
      this.hand = var1;
      this.matrices = var2;
   }

   public Hand getHand() {
      return this.hand;
   }

   public MatrixStack getMatrices() {
      return this.matrices;
   }

   public void setHand(Hand var1) {
      this.hand = var1;
   }

   public void setMatrices(MatrixStack var1) {
      this.matrices = var1;
   }
}
