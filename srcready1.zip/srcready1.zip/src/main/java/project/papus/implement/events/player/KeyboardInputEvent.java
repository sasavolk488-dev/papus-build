package project.papus.implement.events.player;

import net.minecraft.util.PlayerInput;
import project.papus.api.event.events.callables.EventCancellable;

public class KeyboardInputEvent extends EventCancellable {
   private PlayerInput playerInput;

   public void setJumping(boolean var1) {
      this.playerInput = new PlayerInput(
         this.playerInput.forward(),
         this.playerInput.backward(),
         this.playerInput.left(),
         this.playerInput.right(),
         var1,
         this.playerInput.sneak(),
         this.playerInput.sprint()
      );
   }

   public void setDirectional(boolean var1, boolean var2, boolean var3, boolean var4) {
      this.playerInput = new PlayerInput(var1, var2, var3, var4, this.playerInput.jump(), this.playerInput.sneak(), this.playerInput.sprint());
   }

   public void resetDirectional() {
      this.playerInput = new PlayerInput(false, false, false, false, false, false, false);
   }

   public int forwardImpulse() {
      return this.playerInput.forward() ? 1 : (this.playerInput.backward() ? -1 : 0);
   }

   public float sidewaysImpulse() {
      return this.playerInput.left() ? 1.0F : (this.playerInput.right() ? -1.0F : 0.0F);
   }

   public PlayerInput getPlayerInput() {
      return this.playerInput;
   }

   public void setPlayerInput(PlayerInput var1) {
      this.playerInput = var1;
   }

   public KeyboardInputEvent(PlayerInput var1) {
      this.playerInput = var1;
   }
}
