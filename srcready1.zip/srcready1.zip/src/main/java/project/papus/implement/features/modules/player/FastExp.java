package project.papus.implement.features.modules.player;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.implement.events.player.TickEvent;

public class FastExp extends Module {
   private final ValueSetting delaySetting = new ValueSetting("\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430", "z").setValue(0.0F).range(0.0F, 100.0F);
   private long lastThrowTime = 0L;

   public FastExp() {
      super("FastExp", "Fast Exp", ModuleCategory.PLAYER);
      this.setup(this.delaySetting);
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      if (mc.player != null) {
         if (mc.currentScreen == null) {
            if (mc.options.useKey.isPressed()) {
               if (this.isHoldingExperienceBottle()) {
                  long var2 = System.currentTimeMillis();
                  if (var2 - this.lastThrowTime >= (long)this.delaySetting.getValue()) {
                     mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                     mc.player.swingHand(Hand.MAIN_HAND);
                     this.lastThrowTime = var2;
                  }
               }
            }
         }
      }
   }

   private boolean isHoldingExperienceBottle() {
      ItemStack var1 = mc.player.getEquippedStack(EquipmentSlot.MAINHAND);
      if (var1.isEmpty()) {
         return false;
      } else {
         String var2 = var1.getItem().toString().toLowerCase();
         return var2.contains("experience_bottle") || var2.contains("bottle_o_enchanting");
      }
   }
}
