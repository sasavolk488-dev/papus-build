package project.papus.implement.screens.menu.components.implement.other;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.implement.screens.menu.MenuScreen;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class CategorySidebarComponent extends AbstractComponent {
   private final String[] icons = new String[]{"D", "B", "C", "G"};
   private final ModuleCategory[] categories = new ModuleCategory[]{ModuleCategory.RENDER, ModuleCategory.PLAYER, ModuleCategory.MISC, ModuleCategory.FRIEND};
   private static final float ICON_HITBOX_SIZE = 10.0F;

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      MenuScreen var6 = MenuScreen.getInstance();
      float var7 = 20.0F;
      float var8 = 23.0F;
      float var9 = this.y + 8.0F;
      float var10 = this.x + 8.0F;
      rectangle.render(
         ShapeProperties.create(var5, this.x - 2.0F, this.y - 2.0F, this.width - 1.0F, this.height - 35.0F)
            .round(8.0F)
            .softness(1.0F)
            .quality(15.0F)
            .color(ColorUtil.getColor(12, 4, 18, 250))
            .build()
      );

      for (int var11 = 0; var11 < this.icons.length; var11++) {
         float var12 = var9 + var11 * var8;
         boolean var13 = var6.getCategory() == this.categories[var11];
         float var14 = var10 - 2.0F;
         float var15 = var12 - 2.0F;
         boolean var16 = var2 >= var14 && var2 <= var14 + 10.0F && var3 >= var15 && var3 <= var15 + 10.0F;
         int var17;
         if (var13) {
            var17 = ColorUtil.getColor(255, 255, 255, 255);
         } else if (var16) {
            var17 = ColorUtil.getColor(170, 170, 170, 230);
         } else {
            var17 = ColorUtil.getColor(150, 150, 150, 180);
         }

         Fonts.getSize((int)var7, Fonts.Type.GUI).drawString(var5, this.icons[var11], var10, var12, var17);
      }
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      float var6 = 23.0F;
      float var7 = this.y + 8.0F;
      float var8 = this.x + 8.0F;

      for (int var9 = 0; var9 < this.icons.length; var9++) {
         float var10 = var7 + var9 * var6;
         float var11 = var8 - 2.0F;
         float var12 = var10 - 2.0F;
         if (var1 >= var11 && var1 <= var11 + 10.0F && var3 >= var12 && var3 <= var12 + 10.0F) {
            MenuScreen.getInstance().setCategory(this.categories[var9]);
            return true;
         }
      }

      return false;
   }
}
