package project.papus.implement.screens.menu;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.system.animation.Animation;
import project.papus.api.system.animation.Direction;
import project.papus.api.system.animation.implement.DecelerateAnimation;
import project.papus.api.system.sound.SoundManager;
import project.papus.common.QuickImports;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.features.modules.misc.Panic;
import project.papus.implement.screens.menu.components.AbstractComponent;
import project.papus.implement.screens.menu.components.implement.module.ModuleSettingsWindow;
import project.papus.implement.screens.menu.components.implement.other.BackgroundComponent;
import project.papus.implement.screens.menu.components.implement.other.CategoryContainerComponent;
import project.papus.implement.screens.menu.components.implement.other.CategorySidebarComponent;
import project.papus.implement.screens.menu.components.implement.other.SearchComponent;
import project.papus.implement.screens.menu.components.implement.other.UserComponent;
import project.papus.implement.screens.menu.components.implement.settings.TextComponent;

public class MenuScreen extends Screen implements QuickImports {
   private static MenuScreen instance;
   private final List<AbstractComponent> components = new ArrayList<>();
   private final BackgroundComponent backgroundComponent = new BackgroundComponent();
   private final UserComponent userComponent = new UserComponent();
   private final SearchComponent searchComponent = new SearchComponent();
   private final CategoryContainerComponent categoryContainerComponent = new CategoryContainerComponent();
   private final CategorySidebarComponent categorySidebarComponent = new CategorySidebarComponent();
   public final Animation scaleAnimation = new DecelerateAnimation().setMs(200).setValue(1.0);
   public ModuleCategory category = ModuleCategory.RENDER;
   public int x;
   public int y;
   public int width;
   public int height;

   public static MenuScreen getInstance() {
      if (instance == null) {
         instance = new MenuScreen();
         instance.initialize();
      }

      return instance;
   }

   public void initialize() {
      this.scaleAnimation.setDirection(Direction.FORWARDS);
      this.categoryContainerComponent.initializeCategoryComponents();
      this.components
         .addAll(
            Arrays.asList(this.backgroundComponent, this.userComponent, this.searchComponent, this.categoryContainerComponent, this.categorySidebarComponent)
         );
   }

   public MenuScreen() {
      super(Text.of("MenuScreen"));
      instance = this;
   }

   public void tick() {
      this.close();
      this.components.forEach(AbstractComponent::tick);
      windowManager.getWindows().removeIf(var0 -> var0 instanceof ModuleSettingsWindow && ((ModuleSettingsWindow)var0).isCloseAnimationFinished());
      super.tick();
   }

   public void render(DrawContext var1, int var2, int var3, float var4) {
      this.x = window.getScaledWidth() / 2 - 165;
      this.y = window.getScaledHeight() / 2 - 87;
      this.width = 330;
      this.height = 175;
      this.backgroundComponent.position(this.x, this.y).size(this.width, this.height);
      this.userComponent.position(this.x, this.y + this.height);
      this.categoryContainerComponent.position(this.x, this.y);
      this.categorySidebarComponent.position(this.x - 2, this.y + 35).size(31.0F, 130.0F);
      MathUtil.scale(
         var1.getMatrices(),
         this.x + this.width / 2.0F,
         this.y + this.height / 2.0F,
         this.getScaleValue(),
         () -> this.components.forEach(var4xx -> var4xx.render(var1, var2, var3, var4))
      );
      windowManager.getWindows().forEach(var4x -> var4x.render(var1, var2, var3, var4));
      super.render(var1, var2, var3, var4);
   }

   public void openGui() {
      if (!Panic.isPanicActive()) {
         this.scaleAnimation.setDirection(Direction.FORWARDS);
         mc.setScreen(this);
         SoundManager.playSound(SoundManager.OPEN_GUI);
      }
   }

   public float getScaleValue() {
      return this.scaleAnimation.getOutput().floatValue();
   }

   public boolean mouseClicked(double var1, double var3, int var5) {
      this.components.forEach(var5x -> var5x.mouseClicked(var1, var3, var5));
      windowManager.getWindows().forEach(var5x -> var5x.mouseClicked(var1, var3, var5));
      return super.mouseClicked(var1, var3, var5);
   }

   public boolean mouseReleased(double var1, double var3, int var5) {
      this.components.forEach(var5x -> var5x.mouseReleased(var1, var3, var5));
      windowManager.getWindows().forEach(var5x -> var5x.mouseReleased(var1, var3, var5));
      return super.mouseReleased(var1, var3, var5);
   }

   public boolean mouseDragged(double var1, double var3, int var5, double var6, double var8) {
      this.components.forEach(var9 -> var9.mouseDragged(var1, var3, var5, var6, var8));
      return super.mouseDragged(var1, var3, var5, var6, var8);
   }

   public boolean mouseScrolled(double var1, double var3, double var5, double var7) {
      this.components.forEach(var6 -> var6.mouseScrolled(var1, var3, var7));
      windowManager.getWindows().forEach(var6 -> var6.mouseScrolled(var1, var3, var7));
      return super.mouseScrolled(var1, var3, var5, var7);
   }

   public boolean keyPressed(int var1, int var2, int var3) {
      for (AbstractComponent var5 : this.components) {
         if (var5.keyPressed(var1, var2, var3)) {
            return true;
         }
      }

      windowManager.getWindows().forEach(var3x -> var3x.keyPressed(var1, var2, var3));
      if (var1 == 256 && this.shouldCloseOnEsc()) {
         SoundManager.playSound(SoundManager.CLOSE_GUI);
         this.scaleAnimation.setDirection(Direction.BACKWARDS);
         windowManager.getWindows()
            .stream()
            .filter(var0 -> var0 instanceof ModuleSettingsWindow)
            .forEach(var0 -> ((ModuleSettingsWindow)var0).startCloseAnimation());
         return true;
      } else {
         return super.keyPressed(var1, var2, var3);
      }
   }

   public boolean charTyped(char var1, int var2) {
      this.components.forEach(var2x -> var2x.charTyped(var1, var2));
      return super.charTyped(var1, var2);
   }

   public boolean shouldPause() {
      return true;
   }

   public void close() {
      if (this.scaleAnimation.isFinished(Direction.BACKWARDS)) {
         TextComponent.typing = false;
         super.close();
      }
   }

   public void setCategory(ModuleCategory var1) {
      this.category = var1;
   }

   public void setX(int var1) {
      this.x = var1;
   }

   public void setY(int var1) {
      this.y = var1;
   }

   public void setWidth(int var1) {
      this.width = var1;
   }

   public void setHeight(int var1) {
      this.height = var1;
   }

   public List<AbstractComponent> getComponents() {
      return this.components;
   }

   public BackgroundComponent getBackgroundComponent() {
      return this.backgroundComponent;
   }

   public UserComponent getUserComponent() {
      return this.userComponent;
   }

   public SearchComponent getSearchComponent() {
      return this.searchComponent;
   }

   public CategoryContainerComponent getCategoryContainerComponent() {
      return this.categoryContainerComponent;
   }

   public Animation getScaleAnimation() {
      return this.scaleAnimation;
   }

   public ModuleCategory getCategory() {
      return this.category;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getWidth() {
      return this.width;
   }

   public int getHeight() {
      return this.height;
   }
}
