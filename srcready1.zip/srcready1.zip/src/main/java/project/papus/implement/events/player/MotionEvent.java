package project.papus.implement.events.player;

import project.papus.api.event.events.callables.EventCancellable;

public class MotionEvent extends EventCancellable {
   private double x;
   private double y;
   private double z;
   private float yaw;
   private float pitch;
   private boolean onGround;

   @Override
   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else if (var1 instanceof MotionEvent var2) {
         if (!var2.canEqual(this)) {
            return false;
         } else if (!super.equals(var1)) {
            return false;
         } else if (Double.compare(this.getX(), var2.getX()) != 0) {
            return false;
         } else if (Double.compare(this.getY(), var2.getY()) != 0) {
            return false;
         } else if (Double.compare(this.getZ(), var2.getZ()) != 0) {
            return false;
         } else if (Float.compare(this.getYaw(), var2.getYaw()) != 0) {
            return false;
         } else {
            return Float.compare(this.getPitch(), var2.getPitch()) != 0 ? false : this.isOnGround() == var2.isOnGround();
         }
      } else {
         return false;
      }
   }

   protected boolean canEqual(Object var1) {
      return var1 instanceof MotionEvent;
   }

   @Override
   public int hashCode() {
      byte var1 = 59;
      int var2 = super.hashCode();
      long var3 = Double.doubleToLongBits(this.getX());
      var2 = var2 * 59 + (int)(var3 >>> 32 ^ var3);
      long var5 = Double.doubleToLongBits(this.getY());
      var2 = var2 * 59 + (int)(var5 >>> 32 ^ var5);
      long var7 = Double.doubleToLongBits(this.getZ());
      var2 = var2 * 59 + (int)(var7 >>> 32 ^ var7);
      var2 = var2 * 59 + Float.floatToIntBits(this.getYaw());
      var2 = var2 * 59 + Float.floatToIntBits(this.getPitch());
      return var2 * 59 + (this.isOnGround() ? 79 : 97);
   }

   public double getX() {
      return this.x;
   }

   public double getY() {
      return this.y;
   }

   public double getZ() {
      return this.z;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPitch() {
      return this.pitch;
   }

   public boolean isOnGround() {
      return this.onGround;
   }

   public void setX(double var1) {
      this.x = var1;
   }

   public void setY(double var1) {
      this.y = var1;
   }

   public void setZ(double var1) {
      this.z = var1;
   }

   public void setYaw(float var1) {
      this.yaw = var1;
   }

   public void setPitch(float var1) {
      this.pitch = var1;
   }

   public void setOnGround(boolean var1) {
      this.onGround = var1;
   }

   @Override
   public String toString() {
      return "MotionEvent(x="
         + this.getX()
         + ", y="
         + this.getY()
         + ", z="
         + this.getZ()
         + ", yaw="
         + this.getYaw()
         + ", pitch="
         + this.getPitch()
         + ", onGround="
         + this.isOnGround()
         + ")";
   }

   public MotionEvent(double var1, double var3, double var5, float var7, float var8, boolean var9) {
      this.x = var1;
      this.y = var3;
      this.z = var5;
      this.yaw = var7;
      this.pitch = var8;
      this.onGround = var9;
   }
}
