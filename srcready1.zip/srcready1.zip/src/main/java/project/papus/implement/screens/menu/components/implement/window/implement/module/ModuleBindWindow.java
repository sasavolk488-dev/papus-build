package project.papus.implement.screens.menu.components.implement.window.implement.module;

import project.papus.api.feature.module.Module;

public class ModuleBindWindow extends AbstractBindWindow {
   private final Module module;

   @Override
   protected int getKey() {
      return this.module.getKey();
   }

   @Override
   protected void setKey(int var1) {
      this.module.setKey(var1);
   }

   @Override
   protected int getType() {
      return this.module.getType();
   }

   @Override
   protected void setType(int var1) {
      this.module.setType(var1);
   }

   public ModuleBindWindow(Module var1) {
      this.module = var1;
   }
}
