package project.papus.implement.features.modules.player;

import java.util.Random;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.implement.events.player.TickEvent;

public class TriggerBot extends Module {
   private final MultiSelectSetting targetsSetting = new MultiSelectSetting("\u0422\u0430\u0440\u0433\u0435\u0442\u044b", "")
      .value("\u0418\u0433\u0440\u043e\u043a\u0438", "\u041c\u043e\u0431\u044b", "\u0414\u0440\u0443\u0437\u044c\u044f");
   private final MultiSelectSetting conditionsSetting = new MultiSelectSetting("\u0423\u0441\u043b\u043e\u0432\u0438\u044f", "")
      .value(
         "\u0422\u043e\u043b\u044c\u043a\u043e \u0441 \u043e\u0440\u0443\u0436\u0438\u0435\u043c",
         "\u041d\u0435 \u0431\u0438\u0442\u044c \u043a\u043e\u0433\u0434\u0430 \u0435\u0448\u044c",
         "\u0422\u043e\u043b\u044c\u043a\u043e \u043a\u0440\u0438\u0442\u044b"
      );
   private long lastAttackTime;
   private long nextAttackDelay;
   private boolean wasSprinting = false;
   private int sprintStopTicks = 0;
   private final Random random = new Random();
   private float randomFactor = 0.0F;

   public TriggerBot() {
      super("TriggerBot", "Trigger Bot", ModuleCategory.PLAYER);
      this.setup(this.targetsSetting, this.conditionsSetting);
      this.targetsSetting.getSelected().add("\u0418\u0433\u0440\u043e\u043a\u0438");
      this.conditionsSetting.getSelected().add("\u0422\u043e\u043b\u044c\u043a\u043e \u0441 \u043e\u0440\u0443\u0436\u0438\u0435\u043c");
      this.nextAttackDelay = this.getRandomDelay();
   }

   @Override
   public void deactivate() {
      this.wasSprinting = false;
      this.sprintStopTicks = 0;
      super.deactivate();
   }

   private long getRandomDelay() {
      byte var1 = 8;
      byte var2 = 15;
      return var1 + this.random.nextInt(var2 - var1);
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      if (!this.isSilent()) {
         if (mc.player != null && mc.world != null) {
            if (mc.currentScreen == null) {
               if (!this.conditionsSetting.isSelected("\u041d\u0435 \u0431\u0438\u0442\u044c \u043a\u043e\u0433\u0434\u0430 \u0435\u0448\u044c")
                  || !mc.player.isUsingItem()) {
                  if (!this.conditionsSetting.isSelected("\u0422\u043e\u043b\u044c\u043a\u043e \u0441 \u043e\u0440\u0443\u0436\u0438\u0435\u043c")
                     || this.canAttack()) {
                     if (mc.player.isOnGround()) {
                        this.wasSprinting = false;
                        this.sprintStopTicks = 0;
                     } else {
                        this.sprintStopTicks++;
                     }

                     LivingEntity var2 = this.getRaytraceTarget();
                     if (var2 != null) {
                        if (var2.isAlive()) {
                           double var3 = 4.8;
                           if (!(mc.player.distanceTo(var2) > var3 * var3)) {
                              float var5 = mc.player.getAttackCooldownProgress(0.0F);
                              long var6 = System.currentTimeMillis();
                              boolean var8 = this.canCrit();
                              boolean var9 = mc.player.isOnGround();
                              boolean var10 = !var9 && mc.player.getVelocity().y < -0.05;
                              float var11 = mc.player.fallDistance;
                              if (!this.conditionsSetting.isSelected("\u0422\u043e\u043b\u044c\u043a\u043e \u043a\u0440\u0438\u0442\u044b") || !var9) {
                                 if (var9) {
                                    float var14 = var8 ? 0.88F : 0.85F;
                                    if (!(var5 < var14)) {
                                       if (var6 - this.lastAttackTime >= this.nextAttackDelay) {
                                          this.attackTarget(var2);
                                          this.lastAttackTime = var6;
                                          this.nextAttackDelay = this.getRandomDelay();
                                       }
                                    }
                                 } else {
                                    boolean var12 = (var10 || this.sprintStopTicks > 1) && var11 > 0.01F;
                                    if (var12 && !this.wasSprinting) {
                                       float var13 = var8 ? 0.72F : 0.65F;
                                       if (var5 < var13) {
                                          return;
                                       }

                                       if (var6 - this.lastAttackTime < this.nextAttackDelay) {
                                          return;
                                       }

                                       this.attackTarget(var2);
                                       this.lastAttackTime = var6;
                                       this.nextAttackDelay = this.getRandomDelay();
                                       this.wasSprinting = true;
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean canAttack() {
      ItemStack var1 = mc.player.getEquippedStack(EquipmentSlot.MAINHAND);
      if (var1.isEmpty()) {
         return false;
      } else {
         String var2 = var1.getItem().toString().toLowerCase();
         return var2.contains("sword") || var2.contains("axe") || var2.contains("mace") || var2.contains("scythe") || var2.contains("hammer");
      }
   }

   private boolean canCrit() {
      return mc.player.hasStatusEffect(StatusEffects.POISON)
         || mc.player.hasStatusEffect(StatusEffects.SLOW_FALLING)
         || mc.player.hasStatusEffect(StatusEffects.GLOWING)
         || mc.player.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)
         || mc.player.hasStatusEffect(StatusEffects.WITHER)
         || mc.player.hasStatusEffect(StatusEffects.SATURATION)
         || mc.player.hasStatusEffect(StatusEffects.REGENERATION)
         || mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION);
   }

   private void attackTarget(LivingEntity var1) {
      mc.interactionManager.attackEntity(mc.player, var1);
      mc.player.swingHand(Hand.MAIN_HAND);
   }

   private LivingEntity getRaytraceTarget() {
      if (!(mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult var1)) {
         return null;
      } else if (!(var1.getEntity() instanceof LivingEntity var4)) {
         return null;
      } else if (var4 == mc.player) {
         return null;
      } else if (!var4.isAlive()) {
         return null;
      } else if (var4 instanceof ArmorStandEntity) {
         return null;
      } else {
         if (var4 instanceof PlayerEntity var5) {
            if (!this.targetsSetting.isSelected("\u0418\u0433\u0440\u043e\u043a\u0438")) {
               return null;
            }

            boolean var6 = FriendUtils.getFriends().stream().anyMatch(var1x -> var1x.getName().equals(var5.getName().getString()));
            if (var6 && !this.targetsSetting.isSelected("\u0414\u0440\u0443\u0437\u044c\u044f")) {
               return null;
            }
         } else if (!this.targetsSetting.isSelected("\u041c\u043e\u0431\u044b")) {
            return null;
         }

         return var4;
      }
   }
}
