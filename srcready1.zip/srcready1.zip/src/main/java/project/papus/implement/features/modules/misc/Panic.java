package project.papus.implement.features.modules.misc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.core.Main;
import project.papus.implement.events.player.TickEvent;

public class Panic extends Module {
   private static boolean panicActive = false;
   private boolean activating = false;
   private static final List<Module> savedEnabledModules = new ArrayList<>();

   public Panic() {
      super("Panic", "Panic", ModuleCategory.MISC);
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      if (this.isState() && !this.activating) {
         this.activating = true;
         this.enablePanic();
      }

      if (!this.isState()) {
         this.activating = false;
      }
   }

   private void enablePanic() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1 != null) {
         savedEnabledModules.clear();
         int var2 = 0;

         for (Module var4 : Main.getInstance().getModuleRepository().modules()) {
            if (var4 != this && var4.isState()) {
               savedEnabledModules.add(var4);
               var4.setStateQuietly(false);
               var2++;
            }
         }

         panicActive = true;
         if (var1.currentScreen != null) {
            var1.setScreen(null);
         }

         if (var1.player != null) {
            var1.player.sendMessage(Text.literal(""), false);
         }

         this.setStateQuietly(false);
      }
   }

   public static boolean handleChatMessage(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         MinecraftClient var1 = MinecraftClient.getInstance();
         if (var1 == null) {
            return false;
         } else if (var0.equals(".papus")) {
            panicActive = false;
            int var2 = 0;

            for (Module var4 : savedEnabledModules) {
               if (var4 != null) {
                  var4.setStateQuietly(true);
                  var2++;
               }
            }

            savedEnabledModules.clear();
            if (var1.player != null) {
               var1.player.sendMessage(Text.literal(""), false);
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean isPanicActive() {
      return panicActive;
   }

   public static void activateFromCommand() {
      panicActive = true;
   }

   public static void deactivateFromCommand() {
      panicActive = false;
   }
}
