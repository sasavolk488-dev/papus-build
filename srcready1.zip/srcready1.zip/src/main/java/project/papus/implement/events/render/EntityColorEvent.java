package project.papus.implement.events.render;

import project.papus.api.event.events.callables.EventCancellable;

public class EntityColorEvent extends EventCancellable {
   private int color;
   private boolean hurt = false;

   public int getColor() {
      return this.color;
   }

   public void setColor(int var1) {
      this.color = var1;
   }

   public boolean isHurt() {
      return this.hurt;
   }

   public void setHurt(boolean var1) {
      this.hurt = var1;
   }

   public EntityColorEvent(int var1) {
      this.color = var1;
   }
}
