package project.papus.implement.screens.menu.components.implement.window.implement.settings.color.component;

import java.awt.Color;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import project.papus.api.feature.module.setting.implement.ColorSetting;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class SaturationComponent extends AbstractComponent {
   private final ColorSetting setting;
   private boolean sliding;
   private float X;
   private float Y;
   private float W;
   private float H;

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      this.X = this.x + 6.0F;
      this.Y = this.y + 18.5F;
      this.W = 138.0F;
      this.H = 50.0F;
      int[] var6 = new int[]{-16777216, -1, -16777216, Color.HSBtoRGB(this.setting.getHue(), 1.0F, 1.0F)};
      rectangle.render(ShapeProperties.create(var5, this.X, this.Y, this.W, this.H).round(2.0F).color(var6).build());
      float var7 = MathHelper.clamp(this.X + this.W * this.setting.getSaturation(), this.X, this.X + this.W - 5.0F);
      float var8 = MathHelper.clamp(this.Y + this.H * (1.0F - this.setting.getBrightness()), this.Y, this.Y + this.H - 5.0F);
      rectangle.render(ShapeProperties.create(var5, var7, var8, 5.0, 5.0).round(2.5F).softness(1.0F).thickness(3.0F).color(16777215).outlineColor(-1).build());
      float var9 = MathHelper.clamp((var2 - this.X) / this.W, 0.0F, 1.0F);
      if (this.sliding) {
         this.setting.setBrightness(MathHelper.clamp(1.0F - (var3 - this.Y) / this.H, 0.0F, 1.0F));
         this.setting.setSaturation(var9);
      }
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      this.sliding = var5 == 0 && MathUtil.isHovered(var1, var3, this.X, this.Y, this.W, this.H);
      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.sliding = false;
      return super.mouseReleased(var1, var3, var5);
   }

   public SaturationComponent(ColorSetting var1) {
      this.setting = var1;
   }
}
