package project.papus.implement.screens.menu.components.implement.settings;

import net.minecraft.client.gui.DrawContext;
import project.papus.api.feature.module.setting.implement.GroupSetting;
import project.papus.api.system.font.Fonts;
import project.papus.implement.screens.menu.components.implement.other.CheckComponent;
import project.papus.implement.screens.menu.components.implement.other.SettingComponent;
import project.papus.implement.screens.menu.components.implement.window.AbstractWindow;
import project.papus.implement.screens.menu.components.implement.window.implement.settings.group.GroupWindow;

public class GroupComponent extends AbstractSettingComponent {
   private final CheckComponent checkComponent = new CheckComponent();
   private final SettingComponent settingComponent = new SettingComponent();
   private final GroupSetting setting;

   public GroupComponent(GroupSetting var1) {
      super(var1);
      this.setting = var1;
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      this.height = 18.0F;
      Fonts.getSize(14, Fonts.Type.BOLD).drawString(var1.getMatrices(), this.setting.getName(), this.x + 9.0F, this.y + 6.0F, -2828575);
      ((CheckComponent)this.checkComponent.position(this.x + this.width - 16.0F, this.y + 7.5F))
         .setAction(() -> this.setting.setValue(!this.setting.isValue()))
         .setState(this.setting.isValue())
         .render(var1, var2, var3, var4);
      ((SettingComponent)this.settingComponent.position(this.x + this.width - 28.0F, this.y + 8.0F))
         .setAction(() -> this.toggleGroupWindow(var2, var3))
         .render(var1, var2, var3, var4);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      this.checkComponent.mouseClicked(var1, var3, var5);
      this.settingComponent.mouseClicked(var1, var3, var5);
      return super.mouseClicked(var1, var3, var5);
   }

   private void toggleGroupWindow(int var1, int var2) {
      AbstractWindow var3 = null;

      for (AbstractWindow var5 : windowManager.getWindows()) {
         if (var5 instanceof GroupWindow && ((GroupWindow)var5).getSetting() == this.setting) {
            var3 = var5;
            break;
         }
      }

      if (var3 != null) {
         windowManager.delete(var3);
      } else {
         AbstractWindow var6 = new GroupWindow(this.setting).position(var1 + 5, var2 + 5).size(137.0F, 23.0F).setDraggable(false);
         windowManager.add(var6);
      }
   }
}
