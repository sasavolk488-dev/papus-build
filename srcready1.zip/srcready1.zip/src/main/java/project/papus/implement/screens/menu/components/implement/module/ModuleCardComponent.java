package project.papus.implement.screens.menu.components.implement.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.ColorHelper;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.setting.SettingComponentAdder;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.other.StringUtil;
import project.papus.implement.features.modules.player.TriggerBot;
import project.papus.implement.screens.menu.components.AbstractComponent;
import project.papus.implement.screens.menu.components.implement.other.CheckComponent;
import project.papus.implement.screens.menu.components.implement.settings.AbstractSettingComponent;

public class ModuleCardComponent extends AbstractComponent {
   private final List<AbstractSettingComponent> components = new ArrayList<>();
   private final CheckComponent checkComponent = new CheckComponent();
   private final Module module;
   private boolean binding;

   private void initializeSettings() {
      new SettingComponentAdder().addSettingComponent(this.module.settings(), this.components);
   }

   public ModuleCardComponent(Module var1) {
      this.module = var1;
      this.initializeSettings();
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      rectangle.render(
         ShapeProperties.create(var1.getMatrices(), this.x, this.y, this.width, 18.0)
            .round(5.0F, 0.0F, 5.0F, 0.0F)
            .color(ColorUtil.getColor(255, 255, 255, 8))
            .build()
      );
      rectangle.render(
         ShapeProperties.create(var1.getMatrices(), this.x, this.y + 18.0F, this.width, this.height = this.getComponentHeight() - 18)
            .round(0.0F, 5.0F, 0.0F, 5.0F)
            .softness(1.0F)
            .thickness(0.0F)
            .outlineColor(ColorUtil.getColor(255, 255, 255, 0))
            .color(ColorUtil.getColor(255, 255, 255, 2))
            .build()
      );
      String var5 = this.module.getVisibleName();
      if (this.module instanceof TriggerBot) {
         var5 = "\u00a77[\u00a7cFT\u00a77] " + var5;
      }

      Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(var1.getMatrices(), var5, this.x + 8.0F, this.y + 8.0F, -2828575);
      this.renderBind(var1);
      ((CheckComponent)this.checkComponent.position(this.x + this.width - 16.0F, this.y + 4.5F))
         .setAction(this.module::switchState)
         .setState(this.module.isState())
         .render(var1, var2, var3, var4);
      float var6 = this.y + 22.0F;

      for (int var7 = this.components.size() - 1; var7 >= 0; var7--) {
         AbstractSettingComponent var8 = this.components.get(var7);
         Supplier var9 = var8.getSetting().getVisible();
         if (var9 == null || (Boolean)var9.get()) {
            var8.x = this.x;
            var8.y = var6 + (this.getComponentHeight() - 26 - var8.height);
            var8.width = this.width;
            var8.render(var1, var2, var3, var4);
            var6 -= var8.height;
         }
      }
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      boolean var6 = this.components.stream().anyMatch(var4 -> var4.isHover(var1, var3));
      if (!var6 && !this.isBindHidden()) {
         String var7 = StringUtil.getShortBindName(this.module.getKey());
         float var8 = Fonts.getSize(12, Fonts.Type.BOLD).getStringWidth(var7);
         if (MathUtil.isHovered(var1, var3, this.x + this.width - 15.0F - 15.0F - var8, this.y + 8.0F, var8 + 6.0F, 9.0) && var5 == 0) {
            this.binding = !this.binding;
         } else if (this.binding) {
            this.module.setKey(var5);
            this.binding = false;
         }
      }

      this.checkComponent.mouseClicked(var1, var3, var5);
      this.components.forEach(var5x -> var5x.mouseClicked(var1, var3, var5));
      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean isHover(double var1, double var3) {
      for (AbstractComponent var6 : this.components) {
         if (var6.isHover(var1, var3)) {
            return true;
         }
      }

      return MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height);
   }

   @Override
   public void tick() {
      this.components.forEach(AbstractComponent::tick);
      super.tick();
   }

   @Override
   public boolean mouseDragged(double var1, double var3, int var5, double var6, double var8) {
      this.components.forEach(var9 -> var9.mouseDragged(var1, var3, var5, var6, var8));
      return super.mouseDragged(var1, var3, var5, var6, var8);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.components.forEach(var5x -> var5x.mouseReleased(var1, var3, var5));
      return super.mouseReleased(var1, var3, var5);
   }

   @Override
   public boolean mouseScrolled(double var1, double var3, double var5) {
      this.components.forEach(var6 -> var6.mouseScrolled(var1, var3, var5));
      return super.mouseScrolled(var1, var3, var5);
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      int var4 = var1 != 261 && var1 != 256 ? var1 : -1;
      if (this.binding) {
         this.module.setKey(var4);
         this.binding = false;
         if (var1 == 256) {
            return true;
         }
      }

      this.components.forEach(var3x -> var3x.keyPressed(var1, var2, var3));
      return super.keyPressed(var1, var2, var3);
   }

   private boolean isBindHidden() {
      String var1 = this.module.getName();
      return "CustomScoreboard".equals(var1);
   }

   @Override
   public boolean charTyped(char var1, int var2) {
      this.components.forEach(var2x -> var2x.charTyped(var1, var2));
      return super.charTyped(var1, var2);
   }

   public int getComponentHeight() {
      float var1 = 0.0F;

      for (AbstractSettingComponent var3 : this.components) {
         Supplier var4 = var3.getSetting().getVisible();
         if (var4 == null || (Boolean)var4.get()) {
            var1 += var3.height;
         }
      }

      return (int)(var1 + 26.0F);
   }

   private void renderBind(DrawContext var1) {
      if (!this.isBindHidden()) {
         String var2 = StringUtil.getShortBindName(this.module.getKey());
         String var3 = this.binding ? "(" + var2 + ") ..." : var2;
         float var4 = Fonts.getSize(12, Fonts.Type.BOLD).getStringWidth(var3);
         rectangle.render(
            ShapeProperties.create(var1.getMatrices(), this.x + this.width - var4 - 15.0F - 15.0F, this.y + 4.5F, var4 + 6.0F, 9.0)
               .round(2.0F)
               .thickness(3.0F)
               .outlineColor(ColorUtil.getColor(62, 62, 62, 255))
               .color(ColorUtil.getClientColor(0.0F))
               .build()
         );
         int var5 = ColorHelper.getArgb(255, 135, 136, 148);
         Fonts.getSize(12, Fonts.Type.BOLD)
            .drawString(var1.getMatrices(), var3, this.x + this.width - var4 - 15.0F - 12.0F, this.y + 8.0F, ColorUtil.getColor(100, 100, 100, 255));
      }
   }

   @Override
   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         ModuleCardComponent var2 = (ModuleCardComponent)var1;
         return this.module.equals(var2.module);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.module);
   }

   public List<AbstractSettingComponent> getComponents() {
      return this.components;
   }

   public CheckComponent getCheckComponent() {
      return this.checkComponent;
   }

   public Module getModule() {
      return this.module;
   }

   public boolean isBinding() {
      return this.binding;
   }
}
