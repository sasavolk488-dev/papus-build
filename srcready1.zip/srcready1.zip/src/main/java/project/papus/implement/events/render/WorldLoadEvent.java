package project.papus.implement.events.render;

import project.papus.api.event.events.Event;

public class WorldLoadEvent implements Event {
}
