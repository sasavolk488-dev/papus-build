package project.papus.implement.screens.menu.components.implement.module;

import project.papus.api.feature.module.Module;

public class ModuleDescription {
   public static String getDescription(Module var0) {
      return "\u041e\u043f\u0438\u0441\u0430\u043d\u0438\u0435 \u043c\u043e\u0434\u0443\u043b\u044f \u043e\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442.";
   }
}
