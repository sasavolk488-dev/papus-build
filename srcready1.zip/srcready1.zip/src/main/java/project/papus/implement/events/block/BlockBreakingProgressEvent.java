package project.papus.implement.events.block;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import project.papus.api.event.events.Event;

public record BlockBreakingProgressEvent(BlockPos blockPos, Direction direction) implements Event {
}
