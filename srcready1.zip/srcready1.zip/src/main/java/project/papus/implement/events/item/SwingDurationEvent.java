package project.papus.implement.events.item;

import project.papus.api.event.events.callables.EventCancellable;

public class SwingDurationEvent extends EventCancellable {
   private float animation;

   public float getAnimation() {
      return this.animation;
   }

   public void setAnimation(float var1) {
      this.animation = var1;
   }
}
