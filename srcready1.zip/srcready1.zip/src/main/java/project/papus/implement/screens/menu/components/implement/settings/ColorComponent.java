package project.papus.implement.screens.menu.components.implement.settings;

import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.feature.module.setting.implement.ColorSetting;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.implement.module.ModuleSettingsWindow;
import project.papus.implement.screens.menu.components.implement.window.AbstractWindow;
import project.papus.implement.screens.menu.components.implement.window.implement.settings.color.ColorWindow;

public class ColorComponent extends AbstractSettingComponent {
   private final ColorSetting setting;

   public ColorComponent(ColorSetting var1) {
      super(var1);
      this.setting = var1;
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      this.height = 18.0F;
      Fonts.getSize(14, Fonts.Type.BOLD).drawString(var5, this.setting.getName(), this.x + 9.0F, this.y + 6.0F, -2828575);
      rectangle.render(ShapeProperties.create(var5, this.x + this.width - 14.0F, this.y + 7.0F, 7.0, 7.0).round(3.5F).color(this.setting.getColor()).build());
      rectangle.render(
         ShapeProperties.create(var5, this.x + this.width - 14.0F, this.y + 7.0F, 7.0, 7.0)
            .round(3.5F)
            .thickness(2.0F)
            .softness(1.0F)
            .outlineColor(ColorUtil.getTextColor())
            .color(16777215)
            .build()
      );
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (MathUtil.isHovered(var1, var3, this.x + this.width - 15.0F, this.y + 6.7F, 7.0, 7.0) && var5 == 0) {
         AbstractWindow var6 = null;

         for (AbstractWindow var8 : windowManager.getWindows()) {
            if (var8 instanceof ColorWindow) {
               var6 = var8;
               break;
            }
         }

         if (var6 != null) {
            windowManager.delete(var6);
         } else {
            float var12 = (int)(var1 + 18.0);
            float var13 = (int)(var3 + 10.0);
            List var9 = windowManager.getWindows();

            for (int var10 = var9.size() - 1; var10 >= 0; var10--) {
               AbstractWindow var11 = (AbstractWindow)var9.get(var10);
               if (var11 instanceof ModuleSettingsWindow
                  && var1 >= var11.x
                  && var1 <= var11.x + var11.width
                  && var3 >= var11.y
                  && var3 <= var11.y + var11.height) {
                  var12 = var11.x;
                  var13 = var11.y + var11.height + 8.0F;
                  break;
               }
            }

            AbstractWindow var14 = new ColorWindow(this.setting).position((int)var12, (int)var13).size(160.0F, 180.0F).setDraggable(true);
            windowManager.add(var14);
         }
      }

      return super.mouseClicked(var1, var3, var5);
   }
}
