package project.papus.implement.features.modules.render;

import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4i;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.BooleanSetting;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.render.Render3DUtil;
import project.papus.implement.events.player.AttackEvent;
import project.papus.implement.events.player.TickEvent;
import project.papus.implement.events.render.WorldRenderEvent;

public class TargetEsp extends Module {
   private final MultiSelectSetting targetsSetting = new MultiSelectSetting("\u0422\u0430\u0440\u0433\u0435\u0442\u044b", "")
      .value("\u0418\u0433\u0440\u043e\u043a\u0438", "\u041c\u043e\u0431\u044b", "\u0414\u0440\u0443\u0437\u044c\u044f");
   private final SelectSetting modeSetting = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "")
      .value("\u041f\u0440\u0438\u0437\u0440\u0430\u043a\u0438", "\u041a\u0432\u0430\u0434\u0440\u0430\u0442", "\u041a\u0432\u0430\u0434\u0440\u0430\u0442 2")
      .selected("\u041f\u0440\u0438\u0437\u0440\u0430\u043a\u0438");
   private final BooleanSetting redOnHitSetting = new BooleanSetting(
         "\u041a\u0440\u0430\u0441\u043d\u0435\u0442\u044c \u043f\u0440\u0438 \u0443\u0434\u0430\u0440\u0435", ""
      )
      .setValue(true);
   private static final Identifier CAPTURE_2_TEXTURE = Identifier.of("papus", "textures/capture2.png");
   private static final Identifier CAPTURE_TEXTURE = Identifier.of("papus", "textures/capture.png");
   private LivingEntity currentTarget = null;
   private long fadeStartTime = 0L;
   private static final long FADE_DURATION = 1450L;
   private long lastHitTime = 0L;
   private static final long HIT_FLASH_DURATION = 400L;

   public TargetEsp() {
      super("Target Esp", "Target Esp", ModuleCategory.RENDER);
      this.setup(this.targetsSetting, this.modeSetting, this.redOnHitSetting);
      this.targetsSetting.getSelected().add("\u0418\u0433\u0440\u043e\u043a\u0438");
   }

   @Override
   public void deactivate() {
      this.currentTarget = null;
      this.fadeStartTime = 0L;
      this.lastHitTime = 0L;
      super.deactivate();
   }

   @EventHandler
   public void onAttack(AttackEvent var1) {
      if (this.redOnHitSetting.isValue()) {
         if (this.currentTarget != null) {
            if (var1.getEntity() == this.currentTarget) {
               this.lastHitTime = System.currentTimeMillis();
            }
         }
      }
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      if (mc.player != null && mc.world != null) {
         LivingEntity var2 = this.getRaytraceTarget();
         if (var2 != null && var2.isAlive() && this.isValidTarget(var2)) {
            this.currentTarget = var2;
            this.fadeStartTime = 0L;
         } else if (this.currentTarget != null) {
            if (this.fadeStartTime == 0L) {
               this.fadeStartTime = System.currentTimeMillis();
            }

            if (System.currentTimeMillis() - this.fadeStartTime > 1450L) {
               this.currentTarget = null;
               this.fadeStartTime = 0L;
            }
         }
      }
   }

   @EventHandler
   public void onWorldRender(WorldRenderEvent var1) {
      if (this.isState()) {
         if (this.currentTarget != null) {
            if (!this.currentTarget.isAlive()) {
               this.currentTarget = null;
            } else {
               float var2 = 1.0F;
               if (this.fadeStartTime > 0L) {
                  long var3 = System.currentTimeMillis() - this.fadeStartTime;
                  var2 = 1.0F - Math.min(1.0F, (float)var3 / 1450.0F);
               }

               float var8 = 0.0F;
               if (this.redOnHitSetting.isValue() && this.lastHitTime > 0L) {
                  long var4 = System.currentTimeMillis() - this.lastHitTime;
                  if (var4 < 400L) {
                     var8 = 1.0F - (float)var4 / 400.0F;
                  } else {
                     this.lastHitTime = 0L;
                  }
               }

               short var9 = 255;
               int var5 = (int)(255.0F * (1.0F - var8));
               int var6 = (int)(255.0F * (1.0F - var8));
               String var7 = this.modeSetting.getSelected();
               if (var7.equals("\u041f\u0440\u0438\u0437\u0440\u0430\u043a\u0438")) {
                  Render3DUtil.drawGhosts(this.currentTarget, var2, var8, 1.25F);
               } else if (var7.equals("\u041a\u0432\u0430\u0434\u0440\u0430\u0442")) {
                  this.renderSquareEsp(this.currentTarget, var2, CAPTURE_2_TEXTURE, var9, var5, var6);
               } else if (var7.equals("\u041a\u0432\u0430\u0434\u0440\u0430\u0442 2")) {
                  this.renderSquareEsp(this.currentTarget, var2, CAPTURE_TEXTURE, var9, var5, var6);
               }
            }
         }
      }
   }

   private void renderSquareEsp(LivingEntity var1, float var2, Identifier var3, int var4, int var5, int var6) {
      Camera var7 = mc.gameRenderer.getCamera();
      Vec3d var8 = var7.getPos();
      Vec3d var9 = MathUtil.interpolate(var1);
      double var10 = var9.x - var8.x;
      double var12 = var9.y + var1.getHeight() / 2.0 - var8.y;
      double var14 = var9.z - var8.z;
      float var16 = 1.0F;
      int var17 = ColorUtil.getColor(var4, var5, var6, (int)(var2 * 220.0F));
      Vector4i var18 = new Vector4i(var17, var17, var17, var17);
      MatrixStack var19 = new MatrixStack();
      var19.push();
      var19.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var7.getPitch()));
      var19.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var7.getYaw() + 180.0F));
      var19.translate(var10, var12, var14);
      var19.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-var7.getYaw()));
      var19.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var7.getPitch()));
      float var20 = (float)(System.currentTimeMillis() % 5000L) / 5000.0F * 360.0F;
      var19.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var20));
      float var21 = 0.03F;
      Render3DUtil.drawTexture(
         var19.peek().copy(),
         var3,
         -var16 / 2.0F - var21,
         -var16 / 2.0F - var21,
         var16 + var21 * 2.0F,
         var21,
         new Vector4i(var4, var5, var6, (int)(var2 * 100.0F)),
         false
      );
      Render3DUtil.drawTexture(
         var19.peek().copy(),
         var3,
         -var16 / 2.0F - var21,
         var16 / 2.0F,
         var16 + var21 * 2.0F,
         var21,
         new Vector4i(var4, var5, var6, (int)(var2 * 100.0F)),
         false
      );
      Render3DUtil.drawTexture(
         var19.peek().copy(), var3, -var16 / 2.0F - var21, -var16 / 2.0F, var21, var16, new Vector4i(var4, var5, var6, (int)(var2 * 100.0F)), false
      );
      Render3DUtil.drawTexture(
         var19.peek().copy(), var3, var16 / 2.0F, -var16 / 2.0F, var21, var16, new Vector4i(var4, var5, var6, (int)(var2 * 100.0F)), false
      );
      Render3DUtil.drawTexture(var19.peek().copy(), var3, -var16 / 2.0F, -var16 / 2.0F, var16, var16, var18, false);
      var19.pop();
   }

   private boolean isValidTarget(LivingEntity var1) {
      if (var1 == mc.player) {
         return false;
      } else {
         if (var1 instanceof PlayerEntity) {
            boolean var2 = FriendUtils.getFriends().stream().anyMatch(var1x -> var1x.getName().equals(var1.getName().getString()));
            if (var2 && !this.targetsSetting.isSelected("\u0414\u0440\u0443\u0437\u044c\u044f")) {
               return false;
            }

            if (!var2 && !this.targetsSetting.isSelected("\u0418\u0433\u0440\u043e\u043a\u0438")) {
               return false;
            }
         } else if (!this.targetsSetting.isSelected("\u041c\u043e\u0431\u044b")) {
            return false;
         }

         return true;
      }
   }

   private LivingEntity getRaytraceTarget() {
      if (mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult var1 && var1.getEntity() instanceof LivingEntity var4) {
         if (var4 == mc.player) {
            return null;
         } else if (!var4.isAlive()) {
            return null;
         } else {
            return var4 instanceof ArmorStandEntity ? null : var4;
         }
      } else {
         return null;
      }
   }
}
