package project.papus.implement.features.modules.render;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventHandler;
import project.papus.api.event.EventManager;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.common.util.other.Instance;
import project.papus.common.util.rotation.Angle;
import project.papus.implement.events.render.CameraEvent;
import project.papus.implement.events.render.CameraPositionEvent;

public class CameraClip extends Module {
   private static final float DEFAULT_DISTANCE = 4.0F;

   public static CameraClip getInstance() {
      return Instance.get(CameraClip.class);
   }

   public CameraClip() {
      super("Camera Clip", "Camera Clip", ModuleCategory.RENDER);
   }

   @EventHandler
   public void onCamera(CameraEvent var1) {
      if (this.isState()) {
         var1.setCameraClip(true);
         var1.setDistance(4.0F);
         var1.cancel();
      }
   }

   @Mixin(Camera.class)
   public abstract static class CameraMixin {
      @Shadow
      private Vec3d pos;
      @Shadow
      @Final
      private Mutable blockPos;
      @Shadow
      private float yaw;
      @Shadow
      private float pitch;

      @Shadow
      public abstract void setRotation(float var1, float var2);

      @Shadow
      protected abstract void moveBy(float var1, float var2, float var3);

      @Shadow
      protected abstract float clipToSpace(float var1);

      @Inject(
         method = "update(Lnet/minecraft/world/BlockView;Lnet/minecraft/entity/Entity;ZZF)V",
         at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setPos(DDD)V", shift = Shift.AFTER),
         cancellable = true
      )
      private void updateHook(BlockView var1, Entity var2, boolean var3, boolean var4, float var5, CallbackInfo var6) {
         CameraEvent var7 = new CameraEvent(false, 4.0F, new Angle(this.yaw, this.pitch));
         EventManager.callEvent(var7);
         Angle var8 = var7.getAngle();
         if (var7.isCancelled() && var8 != null && var2 instanceof ClientPlayerEntity var9 && !var9.isSleeping() && var3) {
            float var10 = var4 ? -var8.getPitch() : var8.getPitch();
            float var11 = var8.getYaw() - (var4 ? 180 : 0);
            float var12 = var7.getDistance();
            this.setRotation(var11, var10);
            this.moveBy(var7.isCameraClip() ? -var12 : -this.clipToSpace(var12), 0.0F, 0.0F);
            var6.cancel();
         }
      }

      @Inject(method = "setPos(Lnet/minecraft/util/math/Vec3d;)V", at = @At("HEAD"), cancellable = true)
      private void posHook(Vec3d var1, CallbackInfo var2) {
         CameraPositionEvent var3 = new CameraPositionEvent(var1);
         EventManager.callEvent(var3);
         this.pos = var1 = var3.getPos();
         this.blockPos.set(var1.x, var1.y, var1.z);
         var2.cancel();
      }
   }
}
