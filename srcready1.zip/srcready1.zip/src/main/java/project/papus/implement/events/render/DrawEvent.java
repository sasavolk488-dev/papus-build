package project.papus.implement.events.render;

import net.minecraft.client.gui.DrawContext;
import project.papus.api.event.events.Event;
import project.papus.api.system.draw.DrawEngine;

public class DrawEvent implements Event {
   private DrawContext drawContext;
   private DrawEngine drawEngine;
   private float tickDelta;

   public DrawContext getDrawContext() {
      return this.drawContext;
   }

   public DrawEngine getDrawEngine() {
      return this.drawEngine;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }

   public DrawEvent(DrawContext var1, DrawEngine var2, float var3) {
      this.drawContext = var1;
      this.drawEngine = var2;
      this.tickDelta = var3;
   }
}
