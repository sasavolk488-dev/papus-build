package project.papus.implement.features.modules.player;

import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.BooleanSetting;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.common.util.entity.PlayerInventoryUtil;
import project.papus.common.util.other.StopWatch;
import project.papus.common.util.task.scripts.Script;
import project.papus.implement.events.player.KeyboardInputEvent;
import project.papus.implement.events.player.TickEvent;

public class AutoTotem extends Module {
   private final ValueSetting healthSetting = new ValueSetting("\u0417\u0434\u043e\u0440\u043e\u0432\u044c\u0435", "").setValue(10.5F).range(1.0F, 20.0F);
   private final BooleanSetting saveEnchantedTotemSetting = new BooleanSetting(
         "\u0421\u0435\u0439\u0432\u0438\u0442\u044c \u0437\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0439 \u0442\u043e\u0442\u0435\u043c",
         ""
      )
      .setValue(false);
   private final Script script = new Script();
   private final StopWatch stopWatch = new StopWatch();
   private final Random random = new Random();
   private boolean slownessActive = false;

   public AutoTotem() {
      super("AutoTotem", "Auto Totem", ModuleCategory.PLAYER);
      this.setup(this.healthSetting, this.saveEnchantedTotemSetting);
   }

   @Override
   public void deactivate() {
      this.slownessActive = false;
      this.script.cleanup();
      super.deactivate();
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      this.script.update();
      if (this.slownessActive && mc.player != null) {
         mc.player.setSprinting(false);
      }

      if (mc.player != null && mc.world != null) {
         float var2 = mc.player.getHealth();
         if (var2 <= this.healthSetting.getValue() && this.script.isFinished() && this.stopWatch.every(200.0)) {
            ItemStack var3 = mc.player.inventory.getStack(40);
            String var4 = var3.isEmpty() ? "" : var3.getItem().toString().toLowerCase();
            if (this.saveEnchantedTotemSetting.isValue()) {
               boolean var5 = !var3.isEmpty() && var4.contains("totem") && !var3.hasEnchantments();
               if (var5) {
                  return;
               }
            }

            boolean var14 = !var3.isEmpty() && var4.contains("totem");
            boolean var6 = var14 && var3.hasEnchantments();
            boolean var7 = false;
            if (!var14) {
               var7 = true;
            } else if (this.saveEnchantedTotemSetting.isValue() && var6) {
               var7 = true;
            }

            if (!var7) {
               return;
            }

            int var8 = this.findBestTotemSlot();
            if (var8 != -1) {
               String var10 = "totem";
               this.script.cleanup();
               this.slownessActive = true;
               int var11 = 42 + this.random.nextInt(42);
               int var12 = 5 + this.random.nextInt(5);
               int var13 = 5 + this.random.nextInt(5);
               this.script.addTickStep(var11, () -> PlayerInventoryUtil.clickSlot(var8, 40, SlotActionType.SWAP, false)).addTickStep(var12, () -> {
                  ItemStack var1x = mc.player.inventory.getStack(40);
                  boolean var2x = !var1x.isEmpty() && var1x.getItem().toString().toLowerCase().contains("totem");
                  if (!var2x) {
                     PlayerInventoryUtil.clickSlot(var8, 40, SlotActionType.SWAP, false);
                  }
               }).addTickStep(var13, () -> {
                  this.slownessActive = false;
                  this.stopWatch.reset();
               });
            }
         }
      }
   }

   @EventHandler
   public void onKeyboardInput(KeyboardInputEvent var1) {
      if (this.slownessActive) {
         var1.resetDirectional();
      }
   }

   private int findBestTotemSlot() {
      if (this.saveEnchantedTotemSetting.isValue()) {
         for (int var1 = 0; var1 < 36; var1++) {
            ItemStack var2 = mc.player.inventory.getStack(var1);
            if (!var2.isEmpty() && var2.getItem().toString().toLowerCase().contains("totem") && !var2.hasEnchantments()) {
               return var1;
            }
         }
      }

      for (int var3 = 0; var3 < 36; var3++) {
         ItemStack var5 = mc.player.inventory.getStack(var3);
         if (!var5.isEmpty() && var5.getItem().toString().toLowerCase().contains("totem") && !var5.hasEnchantments()) {
            return var3;
         }
      }

      for (int var4 = 0; var4 < 36; var4++) {
         ItemStack var6 = mc.player.inventory.getStack(var4);
         if (!var6.isEmpty() && var6.getItem().toString().toLowerCase().contains("totem") && var6.hasEnchantments()) {
            return var4;
         }
      }

      return -1;
   }
}
