package project.papus.implement.screens.menu.components.implement.window.implement.settings.color;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.feature.module.setting.implement.ColorSetting;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;
import project.papus.implement.screens.menu.components.implement.window.AbstractWindow;
import project.papus.implement.screens.menu.components.implement.window.implement.settings.color.component.AlphaComponent;
import project.papus.implement.screens.menu.components.implement.window.implement.settings.color.component.ColorEditorComponent;
import project.papus.implement.screens.menu.components.implement.window.implement.settings.color.component.ColorPresetComponent;
import project.papus.implement.screens.menu.components.implement.window.implement.settings.color.component.HueComponent;
import project.papus.implement.screens.menu.components.implement.window.implement.settings.color.component.SaturationComponent;

public class ColorWindow extends AbstractWindow {
   private static final float HEADER_HEIGHT = 22.0F;
   private final ColorSetting setting;
   private final List<AbstractComponent> components = new ArrayList<>();
   private final SaturationComponent saturationComponent;
   private final HueComponent hueComponent;
   private final AlphaComponent alphaComponent;
   private final ColorEditorComponent colorEditorComponent;
   private final ColorPresetComponent colorPresetComponent;

   public ColorWindow(ColorSetting var1) {
      this.setting = var1;
      this.components
         .addAll(
            Arrays.asList(
               this.saturationComponent = new SaturationComponent(var1),
               this.hueComponent = new HueComponent(var1),
               this.alphaComponent = new AlphaComponent(var1),
               this.colorEditorComponent = new ColorEditorComponent(var1),
               this.colorPresetComponent = new ColorPresetComponent(var1)
            )
         );
   }

   @Override
   public void renderWindow(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      float var6 = this.y + 22.0F;
      this.alphaComponent.position(this.x, var6);
      this.saturationComponent.position(this.x, var6);
      this.hueComponent.position(this.x, var6);
      this.colorEditorComponent.position(this.x, var6);
      float var7 = ((ColorPresetComponent)this.colorPresetComponent.position(this.x, var6)).getWindowHeight() + 10.0F;
      this.height = 22.0F + var7;
      blur.render(
         ShapeProperties.create(var5, this.x, this.y, this.width + 1.5F, this.height)
            .round(9.0F)
            .quality(18.0F)
            .color(new Color(8, 8, 8, 230).getRGB())
            .build()
      );
      rectangle.render(
         ShapeProperties.create(var5, this.x, this.y, this.width + 1.5F, 22.0)
            .round(9.0F, 0.0F, 9.0F, 0.0F)
            .softness(0.0F)
            .color(ColorUtil.getColor(255, 255, 255, 10))
            .build()
      );
      rectangle.renderOutline(
         ShapeProperties.create(var5, this.x, this.y, this.width + 1.5F, this.height)
            .round(9.0F)
            .softness(0.0F)
            .outlineColor(ColorUtil.getOutlineColor())
            .build(),
         1.5F
      );
      Fonts.getSize(15, Fonts.Type.DEFAULT).drawString(var5, this.setting.getName(), this.x + 9.0F, this.y + 10.0F, ColorUtil.getColor(255, 255, 255, 255));
      this.components.forEach(var4x -> var4x.render(var1, var2, var3, var4));
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      this.setDraggable(MathUtil.isHovered(var1, var3, this.x, this.y, this.width, 22.0));
      this.components.forEach(var5x -> var5x.mouseClicked(var1, var3, var5));
      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean mouseScrolled(double var1, double var3, double var5) {
      this.components.forEach(var6 -> var6.mouseScrolled(var1, var3, var5));
      return super.mouseScrolled(var1, var3, var5);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.components.forEach(var5x -> var5x.mouseReleased(var1, var3, var5));
      return super.mouseReleased(var1, var3, var5);
   }
}
