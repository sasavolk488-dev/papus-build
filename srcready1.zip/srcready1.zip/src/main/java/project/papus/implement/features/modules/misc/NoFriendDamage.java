package project.papus.implement.features.modules.misc;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.implement.events.player.AttackEvent;

public class NoFriendDamage extends Module {
   private static NoFriendDamage instance;

   public static NoFriendDamage getInstance() {
      return instance;
   }

   public NoFriendDamage() {
      super("NoFriendDamage", "NoFriendDamage", ModuleCategory.MISC);
      instance = this;
   }

   @EventHandler
   public void onAttack(AttackEvent var1) {
      if (mc.player != null) {
         Entity var2 = var1.getEntity();
         if (var2 != null) {
            if (var2 instanceof PlayerEntity) {
               String var3 = ((PlayerEntity)var2).getName().getString();
               boolean var4 = FriendUtils.getFriends().stream().anyMatch(var1x -> var1x.getName().equals(var3));
               if (var4) {
                  var1.setCancelled(true);
               }
            }
         }
      }
   }
}
