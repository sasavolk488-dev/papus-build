package project.papus.implement.screens.menu.components.implement.window.implement.settings.color.component;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import project.papus.api.feature.module.setting.implement.ColorSetting;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class AlphaComponent extends AbstractComponent {
   private final ColorSetting setting;
   private boolean sliding;
   private float X;
   private float Y;
   private float W;
   private float H;

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      this.X = this.x + 6.0F;
      this.Y = this.y + 83.5F;
      this.W = 138.0F;
      this.H = 4.0F;
      float var6 = MathHelper.clamp(this.X + this.W * this.setting.getAlpha(), this.X, this.X + this.W - 4.0F);
      float var7 = MathHelper.clamp((var2 - this.X) / this.W, 0.0F, 1.0F);
      image.setTexture("textures/alpha.png").render(ShapeProperties.create(var5, this.X, this.Y, this.W, this.H).build());
      rectangle.render(
         ShapeProperties.create(var5, this.X, this.Y - 0.2, this.W + 0.5, this.H)
            .round(1.5F)
            .color(Integer.MIN_VALUE, 134217728, this.setting.getColorWithAlpha(), this.setting.getColorWithAlpha())
            .build()
      );
      rectangle.render(ShapeProperties.create(var5, var6, this.Y, this.H, this.H).round(this.H / 2.0F).thickness(3.0F).color(16777215).outlineColor(-1).build());
      if (this.sliding) {
         this.setting.setAlpha(var7);
      }
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      this.sliding = var5 == 0 && MathUtil.isHovered(var1, var3, this.X, this.Y, this.W, this.H);
      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.sliding = false;
      return super.mouseReleased(var1, var3, var5);
   }

   public AlphaComponent(ColorSetting var1) {
      this.setting = var1;
   }
}
