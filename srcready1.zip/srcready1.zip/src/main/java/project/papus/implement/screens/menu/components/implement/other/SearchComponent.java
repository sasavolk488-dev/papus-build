package project.papus.implement.screens.menu.components.implement.other;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;
import project.papus.api.system.font.FontRenderer;
import project.papus.api.system.font.Fonts;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class SearchComponent extends AbstractComponent {
   public static boolean typing = false;
   private boolean dragging;
   private int cursorPosition = 0;
   private int selectionStart = -1;
   private int selectionEnd = -1;
   private long lastClickTime = 0L;
   private float xOffset = 0.0F;
   private String text = "";

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height) && var5 == 0) {
         long var6 = System.currentTimeMillis();
         if (var6 - this.lastClickTime < 250L) {
            this.selectionStart = 0;
            this.selectionEnd = this.text.length();
         } else {
            typing = true;
            this.dragging = true;
            this.lastClickTime = var6;
            this.cursorPosition = this.getCursorIndexAt(var1);
            this.selectionStart = this.cursorPosition;
            this.selectionEnd = this.cursorPosition;
         }
      } else {
         typing = false;
         this.clearSelection();
      }

      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.dragging = false;
      return super.mouseReleased(var1, var3, var5);
   }

   @Override
   public boolean charTyped(char var1, int var2) {
      if (typing && Fonts.getSize(12).getStringWidth(this.text) < 55.0F) {
         this.deleteSelectedText();
         this.text = this.text.substring(0, this.cursorPosition) + var1 + this.text.substring(this.cursorPosition);
         this.cursorPosition++;
         this.clearSelection();
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      if (typing) {
         if (Screen.hasControlDown()) {
            switch (var1) {
               case 65:
                  this.selectAllText();
                  break;
               case 67:
                  this.copyToClipboard();
                  break;
               case 86:
                  this.pasteFromClipboard();
            }
         } else {
            switch (var1) {
               case 257:
               case 259:
                  this.handleBackspaceOrEnter(var1);
               case 258:
               case 260:
               case 261:
               default:
                  break;
               case 262:
               case 263:
                  this.moveCursor(var1);
            }
         }
      }

      return super.keyPressed(var1, var2, var3);
   }

   private void pasteFromClipboard() {
      String var1 = GLFW.glfwGetClipboardString(window.getHandle());
      if (var1 != null) {
         this.replaceText(this.cursorPosition, this.cursorPosition, var1);
      }
   }

   private void copyToClipboard() {
      if (this.hasSelection()) {
         GLFW.glfwSetClipboardString(window.getHandle(), this.getSelectedText());
      }
   }

   private void selectAllText() {
      this.selectionStart = 0;
      this.selectionEnd = this.text.length();
   }

   private void handleBackspaceOrEnter(int var1) {
      if (var1 == 259) {
         if (this.hasSelection()) {
            this.replaceText(this.getStartOfSelection(), this.getEndOfSelection(), "");
         } else if (this.cursorPosition > 0) {
            this.replaceText(this.cursorPosition - 1, this.cursorPosition, "");
         }
      } else if (var1 == 257) {
         typing = false;
      }
   }

   private void moveCursor(int var1) {
      if (var1 == 263 && this.cursorPosition > 0) {
         this.cursorPosition--;
      } else if (var1 == 262 && this.cursorPosition < this.text.length()) {
         this.cursorPosition++;
      }

      this.updateSelectionAfterMove();
   }

   private void updateSelectionAfterMove() {
      if (Screen.hasShiftDown()) {
         if (this.selectionStart == -1) {
            this.selectionStart = this.cursorPosition;
         }

         this.selectionEnd = this.cursorPosition;
      } else {
         this.clearSelection();
      }
   }

   private void replaceText(int var1, int var2, String var3) {
      if (var1 < 0) {
         var1 = 0;
      }

      if (var2 > this.text.length()) {
         var2 = this.text.length();
      }

      if (var1 > var2) {
         var1 = var2;
      }

      this.text = this.text.substring(0, var1) + var3 + this.text.substring(var2);
      this.cursorPosition = var1 + var3.length();
      this.clearSelection();
   }

   private boolean hasSelection() {
      return this.selectionStart != -1 && this.selectionEnd != -1 && this.selectionStart != this.selectionEnd;
   }

   private String getSelectedText() {
      return this.text.substring(this.getStartOfSelection(), this.getEndOfSelection());
   }

   private int getStartOfSelection() {
      return Math.min(this.selectionStart, this.selectionEnd);
   }

   private int getEndOfSelection() {
      return Math.max(this.selectionStart, this.selectionEnd);
   }

   private void clearSelection() {
      this.selectionStart = -1;
      this.selectionEnd = -1;
   }

   private int getCursorIndexAt(double var1) {
      FontRenderer var3 = Fonts.getSize(12, Fonts.Type.BOLD);
      float var4 = (float)var1 - this.x - 3.0F + this.xOffset;

      int var5;
      for (var5 = 0; var5 < this.text.length(); var5++) {
         float var6 = var3.getStringWidth(this.text.substring(0, var5 + 1));
         if (var6 > var4) {
            break;
         }
      }

      return var5;
   }

   private void updateXOffset(FontRenderer var1, int var2) {
      float var3 = var1.getStringWidth(this.text.substring(0, var2));
      if (var3 < this.xOffset) {
         this.xOffset = var3;
      } else if (var3 - this.xOffset > this.width - 7.0F) {
         this.xOffset = var3 - (this.width - 7.0F);
      }
   }

   private void deleteSelectedText() {
      if (this.hasSelection()) {
         this.replaceText(this.getStartOfSelection(), this.getEndOfSelection(), "");
      }
   }

   public String getText() {
      return this.text;
   }
}
