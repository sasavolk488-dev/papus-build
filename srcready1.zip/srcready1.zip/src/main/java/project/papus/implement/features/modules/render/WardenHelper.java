package project.papus.implement.features.modules.render;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.BindSetting;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.render.Render3DUtil;
import project.papus.implement.events.keyboard.KeyEvent;
import project.papus.implement.events.player.TickEvent;
import project.papus.implement.events.render.WorldRenderEvent;

public class WardenHelper extends Module {
   private final BindSetting resetChestsBind = new BindSetting("\u0421\u0431\u0440\u043e\u0441 \u0441\u0443\u043d\u0434\u0443\u043a\u043e\u0432", "");
   private final Map<BlockPos, Long> trackedChests = new HashMap<>();
   private BlockPos lastPlayerPos = null;

   public WardenHelper() {
      super("WardenHelper", "Warden Helper", ModuleCategory.RENDER);
      this.setup(this.resetChestsBind);
   }

   @Override
   public void deactivate() {
      this.trackedChests.clear();
      this.lastPlayerPos = null;
      super.deactivate();
   }

   @EventHandler
   public void onKey(KeyEvent var1) {
      if (var1.key() == this.resetChestsBind.getKey() && var1.action() == 1) {
         this.trackedChests.clear();
      }
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      if (this.isState()) {
         if (mc.player != null && mc.world != null) {
            BlockPos var2 = new BlockPos((int)mc.player.getX(), (int)mc.player.getY(), (int)mc.player.getZ());
            if (this.lastPlayerPos != null) {
               double var3 = var2.getX() - this.lastPlayerPos.getX();
               double var5 = var2.getZ() - this.lastPlayerPos.getZ();
               if (var3 * var3 + var5 * var5 > 250000.0) {
                  this.trackedChests.clear();
               }
            }

            this.lastPlayerPos = var2;

            for (Entity var4 : mc.world.getEntities()) {
               if (var4 instanceof ArmorStandEntity) {
                  String var14 = var4.getName().getString();
                  if (var14.matches("(\\d{2}):(\\d{2})")) {
                     BlockPos var6 = new BlockPos((int)var4.getX(), (int)var4.getY(), (int)var4.getZ());
                     String[] var7 = var14.split(":");
                     int var8 = Integer.parseInt(var7[0]);
                     int var9 = Integer.parseInt(var7[1]);
                     long var10 = var8 * 60L + var9;
                     BlockPos var12 = this.findNearbyChest(var6);
                     if (var12 != null) {
                        if (var10 == 0L) {
                           this.trackedChests.put(var12, 0L);
                        } else {
                           this.trackedChests.put(var12, System.currentTimeMillis() + var10 * 1000L);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private BlockPos findNearbyChest(BlockPos var1) {
      for (int var2 = -2; var2 <= 2; var2++) {
         for (int var3 = -2; var3 <= 2; var3++) {
            for (int var4 = -2; var4 <= 2; var4++) {
               BlockPos var5 = var1.add(var2, var3, var4);
               if (mc.world.getBlockState(var5).getBlock().toString().toLowerCase().contains("chest")) {
                  return var5;
               }
            }
         }
      }

      return null;
   }

   @EventHandler
   public void onWorldRender(WorldRenderEvent var1) {
      if (this.isState()) {
         long var2 = System.currentTimeMillis();

         for (Entry var5 : this.trackedChests.entrySet()) {
            BlockPos var6 = (BlockPos)var5.getKey();
            long var7 = (Long)var5.getValue();
            int var9;
            int var10;
            if (var7 != 0L && var2 < var7) {
               if (var7 - var2 <= 30000L) {
                  var9 = ColorUtil.getColor(255, 255, 0, 255);
                  var10 = ColorUtil.getColor(255, 255, 0, 50);
               } else {
                  var9 = ColorUtil.getColor(255, 0, 0, 255);
                  var10 = ColorUtil.getColor(255, 0, 0, 50);
               }
            } else {
               var9 = ColorUtil.getColor(0, 255, 0, 255);
               var10 = ColorUtil.getColor(0, 255, 0, 50);
            }

            Box var11 = new Box(var6.getX(), var6.getY(), var6.getZ(), var6.getX() + 1, var6.getY() + 1, var6.getZ() + 1);
            Render3DUtil.drawBox(var1.getStack().peek(), var11, var9, var10, 0.0F, false, true, false);
         }
      }
   }
}
