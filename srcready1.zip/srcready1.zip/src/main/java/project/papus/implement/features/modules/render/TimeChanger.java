package project.papus.implement.features.modules.render;

import java.lang.reflect.Field;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.common.util.other.Instance;
import project.papus.implement.events.player.TickEvent;

public class TimeChanger extends Module {
   public final SelectSetting timeSetting = new SelectSetting(
         "\u0412\u0440\u0435\u043c\u044f", "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0432\u0440\u0435\u043c\u044f \u0441\u0443\u0442\u043e\u043a"
      )
      .value(
         "\u0414\u0435\u043d\u044c",
         "\u041d\u043e\u0447\u044c",
         "\u0412\u0435\u0447\u0435\u0440",
         "\u0420\u0430\u0441\u0441\u0432\u0435\u0442",
         "\u0417\u0430\u043a\u0430\u0442"
      )
      .selected("\u0414\u0435\u043d\u044c");

   public static TimeChanger getInstance() {
      return Instance.get(TimeChanger.class);
   }

   public TimeChanger() {
      super("TimeChanger", "Time Changer", ModuleCategory.RENDER);
      this.setup(this.timeSetting);
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      if (mc.world != null) {
         if (this.isState()) {
            String var2 = this.timeSetting.getSelected();
            long var3 = this.getTimeByName(var2);
            mc.world.getLevelProperties().setTimeOfDay(var3);
         }
      }
   }

   private long getTimeByName(String var1) {
      return switch (var1) {
         case "\u0414\u0435\u043d\u044c" -> 6000L;
         case "\u041d\u043e\u0447\u044c" -> 18000L;
         case "\u0412\u0435\u0447\u0435\u0440" -> 13000L;
         case "\u0420\u0430\u0441\u0441\u0432\u0435\u0442" -> 23000L;
         case "\u0417\u0430\u043a\u0430\u0442" -> 12000L;
         default -> 6000L;
      };
   }

   @Override
   public void deactivate() {
      super.deactivate();
   }
}
