package project.papus.implement.events.render;

import project.papus.api.event.events.callables.EventCancellable;
import project.papus.common.util.rotation.Angle;

public class CameraEvent extends EventCancellable {
   private boolean cameraClip;
   private float distance;
   private Angle angle;

   public boolean isCameraClip() {
      return this.cameraClip;
   }

   public float getDistance() {
      return this.distance;
   }

   public Angle getAngle() {
      return this.angle;
   }

   public void setCameraClip(boolean var1) {
      this.cameraClip = var1;
   }

   public void setDistance(float var1) {
      this.distance = var1;
   }

   public void setAngle(Angle var1) {
      this.angle = var1;
   }

   public CameraEvent(boolean var1, float var2, Angle var3) {
      this.cameraClip = var1;
      this.distance = var2;
      this.angle = var3;
   }
}
