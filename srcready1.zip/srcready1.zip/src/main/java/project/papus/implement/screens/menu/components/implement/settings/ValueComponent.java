package project.papus.implement.screens.menu.components.implement.settings;

import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.render.ScissorManager;
import project.papus.core.Main;

public class ValueComponent extends AbstractSettingComponent {
   private final ValueSetting setting;
   private boolean sliding;
   private double animatedWidth;
   private float unusedPadding;

   public ValueComponent(ValueSetting var1) {
      super(var1);
      this.setting = var1;
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      float var6 = Fonts.getSize(12, Fonts.Type.DEFAULT).getStringWidth(this.setting.getName());
      this.height = 17.0F;
      String var7 = String.valueOf(this.setting.getValue());
      this.y -= 6.0F;
      Fonts.getSize(13, Fonts.Type.DEFAULT)
         .drawString(var5, var7, this.x + this.width - 92.0F - Fonts.getSize(12).getStringWidth(var7), this.y + 15.0F, ColorUtil.getTextColor());
      if (this.sliding) {
         this.updateSliderValue(var2);
      }

      this.renderSlider(var5);
      float var8 = 62.0F;
      if (var6 > 62.0F) {
         ScissorManager var9 = Main.getInstance().getScissorManager();
         var9.push(var5.peek().getPositionMatrix(), this.x + 5.0F, this.y + 12.0F, 65.0F, 50.0F);
         Fonts.getSize(13, Fonts.Type.DEFAULT)
            .drawGradientString(var5, this.setting.getName(), this.x + 3.0F, this.y + 15.5F, var8, new Color(225, 225, 225, 225).getRGB());
         var9.pop();
      } else {
         Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(var5, this.setting.getName(), this.x + 11.0F, this.y + 14.5F, -2828575);
      }
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      this.sliding = MathUtil.isHovered(var1, var3, this.x + this.width - 80.0F - 9.0F, this.y + 12.0F, 80.0, 8.0) && var5 == 0;
      return super.mouseClicked(var1, var3, var5);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.sliding = false;
      return super.mouseReleased(var1, var3, var5);
   }

   private void renderSlider(MatrixStack var1) {
      float var2 = this.setting.getMin();
      float var3 = this.setting.getMax();
      float var4 = var3 - var2;
      float var5 = var4 <= 0.0F ? 0.0F : 80.0F * (this.setting.getValue() - var2) / var4;
      var5 = MathHelper.clamp(var5, 0.0F, 80.0F);
      if (this.sliding) {
         this.animatedWidth = var5;
      } else {
         this.animatedWidth = MathUtil.interpolateSmooth(5.0, this.animatedWidth, (double)var5);
      }

      rectangle.render(ShapeProperties.create(var1, this.x + this.width - 80.0F - 9.0F, this.y + 15.0F, 80.0, 3.0).round(1.0F).color(758006093).build());
      rectangle.render(
         ShapeProperties.create(var1, this.x + this.width - 80.0F - 9.0F, this.y + 15.0F, (float)this.animatedWidth, 3.0)
            .round(1.0F)
            .color(new Color(255, 255, 255, 255).getRGB())
            .build()
      );
      float var6 = MathHelper.clamp((float)(this.x + this.width - 80.0F + this.animatedWidth), 0.0F, this.x + this.width - 4.0F);
      rectangle.render(ShapeProperties.create(var1, var6 - 10.5F, this.y + 12.5F, 7.0, 7.0).round(3.0F).color(ColorUtil.getClientColor()).build());
      rectangle.render(
         ShapeProperties.create(var1, var6 - 10.0F, this.y + 13.5F, 6.0, 6.0)
            .round(3.0F)
            .thickness(2.0F)
            .softness(0.0F)
            .color(new Color(255, 255, 255, 255).getRGB())
            .build()
      );
   }

   private void updateSliderValue(int var1) {
      float var2 = this.x + this.width - 80.0F - 9.0F;
      float var3 = 80.0F;
      float var4 = MathHelper.clamp(var1 - var2, 0.0F, var3);
      float var5 = var4 / var3;
      float var6 = this.setting.getMax() - this.setting.getMin();
      float var7 = this.setting.getMin() + var5 * var6;
      if (this.setting.isInteger()) {
         var7 = Math.round(var7);
      } else {
         BigDecimal var8 = BigDecimal.valueOf((double)var7).setScale(2, RoundingMode.HALF_UP);
         var7 = var8.floatValue();
      }

      var7 = MathHelper.clamp(var7, this.setting.getMin(), this.setting.getMax());
      this.setting.setValue(var7);
   }
}
