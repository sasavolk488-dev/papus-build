package project.papus.implement.events.block;

import net.minecraft.block.entity.BlockEntity;
import project.papus.api.event.events.Event;

public record BlockEntityProgressEvent(BlockEntity blockEntity, BlockEntityProgressEvent.Type type) implements Event {
   public static enum Type {
      ADD,
      REMOVE;
   }
}
