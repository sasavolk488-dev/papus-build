package project.papus.implement.features.modules.render;

import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.BindSetting;
import project.papus.common.util.entity.PlayerHealthUtil;
import project.papus.common.util.rotation.Angle;
import project.papus.common.util.rotation.AngleUtil;
import project.papus.implement.events.keyboard.KeyEvent;
import project.papus.implement.events.keyboard.MouseRotationEvent;
import project.papus.implement.events.render.CameraEvent;
import project.papus.implement.events.render.FovEvent;

public class FreeLook extends Module {
   private Perspective savedPerspective;
   private Angle cameraAngle;
   private final BindSetting keySetting = new BindSetting("Key", "");

   public FreeLook() {
      super("FreeLook", "Free Look", ModuleCategory.RENDER);
      this.setup(this.keySetting);
   }

   @EventHandler
   public void onKey(KeyEvent var1) {
      if (var1.key() == this.keySetting.getKey() && var1.action() == 1) {
         this.savedPerspective = mc.options.getPerspective();
      }
   }

   @EventHandler
   public void onFov(FovEvent var1) {
      if (PlayerHealthUtil.isKey(this.keySetting)) {
         if (mc.options.getPerspective().isFirstPerson()) {
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
         }
      } else if (this.savedPerspective != null) {
         mc.options.setPerspective(this.savedPerspective);
         this.savedPerspective = null;
      }
   }

   @EventHandler
   public void onMouseRotation(MouseRotationEvent var1) {
      if (PlayerHealthUtil.isKey(this.keySetting)) {
         if (this.cameraAngle == null) {
            this.cameraAngle = AngleUtil.cameraAngle();
         }

         this.cameraAngle.setYaw(this.cameraAngle.getYaw() + var1.getCursorDeltaX() * 0.15F);
         this.cameraAngle.setPitch(MathHelper.clamp(this.cameraAngle.getPitch() + var1.getCursorDeltaY() * 0.15F, -90.0F, 90.0F));
         var1.cancel();
      } else {
         this.cameraAngle = AngleUtil.cameraAngle();
      }
   }

   @EventHandler
   public void onCamera(CameraEvent var1) {
      if (PlayerHealthUtil.isKey(this.keySetting) && this.cameraAngle != null) {
         var1.setCameraClip(false);
         var1.setDistance(4.0F);
         var1.setAngle(this.cameraAngle);
         var1.cancel();
      }
   }
}
