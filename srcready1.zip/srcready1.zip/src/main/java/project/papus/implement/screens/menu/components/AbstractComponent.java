package project.papus.implement.screens.menu.components;

import net.minecraft.client.gui.DrawContext;
import project.papus.common.QuickImports;

public abstract class AbstractComponent implements QuickImports {
   public float x;
   public float y;
   public float width;
   public float height;
   public double scroll = 0.0;
   public double smoothedScroll = 0.0;

   public boolean isHover(double var1, double var3) {
      return var1 >= this.x && var1 <= this.x + this.width && var3 >= this.y && var3 <= this.y + this.height;
   }

   public void render(DrawContext var1, int var2, int var3, float var4) {
   }

   public void tick() {
   }

   public boolean mouseClicked(double var1, double var3, int var5) {
      return false;
   }

   public boolean mouseReleased(double var1, double var3, int var5) {
      return false;
   }

   public boolean mouseDragged(double var1, double var3, int var5, double var6, double var8) {
      return false;
   }

   public boolean mouseScrolled(double var1, double var3, double var5) {
      return false;
   }

   public boolean keyPressed(int var1, int var2, int var3) {
      return false;
   }

   public boolean charTyped(char var1, int var2) {
      return false;
   }

   public AbstractComponent position(float var1, float var2) {
      this.x = var1;
      this.y = var2;
      return this;
   }

   public AbstractComponent size(float var1, float var2) {
      this.width = var1;
      this.height = var2;
      return this;
   }
}
