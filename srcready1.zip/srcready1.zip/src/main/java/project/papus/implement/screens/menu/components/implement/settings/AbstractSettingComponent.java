package project.papus.implement.screens.menu.components.implement.settings;

import project.papus.api.feature.module.setting.Setting;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public abstract class AbstractSettingComponent extends AbstractComponent {
   private final Setting setting;

   @Override
   public boolean isHover(double var1, double var3) {
      return MathUtil.isHovered(var1, var3, this.x, this.y, this.width, this.height);
   }

   public Setting getSetting() {
      return this.setting;
   }

   public AbstractSettingComponent(Setting var1) {
      this.setting = var1;
   }
}
