package project.papus.implement.events.player;

import project.papus.api.event.events.Event;

public class ListsCheckEvent implements Event {
}
