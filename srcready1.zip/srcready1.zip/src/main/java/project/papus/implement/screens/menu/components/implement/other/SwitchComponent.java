package project.papus.implement.screens.menu.components.implement.other;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.system.animation.Animation;
import project.papus.api.system.animation.Direction;
import project.papus.api.system.animation.implement.DecelerateAnimation;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class SwitchComponent extends AbstractComponent {
   private boolean state;
   private Runnable action;
   private float switchWidth = 24.0F;
   private float switchHeight = 12.0F;
   private final Animation knobAnimation = new DecelerateAnimation().setMs(200).setValue(this.switchHeight - 4.0F);
   private final Animation alphaAnimation = new DecelerateAnimation().setMs(200).setValue(255.0);

   public SwitchComponent setSwitchSize(float var1, float var2) {
      this.switchWidth = var1;
      this.switchHeight = var2;
      this.knobAnimation.setValue(var2 - 1.0F);
      return this;
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      this.knobAnimation.setDirection(this.state ? Direction.FORWARDS : Direction.BACKWARDS);
      this.alphaAnimation.setDirection(this.state ? Direction.FORWARDS : Direction.BACKWARDS);
      float var6 = this.knobAnimation.getOutput().floatValue();
      int var7 = this.alphaAnimation.getOutput().intValue();
      int var8 = this.state ? ColorUtil.getColor(255, 255, 255, 25) : ColorUtil.getColor(40, 40, 40, 100);
      rectangle.render(ShapeProperties.create(var5, this.x, this.y, this.switchWidth, this.switchHeight).round(this.switchHeight / 2.0F).color(var8).build());
      rectangle.renderOutline(
         ShapeProperties.create(var5, this.x, this.y, this.switchWidth, this.switchHeight)
            .round(this.switchHeight / 2.0F)
            .softness(0.0F)
            .outlineColor(ColorUtil.getOutlineColor())
            .build(),
         1.5F
      );
      float var9 = this.switchHeight - 4.0F;
      float var10 = this.x + 2.5F + var6;
      float var11 = this.y + 2.0F;
      rectangle.render(ShapeProperties.create(var5, var10, var11, var9, var9).round(var9 / 2.0F).color(ColorUtil.getColor(255, 255, 255, 255)).build());
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (MathUtil.isHovered(var1, var3, this.x, this.y, this.switchWidth, this.switchHeight) && var5 == 0) {
         if (this.action != null) {
            this.action.run();
         }

         return true;
      } else {
         return super.mouseClicked(var1, var3, var5);
      }
   }

   public SwitchComponent setState(boolean var1) {
      this.state = var1;
      return this;
   }

   public SwitchComponent setAction(Runnable var1) {
      this.action = var1;
      return this;
   }

   public SwitchComponent setSwitchWidth(float var1) {
      this.switchWidth = var1;
      return this;
   }

   public SwitchComponent setSwitchHeight(float var1) {
      this.switchHeight = var1;
      return this;
   }
}
