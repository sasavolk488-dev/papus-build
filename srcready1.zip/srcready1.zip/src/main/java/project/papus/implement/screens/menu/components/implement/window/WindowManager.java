package project.papus.implement.screens.menu.components.implement.window;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class WindowManager extends AbstractComponent {
   private final List<AbstractWindow> windows = new ArrayList<>();

   public void add(AbstractWindow var1) {
      this.windows.add(var1);
   }

   public void delete(AbstractWindow var1) {
      var1.startCloseAnimation();
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      ArrayList var5 = new ArrayList();
      this.windows.forEach(var5x -> {
         var5x.render(var1, var2, var3, var4);
         if (var5x.isCloseAnimationFinished()) {
            var5.add(var5x);
         }
      });
      this.windows.removeAll(var5);
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      boolean var6 = false;
      ArrayList var7 = new ArrayList<>(this.windows);

      for (int var8 = var7.size() - 1; var8 >= 0; var8--) {
         AbstractWindow var9 = (AbstractWindow)var7.get(var8);
         if (var9.isHovered(var1, var3) || this.isHover(var1, var3)) {
            var6 = true;
            var9.mouseClicked(var1, var3, var5);
            break;
         }
      }

      if (var6) {
         return var6;
      } else {
         for (AbstractWindow var11 : this.windows) {
            var11.startCloseAnimation();
         }

         return false;
      }
   }

   @Override
   public boolean isHover(double var1, double var3) {
      for (AbstractWindow var6 : this.windows) {
         if (var6.isHovered(var1, var3)) {
            return true;
         }
      }

      return false;
   }

   @Override
   public boolean charTyped(char var1, int var2) {
      this.windows.forEach(var2x -> var2x.charTyped(var1, var2));
      return super.charTyped(var1, var2);
   }

   @Override
   public boolean mouseScrolled(double var1, double var3, double var5) {
      for (AbstractWindow var8 : this.windows) {
         if (var8.mouseScrolled(var1, var3, var5)) {
            return true;
         }
      }

      return super.mouseScrolled(var1, var3, var5);
   }

   @Override
   public boolean keyPressed(int var1, int var2, int var3) {
      for (AbstractWindow var5 : this.windows) {
         if (var5.keyPressed(var1, var2, var3)) {
            return true;
         }
      }

      return super.keyPressed(var1, var2, var3);
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.windows.forEach(var5x -> var5x.mouseReleased(var1, var3, var5));
      return super.mouseReleased(var1, var3, var5);
   }

   public List<AbstractWindow> getWindows() {
      return this.windows;
   }
}
