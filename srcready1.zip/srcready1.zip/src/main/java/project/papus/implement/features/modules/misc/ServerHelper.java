package project.papus.implement.features.modules.misc;

import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.BindSetting;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.common.util.entity.PlayerInventoryUtil;
import project.papus.common.util.other.StopWatch;
import project.papus.common.util.task.scripts.Script;
import project.papus.implement.events.keyboard.HotBarScrollEvent;
import project.papus.implement.events.keyboard.KeyEvent;
import project.papus.implement.events.player.KeyboardInputEvent;
import project.papus.implement.events.player.TickEvent;

public class ServerHelper extends Module {
   private final BindSetting disorientBind = new BindSetting("\u0414\u0435\u0437\u043e\u0440\u0438\u0435\u043d\u0442\u0430\u0446\u0438\u044f", "Key");
   private final BindSetting trapBind = new BindSetting("\u0422\u0440\u0430\u043f\u043a\u0430", "Key");
   private final BindSetting fireWhirlwindBind = new BindSetting("\u041e\u0433\u043d\u0435\u043d\u043d\u044b\u0439 \u0441\u043c\u0435\u0440\u0447", "Key");
   private final BindSetting brightDustBind = new BindSetting("\u042f\u0432\u043d\u0430\u044f \u043f\u044b\u043b\u044c", "Key");
   private final BindSetting plastBind = new BindSetting("\u041f\u043b\u0430\u0441\u0442", "Key");
   private final BindSetting freezeSnowballBind = new BindSetting(
      "\u0421\u043d\u0435\u0436\u043e\u043a \u0437\u0430\u043c\u043e\u0440\u043e\u0437\u043a\u0430", "Key"
   );
   private final BindSetting godAuraBind = new BindSetting("\u0411\u043e\u0436\u044c\u044f \u0430\u0443\u0440\u0430", "Key");
   private final BindSetting windChargeBind = new BindSetting("\u0417\u0430\u0440\u044f\u0434 \u0432\u0435\u0442\u0440\u0430", "Key");
   private final SelectSetting modeSetting = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "")
      .value("FunTime", "\u0414\u0440\u0443\u0433\u0438\u0435 \u0441\u0435\u0440\u0432\u0435\u0440\u0430")
      .selected("FunTime");
   private final Script script = new Script();
   private final StopWatch stopWatch = new StopWatch();
   private final Random random = new Random();
   private boolean slownessActive = false;
   private String pendingItem = null;
   private int savedHotbarSlot = -1;
   private int scrollLockTicks = -1;
   private static final int SCROLL_LOCK_DURATION = 48;

   public ServerHelper() {
      super("FunTimeHelper", "FunTime Helper", ModuleCategory.MISC);
      this.setup(
         this.modeSetting,
         this.disorientBind,
         this.trapBind,
         this.fireWhirlwindBind,
         this.brightDustBind,
         this.plastBind,
         this.freezeSnowballBind,
         this.godAuraBind,
         this.windChargeBind
      );
   }

   @Override
   public void deactivate() {
      this.resetState();
      super.deactivate();
   }

   private void resetState() {
      this.slownessActive = false;
      this.pendingItem = null;
      this.savedHotbarSlot = -1;
      this.scrollLockTicks = -1;
      this.script.cleanup();
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      this.script.update();
      if (this.slownessActive && mc.player != null) {
         mc.player.setSprinting(false);
      }
   }

   @EventHandler
   public void onKeyboardInput(KeyboardInputEvent var1) {
      if (this.slownessActive) {
         var1.resetDirectional();
      }
   }

   @EventHandler
   public void onHotBarScroll(HotBarScrollEvent var1) {
      if (this.slownessActive) {
         var1.setCancelled(true);
      }
   }

   @EventHandler
   public void onKey(KeyEvent var1) {
      if (var1.action() == 1 && mc.player != null) {
         if (mc.currentScreen == null) {
            if (!this.slownessActive && this.script.isFinished()) {
               if (this.stopWatch.every(1.0)) {
                  if (!this.modeSetting.getSelected().equals("\u0414\u0440\u0443\u0433\u0438\u0435 \u0441\u0435\u0440\u0432\u0435\u0440\u0430")
                     || mc.player.isOnGround()) {
                     int var2 = var1.key();
                     String var3 = null;
                     if (var2 == this.disorientBind.getKey()) {
                        var3 = "\u0434\u0435\u0437\u043e\u0440";
                     } else if (var2 == this.trapBind.getKey()) {
                        var3 = "\u0442\u0440\u0430\u043f\u043a";
                     } else if (var2 == this.fireWhirlwindBind.getKey()) {
                        var3 = "\u043e\u0433\u043d\u0435\u043d";
                     } else if (var2 == this.brightDustBind.getKey()) {
                        var3 = "\u044f\u0432\u043d\u0430\u044f";
                     } else if (var2 == this.plastBind.getKey()) {
                        var3 = "\u043f\u043b\u0430\u0441\u0442";
                     } else if (var2 == this.freezeSnowballBind.getKey()) {
                        var3 = "\u0441\u043d\u0435\u0436\u043e\u043a \u0437";
                     } else if (var2 == this.godAuraBind.getKey()) {
                        var3 = "\u0431\u043e\u0436\u044c\u044f";
                     } else if (var2 == this.windChargeBind.getKey()) {
                        var3 = "\u0437\u0430\u0440\u044f\u0434";
                     }

                     if (var3 != null) {
                        int var4 = this.findItemSlot(var3);
                        if (var4 != -1) {
                           int var6 = mc.player.inventory.selectedSlot;
                           this.script.cleanup();
                           this.slownessActive = true;
                           byte var7 = 48;
                           if (var4 < 9) {
                              this.script
                                 .addTickStep(var7 + this.random.nextInt(15), () -> mc.player.inventory.selectedSlot = var4)
                                 .addTickStep(var7 + this.random.nextInt(15), () -> {
                                    mc.player.swingHand(Hand.MAIN_HAND);
                                    mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                                 })
                                 .addTickStep(var7 + this.random.nextInt(15), () -> {
                                    mc.player.inventory.selectedSlot = var6;
                                    this.resetState();
                                    this.stopWatch.reset();
                                 });
                           } else {
                              this.pendingItem = var3;
                              this.savedHotbarSlot = var4;
                              this.scrollLockTicks = var6;
                              this.script
                                 .addTickStep(
                                    var7 + this.random.nextInt(15),
                                    () -> PlayerInventoryUtil.clickSlot(this.savedHotbarSlot, this.scrollLockTicks, SlotActionType.SWAP, false)
                                 )
                                 .addTickStep(var7 + this.random.nextInt(15), () -> {
                                    mc.player.swingHand(Hand.MAIN_HAND);
                                    mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                                 })
                                 .addTickStep(var7 + this.random.nextInt(20), () -> {
                                    ItemStack var1x = mc.player.inventory.getStack(this.savedHotbarSlot);
                                    if (!var1x.isEmpty()) {
                                       PlayerInventoryUtil.clickSlot(this.savedHotbarSlot, this.scrollLockTicks, SlotActionType.SWAP, false);
                                    }

                                    this.resetState();
                                    this.stopWatch.reset();
                                 });
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private int findItemSlot(String var1) {
      for (int var2 = 0; var2 < 36; var2++) {
         ItemStack var3 = mc.player.inventory.getStack(var2);
         if (!var3.isEmpty() && var3.getName().getString().toLowerCase().contains(var1.toLowerCase())) {
            return var2;
         }
      }

      return -1;
   }
}
