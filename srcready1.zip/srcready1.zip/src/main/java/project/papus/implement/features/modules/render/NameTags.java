package project.papus.implement.features.modules.render;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.StreamSupport;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.api.system.font.FontRenderer;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.math.ProjectionUtil;
import project.papus.common.util.other.Instance;
import project.papus.implement.events.render.DrawEvent;

public class NameTags extends Module {
   private final MultiSelectSetting elementsSetting = new MultiSelectSetting("\u042d\u043b\u0435\u043c\u0435\u043d\u0442\u044b", "")
      .value(
         "\u041d\u0438\u043a",
         "\u0425\u041f",
         "\u0411\u0440\u043e\u043d\u044f",
         "\u041f\u0440\u0438\u043f\u0438\u0441\u043a\u0438",
         "\u041f\u0440\u0430\u0432\u0430\u044f \u0440\u0443\u043a\u0430",
         "\u041b\u0435\u0432\u0430\u044f \u0440\u0443\u043a\u0430"
      );
   private final MultiSelectSetting targetsSetting = new MultiSelectSetting("\u0426\u0435\u043b\u0438", "")
      .value(
         "\u0418\u0433\u0440\u043e\u043a\u0438",
         "\u041c\u043e\u0431\u044b",
         "\u0414\u0440\u0443\u0437\u044c\u044f",
         "\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b"
      );
   private static final double MIN_SCALE = 4.0;
   private static final float TAG_HEIGHT = 0.65F;
   private static final float PADDING_X = 1.4F;
   private static final float CORNER_RADIUS = 0.2F;
   private static final float FONT_SIZE = 10.0F;
   private static final float ITEM_SIZE = 3.0F;
   private static final float ITEM_SPACING = 12.0F;
   private static final float ITEM_OFFSET_Y = 4.0F;
   private static final float ENCHANT_FONT_SIZE = 5.0F;
   private static final float HAND_ITEM_SCALE = 1.0F;
   private final Map<Integer, Float> animatedHealthMap = new HashMap<>();

   public static NameTags getInstance() {
      return Instance.get(NameTags.class);
   }

   public NameTags() {
      super("NameTags", "Name Tags", ModuleCategory.RENDER);
      this.setup(this.elementsSetting, this.targetsSetting);
      this.elementsSetting.getSelected().add("\u041d\u0438\u043a");
      this.elementsSetting.getSelected().add("\u0425\u041f");
      this.elementsSetting.getSelected().add("\u0411\u0440\u043e\u043d\u044f");
      this.elementsSetting.getSelected().add("\u041f\u0440\u0438\u043f\u0438\u0441\u043a\u0438");
      this.elementsSetting.getSelected().add("\u041f\u0440\u0430\u0432\u0430\u044f \u0440\u0443\u043a\u0430");
      this.elementsSetting.getSelected().add("\u041b\u0435\u0432\u0430\u044f \u0440\u0443\u043a\u0430");
      this.targetsSetting.getSelected().add("\u0418\u0433\u0440\u043e\u043a\u0438");
      this.targetsSetting.getSelected().add("\u041c\u043e\u0431\u044b");
      this.targetsSetting.getSelected().add("\u0414\u0440\u0443\u0437\u044c\u044f");
      this.targetsSetting.getSelected().add("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b");
   }

   @EventHandler
   public void onDraw(DrawEvent var1) {
      if (mc.player != null && mc.world != null) {
         List<Entity> var2 = StreamSupport.<Entity>stream(mc.world.getEntities().spliterator(), false)
            .filter(var0 -> var0 != null && var0 != mc.player)
            .filter(var0 -> var0.isAlive())
            .filter(
               var1x -> {
                  if (var1x instanceof LivingEntity var2x) {
                     if (var2x instanceof PlayerEntity) {
                        boolean var3x = FriendUtils.getFriends().stream().anyMatch(var1xx -> var1xx.getName().equals(var2x.getName().getString()));
                        return var3x
                           ? this.targetsSetting.isSelected("\u0414\u0440\u0443\u0437\u044c\u044f")
                           : this.targetsSetting.isSelected("\u0418\u0433\u0440\u043e\u043a\u0438");
                     } else {
                        return this.targetsSetting.isSelected("\u041c\u043e\u0431\u044b");
                     }
                  } else {
                     return var1x instanceof ItemEntity ? this.targetsSetting.isSelected("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b") : false;
                  }
               }
            )
            .filter(
               var1x -> {
                  String var2x = var1x.getName().getString().toLowerCase();
                  return var2x.contains("armor stand") || var2x.contains("npc") || var2x.contains("holo") || var2x.contains("spawn")
                     ? false
                     : !(var1x instanceof ArmorStandEntity);
               }
            )
            .toList();
         HashSet<Integer> var3 = new HashSet<>();

         for (Entity var5 : var2) {
            var3.add(var5.getId());
         }

         this.animatedHealthMap.keySet().retainAll(var3);

         for (Entity var7 : var2) {
            if (var7 instanceof LivingEntity) {
               this.renderLivingTag(var1, (LivingEntity)var7);
            } else if (var7 instanceof ItemEntity && this.targetsSetting.isSelected("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b")) {
               this.renderItemTag(var1, (ItemEntity)var7);
            }
         }
      }
   }

   private void renderLivingTag(DrawEvent var1, LivingEntity var2) {
      Vec3d var3 = MathUtil.interpolate(var2);
      float var4 = var2.getHeight();
      float var5 = 0.4F;
      Vec3d var6 = new Vec3d(var3.x, var3.y + var4 + var5, var3.z);
      Vec3d var7 = new Vec3d(var3.x, var3.y - 0.5, var3.z);
      Vec3d var8 = ProjectionUtil.worldSpaceToScreenSpace(var6);
      Vec3d var9 = ProjectionUtil.worldSpaceToScreenSpace(var7);
      boolean var10 = var8.z > 0.0 && var8.z < 1.0;
      boolean var11 = var9.z > 0.0 && var9.z < 1.0;
      if (var10 || var11) {
         double var12 = Math.sqrt(mc.player.squaredDistanceTo(var3.x, var3.y, var3.z));
         float var14 = MathHelper.clamp((float)(4.0 / Math.max(var12, 0.1)), 0.65F, 1.4F);
         int var15 = var2.getId();
         float var16 = this.animatedHealthMap.getOrDefault(var15, var14);
         var16 += (var14 - var16) * 0.2F;
         this.animatedHealthMap.put(var15, var16);
         float var17 = Math.max(var16, 0.65F);
         MatrixStack var18 = var1.getDrawContext().getMatrices();
         boolean var19 = false;
         if (var2 instanceof PlayerEntity) {
            String var20 = var2.getName().getString();
            var19 = FriendUtils.getFriends().stream().anyMatch(var1x -> var1x.getName().equals(var20));
         }

         if (var10) {
            var18.push();
            var18.translate((float)var8.x, (float)var8.y - 10.0F, 0.0F);
            var18.scale(var17, var17, 1.0F);
            float var22 = 0.0F;
            if (this.elementsSetting.isSelected("\u0411\u0440\u043e\u043d\u044f")) {
               var22 = this.renderArmor(var1, var2, var18, var22);
            }

            this.renderNameAndHealth(var1, var2, var18, var22, var19);
            var18.pop();
         }

         if (var11
            && (
               this.elementsSetting.isSelected("\u041f\u0440\u0430\u0432\u0430\u044f \u0440\u0443\u043a\u0430")
                  || this.elementsSetting.isSelected("\u041b\u0435\u0432\u0430\u044f \u0440\u0443\u043a\u0430")
            )) {
            var18.push();
            var18.translate((float)var9.x, (float)var9.y, 0.0F);
            var18.scale(var17, var17, 1.0F);
            this.renderHands(var1, var2, var18);
            var18.pop();
         }
      }
   }

   private void renderItemTag(DrawEvent var1, ItemEntity var2) {
      Vec3d var3 = MathUtil.interpolate(var2);
      ItemStack var4 = var2.getStack();
      if (var4 != null && !var4.isEmpty()) {
         String var5 = var4.getName().getString();
         Vec3d var6 = new Vec3d(var3.x, var3.y + 1.0, var3.z);
         Vec3d var7 = ProjectionUtil.worldSpaceToScreenSpace(var6);
         if (!(var7.z <= 0.0) && !(var7.z >= 1.0)) {
            double var8 = Math.sqrt(mc.player.squaredDistanceTo(var3.x, var3.y, var3.z));
            float var10 = MathHelper.clamp((float)(4.0 / Math.max(var8, 0.1)), 0.65F, 1.4F);
            int var11 = var2.getId();
            float var12 = this.animatedHealthMap.getOrDefault(var11, var10);
            var12 += (var10 - var12) * 0.2F;
            this.animatedHealthMap.put(var11, var12);
            float var13 = Math.max(var12, 0.65F);
            MatrixStack var14 = var1.getDrawContext().getMatrices();
            var14.push();
            var14.translate((float)var7.x, (float)var7.y, 0.0F);
            var14.scale(var13, var13, 1.0F);
            FontRenderer var15 = Fonts.getSize(20, Fonts.Type.DEFAULT);
            float var16 = var15.getStringWidth(var5);
            float var17 = -var16 / 2.0F;
            float var18 = 0.0F;
            this.drawTagBackground(var14, var17, var18, var16, 12.0F);
            var15.drawString(var14, var5, var17, var18 + 2.0F, ColorUtil.getColor(255, 255, 255, 255));
            var14.pop();
         }
      }
   }

   private void drawTagBackground(MatrixStack var1, float var2, float var3, float var4, float var5) {
      blur.render(
         ShapeProperties.create(var1, var2 - 3.0F, var3 - 3.0F, var4 + 6.0F, var5 + 6.0F)
            .round(4.0F)
            .quality(5.0F)
            .softness(1.0F)
            .thickness(0.0F)
            .outlineColor(ColorUtil.getColor(120, 40, 180, 255))
            .color(ColorUtil.getColor(12, 4, 18, 240))
            .build()
      );
   }

   private float renderArmor(DrawEvent var1, LivingEntity var2, MatrixStack var3, float var4) {
      ArrayList var5 = new ArrayList();

      for (EquipmentSlot var9 : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
         ItemStack var10 = var2.getEquippedStack(var9);
         if (var10 != null && !var10.isEmpty()) {
            var5.add(var10);
         }
      }

      if (var5.isEmpty()) {
         return var4;
      } else {
         float var14 = 12.0F;
         float var15 = var14 / 16.0F;
         float var16 = 10.0F;
         float var17 = var5.size() * var14 + (var5.size() - 1) * var16;
         float var18 = -var17 / 2.0F;
         float var11 = -20.0F;

         for (int var12 = 0; var12 < var5.size(); var12++) {
            float var13 = var18 + var12 * (var14 + var16);
            this.drawTagBackground(var3, var13, var11, var14, var14);
            var3.push();
            var3.translate(var13, var11, 0.0F);
            var3.scale(var15, var15, 1.0F);
            var1.getDrawContext().drawItem((ItemStack)var5.get(var12), 0, 0);
            var3.pop();
         }

         return var4;
      }
   }

   private void renderNameAndHealth(DrawEvent var1, LivingEntity var2, MatrixStack var3, float var4, boolean var5) {
      boolean var6 = this.elementsSetting.isSelected("\u041d\u0438\u043a");
      boolean var7 = this.elementsSetting.isSelected("\u0425\u041f");
      if (var6 || var7) {
         String var8 = var7 ? " \u00a7c" + (int)Math.ceil(var2.getHealth()) + "HP" : "";
         FontRenderer var9 = Fonts.getSize(20, Fonts.Type.DEFAULT);
         Text var10 = this.getFormattedName(var2, true);
         String var11 = var10.getString();
         float var12 = var9.getStringWidth(var11);
         float var13 = var8.isEmpty() ? 0.0F : var9.getStringWidth(var8);
         float var14 = var12 + var13;
         float var15 = -var14 / 2.0F;
         this.drawTagBackground(var3, var15, var4, var14, 12.0F);
         int var17 = var5 ? ColorUtil.getColor(85, 255, 85, 255) : ColorUtil.getColor(255, 255, 255, 255);
         var9.drawString(var3, var11, var15, var4 + 2.0F, var17);
         if (!var8.isEmpty()) {
            float var18 = var15 + var12;
            var9.drawString(var3, var8, var18, var4 + 2.0F, ColorUtil.getColor(255, 80, 80, 255));
         }
      }
   }

   private Text getFormattedName(LivingEntity var1, boolean var2) {
      String var3 = var2 ? var1.getName().getString() : "";
      if (!this.elementsSetting.isSelected("\u041f\u0440\u0438\u043f\u0438\u0441\u043a\u0438")) {
         return Text.literal(var3);
      } else {
         Team var4 = var1.getScoreboardTeam();
         if (var4 == null) {
            return Text.literal(var3);
         } else {
            Text var5 = var4.getPrefix();
            Text var6 = var4.getSuffix();
            return Text.empty().append(var5).append(var3).append(var6);
         }
      }
   }

   private void renderHands(DrawEvent var1, LivingEntity var2, MatrixStack var3) {
      ArrayList var4 = new ArrayList();
      ItemStack var5 = var2.getMainHandStack();
      ItemStack var6 = var2.getOffHandStack();
      if (this.elementsSetting.isSelected("\u041f\u0440\u0430\u0432\u0430\u044f \u0440\u0443\u043a\u0430") && var5 != null && !var5.isEmpty()) {
         var4.add(var5);
      }

      if (this.elementsSetting.isSelected("\u041b\u0435\u0432\u0430\u044f \u0440\u0443\u043a\u0430") && var6 != null && !var6.isEmpty()) {
         var4.add(var6);
      }

      if (!var4.isEmpty()) {
         float var7 = 12.0F;
         float var8 = var7 / 16.0F;
         float var9 = 10.0F;
         float var10 = var4.size() * var7 + (var4.size() - 1) * var9;
         float var11 = -var10 / 2.0F;

         for (int var12 = 0; var12 < var4.size(); var12++) {
            float var13 = var11 + var12 * (var7 + var9);
            this.drawTagBackground(var3, var13, 0.0F, var7, var7);
            var3.push();
            var3.translate(var13, 0.0F, 0.0F);
            var3.scale(var8, var8, 1.0F);
            var1.getDrawContext().drawItem((ItemStack)var4.get(var12), 0, 0);
            var3.pop();
         }
      }
   }
}
