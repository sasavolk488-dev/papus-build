package project.papus.implement.events.item;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import project.papus.api.event.events.Event;

public class HandOffsetEvent implements Event {
   private MatrixStack matrices;
   private ItemStack stack;
   private Hand hand;

   public HandOffsetEvent(MatrixStack var1, ItemStack var2, Hand var3) {
      this.matrices = var1;
      this.stack = var2;
      this.hand = var3;
   }

   public MatrixStack getMatrices() {
      return this.matrices;
   }

   public ItemStack getStack() {
      return this.stack;
   }

   public Hand getHand() {
      return this.hand;
   }

   public void setMatrices(MatrixStack var1) {
      this.matrices = var1;
   }

   public void setStack(ItemStack var1) {
      this.stack = var1;
   }

   public void setHand(Hand var1) {
      this.hand = var1;
   }
}
