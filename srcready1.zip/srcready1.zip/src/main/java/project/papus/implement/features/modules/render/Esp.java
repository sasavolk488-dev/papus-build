package project.papus.implement.features.modules.render;

import java.util.stream.StreamSupport;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.api.repository.friend.FriendUtils;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.other.Instance;
import project.papus.common.util.render.Render3DUtil;
import project.papus.implement.events.render.WorldRenderEvent;

public class Esp extends Module {
   private final MultiSelectSetting targetsSetting = new MultiSelectSetting("\u0426\u0435\u043b\u0438", "")
      .value(
         "\u0418\u0433\u0440\u043e\u043a\u0438",
         "\u041c\u043e\u0431\u044b",
         "\u0414\u0440\u0443\u0437\u044c\u044f",
         "\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b"
      );
   private final MultiSelectSetting modeSetting = new MultiSelectSetting("\u0420\u0435\u0436\u0438\u043c", "")
      .value("\u0417\u0430\u043b\u0438\u0432\u043a\u0430", "\u041e\u0431\u0432\u043e\u0434\u043a\u0430");

   public static Esp getInstance() {
      return Instance.get(Esp.class);
   }

   public Esp() {
      super("Esp", "Esp", ModuleCategory.RENDER);
      this.setup(this.targetsSetting, this.modeSetting);
      this.targetsSetting.getSelected().add("\u0418\u0433\u0440\u043e\u043a\u0438");
      this.targetsSetting.getSelected().add("\u041c\u043e\u0431\u044b");
      this.targetsSetting.getSelected().add("\u0414\u0440\u0443\u0437\u044c\u044f");
      this.targetsSetting.getSelected().add("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b");
      this.modeSetting.getSelected().add("\u041e\u0431\u0432\u043e\u0434\u043a\u0430");
   }

   @EventHandler
   public void onWorldRender(WorldRenderEvent var1) {
      if (mc.player != null && mc.world != null) {
         boolean var2 = mc.options.getPerspective().isFirstPerson();
         float var3 = var1.getTickDelta();
         Entry var4 = var1.getStack().peek();
         boolean var5 = false;
         boolean var6 = this.modeSetting.isSelected("\u0417\u0430\u043b\u0438\u0432\u043a\u0430");
         boolean var7 = this.modeSetting.isSelected("\u041e\u0431\u0432\u043e\u0434\u043a\u0430");

         for (Entity var10 : StreamSupport.<Entity>stream(mc.world.getEntities().spliterator(), false)
            .filter(var0 -> var0 != null)
            .filter(var1x -> !var2 || var1x != mc.player)
            .filter(var0 -> !(var0 instanceof ArmorStandEntity))
            .filter(
               var1x -> {
                  if (var1x instanceof LivingEntity var2x) {
                     if (var2x instanceof PlayerEntity) {
                        String var3x = var2x.getName().getString();
                        boolean var4x = FriendUtils.getFriends().stream().anyMatch(var1xx -> var1xx.getName().equals(var3x));
                        return var4x
                           ? this.targetsSetting.isSelected("\u0414\u0440\u0443\u0437\u044c\u044f")
                           : this.targetsSetting.isSelected("\u0418\u0433\u0440\u043e\u043a\u0438");
                     } else {
                        return this.targetsSetting.isSelected("\u041c\u043e\u0431\u044b");
                     }
                  } else {
                     return var1x instanceof ItemEntity ? this.targetsSetting.isSelected("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b") : false;
                  }
               }
            )
            .toList()) {
            if (var10 instanceof LivingEntity var11) {
               Box var12 = getInterpolatedBox(var11, var3);
               int var13 = this.getArmorColor(var11);
               if (var6) {
                  this.drawCornerBox(var4, var12, var13, var5);
               }

               if (var7) {
                  this.drawCornerLines(var4, var12, var13, var5);
               }
            } else if (var10 instanceof ItemEntity && this.targetsSetting.isSelected("\u041f\u0440\u0435\u0434\u043c\u0435\u0442\u044b")) {
               ItemEntity var14 = (ItemEntity)var10;
               Box var15 = getItemInterpolatedBox(var14, var3);
               int var16 = ColorUtil.getColor(255, 255, 255, 255);
               if (var6) {
                  this.drawCornerBox(var4, var15, var16, var5);
               }

               if (var7) {
                  this.drawCornerLines(var4, var15, var16, var5);
               }
            }
         }
      }
   }

   private void drawCornerBox(Entry var1, Box var2, int var3, boolean var4) {
      double var5 = var2.minX;
      double var7 = var2.minY;
      double var9 = var2.minZ;
      double var11 = var2.maxX;
      double var13 = var2.maxY;
      double var15 = var2.maxZ;
      int var17 = ColorUtil.setAlpha(var3, 0.15F);
      Render3DUtil.drawQuad(
         var1, new Vec3d(var5, var7, var9), new Vec3d(var11, var7, var9), new Vec3d(var11, var7, var15), new Vec3d(var5, var7, var15), var17, var4
      );
      Render3DUtil.drawQuad(
         var1, new Vec3d(var5, var13, var9), new Vec3d(var11, var13, var9), new Vec3d(var11, var13, var15), new Vec3d(var5, var13, var15), var17, var4
      );
      Render3DUtil.drawQuad(
         var1, new Vec3d(var5, var7, var9), new Vec3d(var11, var7, var9), new Vec3d(var11, var13, var9), new Vec3d(var5, var13, var9), var17, var4
      );
      Render3DUtil.drawQuad(
         var1, new Vec3d(var5, var7, var15), new Vec3d(var11, var7, var15), new Vec3d(var11, var13, var15), new Vec3d(var5, var13, var15), var17, var4
      );
      Render3DUtil.drawQuad(
         var1, new Vec3d(var5, var7, var9), new Vec3d(var5, var7, var15), new Vec3d(var5, var13, var15), new Vec3d(var5, var13, var9), var17, var4
      );
      Render3DUtil.drawQuad(
         var1, new Vec3d(var11, var7, var9), new Vec3d(var11, var7, var15), new Vec3d(var11, var13, var15), new Vec3d(var11, var13, var9), var17, var4
      );
   }

   private void drawCornerLines(Entry var1, Box var2, int var3, boolean var4) {
      int var5 = ColorUtil.setAlpha(var3, 1.8F);
      Render3DUtil.drawBox(var1, var2, var5, 0, 1.5F, true, false, var4);
   }

   private int getArmorColor(LivingEntity var1) {
      if (var1 instanceof PlayerEntity) {
         String var2 = var1.getName().getString();
         boolean var3 = FriendUtils.getFriends().stream().anyMatch(var1x -> var1x.getName().equals(var2));
         if (var3) {
            return !this.targetsSetting.isSelected("\u0414\u0440\u0443\u0437\u044c\u044f")
               ? ColorUtil.getColor(255, 255, 255, 255)
               : ColorUtil.getColor(50, 255, 50, 255);
         } else {
            return ColorUtil.getColor(255, 255, 255, 255);
         }
      } else {
         return ColorUtil.getColor(255, 255, 255, 255);
      }
   }

   private static Box getInterpolatedBox(Entity var0, float var1) {
      Box var2 = var0.getBoundingBox();
      double var3 = MathHelper.lerp(var1, var0.prevX, var0.getX());
      double var5 = MathHelper.lerp(var1, var0.prevY, var0.getY());
      double var7 = MathHelper.lerp(var1, var0.prevZ, var0.getZ());
      double var9 = var2.maxX - var2.minX;
      double var11 = var2.maxY - var2.minY;
      double var13 = var2.maxZ - var2.minZ;
      return new Box(var3 - var9 * 0.5, var5 + 0.01, var7 - var13 * 0.5, var3 + var9 * 0.5, var5 + var11, var7 + var13 * 0.5);
   }

   private static Box getItemInterpolatedBox(ItemEntity var0, float var1) {
      Box var2 = var0.getBoundingBox();
      double var3 = MathHelper.lerp(var1, var0.prevX, var0.getX());
      double var5 = MathHelper.lerp(var1, var0.prevY, var0.getY());
      double var7 = MathHelper.lerp(var1, var0.prevZ, var0.getZ());
      double var9 = var2.maxX - var2.minX;
      double var11 = var2.maxY - var2.minY;
      double var13 = var2.maxZ - var2.minZ;
      return new Box(var3 - var9 * 0.7, var5, var7 - var13 * 0.7, var3 + var9 * 0.7, var5 + var11 + 0.3, var7 + var13 * 0.7);
   }
}
