package project.papus.implement.events.render;

import project.papus.api.event.events.callables.EventCancellable;

public class AspectRatioEvent extends EventCancellable {
   private float ratio;

   public float getRatio() {
      return this.ratio;
   }

   public void setRatio(float var1) {
      this.ratio = var1;
   }
}
