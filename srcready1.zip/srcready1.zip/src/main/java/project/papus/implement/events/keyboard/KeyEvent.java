package project.papus.implement.events.keyboard;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil.Type;
import project.papus.api.event.events.Event;
import project.papus.common.QuickImports;

public record KeyEvent(Screen screen, Type type, int key, int action) implements QuickImports, Event {
   public boolean isKeyDown(int var1) {
      return this.isKeyDown(var1, mc.currentScreen == null);
   }

   public boolean isKeyDown(int var1, boolean var2) {
      return this.key == var1 && this.action == 1 && var2;
   }

   public boolean isKeyReleased(int var1) {
      return this.isKeyReleased(var1, mc.currentScreen == null);
   }

   public boolean isKeyReleased(int var1, boolean var2) {
      return this.key == var1 && this.action == 0 && var2;
   }
}
