package project.papus.implement.features.modules.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4i;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.render.Render3DUtil;
import project.papus.implement.events.player.KeepSprintEvent;
import project.papus.implement.events.render.WorldRenderEvent;

public class JumpCircle extends Module {
   private static final float MAX_SCALE = 2.0F;
   private static final float INITIAL_SCALE = 1.5F;
   private final List<JumpCircle.Circle> circles = new ArrayList<>();

   public JumpCircle() {
      super("JumpCircle", "Jump Circle", ModuleCategory.RENDER);
   }

   private Identifier getTexture() {
      return Identifier.of("papus", "textures/jumpcircles/glow.png");
   }

   private void addCircle(Vec3d var1) {
      BlockPos var2 = BlockPos.ofFloored(var1);
      BlockState var3 = mc.world != null ? mc.world.getBlockState(var2) : null;
      if (var3 != null && var3.getBlock() == Blocks.SNOW) {
         var1 = var1.add(0.0, 0.125, 0.0);
      }

      this.circles.add(new JumpCircle.Circle(var1));
   }

   @EventHandler
   public void onKeepSprint(KeepSprintEvent var1) {
      if (mc.player != null && mc.world != null && var1.getPlayer() == mc.player) {
         this.addCircle(var1.getPlayer().getPos().add(0.0, 0.005, 0.0));
      }
   }

   @EventHandler
   public void onWorldRender(WorldRenderEvent var1) {
      if (mc.player != null && mc.world != null) {
         this.circles.removeIf(var0 -> var0.getAgeSeconds() >= 2.0);
         if (!this.circles.isEmpty()) {
            MatrixStack var2 = var1.getStack();
            Identifier var3 = this.getTexture();

            for (JumpCircle.Circle var5 : this.circles) {
               float var6 = (float)var5.getAgeSeconds();
               float var7 = Math.min(var6 / 2.0F, 1.0F);
               float var8 = 1.0F - var7;
               float var9 = bounce(var8);
               float var10 = clamp01(var9);
               float var11 = Math.max(0.0F, 0.5F);
               if (var6 >= var11) {
                  float var12 = (var6 - var11) / (2.0F - var11);
                  var10 *= 1.0F - Math.min(var12, 1.0F);
               }

               float var17 = (float)(easeOutCirc(clamp01(var8)) * 1.4F);
               byte var13 = -1;
               int var14 = ColorUtil.setAlpha(var13, var10);
               Vector4i var15 = new Vector4i(var14, var14, var14, var14);
               Vec3d var16 = var5.pos;
               var2.push();
               var2.translate(var16.x - var17 / 2.0F, var16.y, var16.z - var17 / 2.0F);
               var2.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0F));
               Render3DUtil.drawTexture(var2.peek().copy(), var3, 0.0F, 0.0F, var17, var17, var15, true);
               var2.pop();
            }
         }
      }
   }

   public void clear() {
      this.circles.clear();
   }

   public void reset() {
      this.circles.clear();
   }

   private static float bounce(float var0) {
      return (var0 > 0.5F ? 1.0F - var0 : var0) * 2.0F;
   }

   private static float clamp01(float var0) {
      return Math.min(var0, 1.0F);
   }

   private static double easeOutCirc(double var0) {
      return Math.sqrt(1.0 - Math.pow(var0 - 1.0, 2.0));
   }

   static final class Circle {
      final long startTime = System.currentTimeMillis();
      final Vec3d pos;

      Circle(Vec3d var1) {
         this.pos = var1;
      }

      double getAgeSeconds() {
         return (System.currentTimeMillis() - this.startTime) / 1000.0;
      }
   }
}
