package project.papus.implement.features.modules.render;

import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.common.util.other.Instance;

public class FullBright extends Module {
   public static FullBright getInstance() {
      return Instance.get(FullBright.class);
   }

   public FullBright() {
      super("FullBright", "Full Bright", ModuleCategory.RENDER);
   }
}
