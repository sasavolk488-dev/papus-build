package project.papus.implement.screens.menu.components.implement.other;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.color.ColorUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class BackgroundComponent extends AbstractComponent {
   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      MatrixStack var5 = var1.getMatrices();
      float var6 = 0.0F;
      float var7 = this.x + 43.0F;
      float var8 = this.y + var6;
      float var9 = this.width - 42.0F;
      float var10 = this.height - var6 * 2.0F;
      rectangle.render(
         ShapeProperties.create(var5, var7 - 8.0F, var8 - 5.0F, var9 + 9.5F, var10 + 5.0F)
            .round(8.0F)
            .softness(1.0F)
            .quality(15.0F)
            .color(ColorUtil.getColor(12, 4, 18, 250))
            .build()
      );
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      return super.mouseClicked(var1, var3, var5);
   }

   public String getSearchText() {
      return "";
   }

   public boolean isTyping() {
      return false;
   }
}
