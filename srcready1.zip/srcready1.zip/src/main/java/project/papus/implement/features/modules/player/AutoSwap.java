package project.papus.implement.features.modules.player;

import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleCategory;
import project.papus.api.feature.module.setting.implement.BindSetting;
import project.papus.api.feature.module.setting.implement.BooleanSetting;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.common.util.entity.PlayerInventoryUtil;
import project.papus.common.util.other.StopWatch;
import project.papus.common.util.task.scripts.Script;
import project.papus.implement.events.keyboard.KeyEvent;
import project.papus.implement.events.player.KeyboardInputEvent;
import project.papus.implement.events.player.TickEvent;

public class AutoSwap extends Module {
   private final BindSetting keySetting = new BindSetting("Key", "");
   private final SelectSetting modeSetting = new SelectSetting("\u0420\u0435\u0436\u0438\u043c", "")
      .value("FunTime", "\u0414\u0440\u0443\u0433\u0438\u0435 \u0441\u0435\u0440\u0432\u0435\u0440\u0430")
      .selected("FunTime");
   private final SelectSetting swapTypeSetting = new SelectSetting("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438", "")
      .value(
         "\u0428\u0430\u0440 \u0438 \u0422\u043e\u0442\u0435\u043c",
         "\u0428\u0430\u0440 \u0438 \u0428\u0430\u0440",
         "\u0422\u043e\u0442\u0435\u043c \u0438 \u0422\u043e\u0442\u0435\u043c"
      )
      .selected("\u0428\u0430\u0440 \u0438 \u0422\u043e\u0442\u0435\u043c");
   private final BooleanSetting onlyEnchantedTotemsSetting = new BooleanSetting(
         "\u0422\u043e\u043b\u044c\u043a\u043e \u0437\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0435 \u0442\u043e\u0442\u0435\u043c\u044b",
         ""
      )
      .setValue(false);
   private final Script script = new Script();
   private final StopWatch stopWatch = new StopWatch();
   private final StopWatch cooldownWatch = new StopWatch();
   private final Random random = new Random();
   private boolean slownessActive = false;

   public AutoSwap() {
      super("AutoSwap", "Auto Swap", ModuleCategory.PLAYER);
      this.setup(this.keySetting, this.modeSetting, this.swapTypeSetting, this.onlyEnchantedTotemsSetting);
      this.cooldownWatch.reset();
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      this.script.update();
      if (this.slownessActive && mc.player != null) {
         mc.player.setSprinting(false);
      }
   }

   @EventHandler
   public void onKeyboardInput(KeyboardInputEvent var1) {
      if (this.slownessActive) {
         var1.resetDirectional();
      }
   }

   @EventHandler
   public void onKey(KeyEvent var1) {
      if (var1.action() == 1 && mc.player != null) {
         if (mc.currentScreen == null) {
            if (var1.key() == this.keySetting.getKey()) {
               if (this.script.isFinished()) {
                  if (this.cooldownWatch.every(1000.0)) {
                     if (this.stopWatch.every(100.0)) {
                        if (!this.modeSetting.getSelected().equals("\u0414\u0440\u0443\u0433\u0438\u0435 \u0441\u0435\u0440\u0432\u0435\u0440\u0430")
                           || mc.player.isOnGround()) {
                           ItemStack var2 = mc.player.inventory.getStack(40);
                           String var3 = var2.isEmpty() ? "" : var2.getItem().toString().toLowerCase();
                           String var4 = this.getSecondItemType(var3);
                           if (var4 != null) {
                              int var5 = this.findSlotByType(var4);
                              if (var5 != -1) {
                                 this.script.cleanup();
                                 this.slownessActive = true;
                                 int var8 = 42 + this.random.nextInt(42);
                                 int var9 = 5 + this.random.nextInt(5);
                                 int var10 = 5 + this.random.nextInt(5);
                                 this.script
                                    .addTickStep(var8, () -> PlayerInventoryUtil.clickSlot(var5, 40, SlotActionType.SWAP, false))
                                    .addTickStep(var9, () -> {
                                       ItemStack var2x = mc.player.inventory.getStack(40);
                                       boolean var3x = !var2x.isEmpty() && var2x.getItem().toString().toLowerCase().contains(var4);
                                       if (!var3x) {
                                          PlayerInventoryUtil.clickSlot(var5, 40, SlotActionType.SWAP, false);
                                       }
                                    })
                                    .addTickStep(var10, () -> {
                                       this.slownessActive = false;
                                       this.stopWatch.reset();
                                       this.cooldownWatch.reset();
                                    });
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private String getSecondItemType(String var1) {
      String var2 = this.swapTypeSetting.getSelected();

      return switch (var2) {
         case "\u0428\u0430\u0440 \u0438 \u0422\u043e\u0442\u0435\u043c" -> var1.contains("player_head") ? "totem" : "player_head";
         case "\u0428\u0430\u0440 \u0438 \u0428\u0430\u0440" -> "player_head";
         case "\u0422\u043e\u0442\u0435\u043c \u0438 \u0422\u043e\u0442\u0435\u043c" -> "totem";
         default -> null;
      };
   }

   private int findSlotByType(String var1) {
      boolean var2 = var1.equals("totem");
      boolean var3 = var2 && this.onlyEnchantedTotemsSetting.isValue();
      if (var3) {
         for (int var7 = 0; var7 < 9; var7++) {
            ItemStack var10 = mc.player.inventory.getStack(var7);
            if (!var10.isEmpty() && var10.getItem().toString().toLowerCase().contains(var1) && var10.hasEnchantments()) {
               return var7;
            }
         }

         for (int var8 = 9; var8 < 36; var8++) {
            ItemStack var11 = mc.player.inventory.getStack(var8);
            if (!var11.isEmpty() && var11.getItem().toString().toLowerCase().contains(var1) && var11.hasEnchantments()) {
               return var8;
            }
         }

         return -1;
      } else {
         for (int var4 = 0; var4 < 9; var4++) {
            ItemStack var5 = mc.player.inventory.getStack(var4);
            if (!var5.isEmpty() && var5.getItem().toString().toLowerCase().contains(var1)) {
               return var4;
            }
         }

         for (int var6 = 9; var6 < 36; var6++) {
            ItemStack var9 = mc.player.inventory.getStack(var6);
            if (!var9.isEmpty() && var9.getItem().toString().toLowerCase().contains(var1)) {
               return var6;
            }
         }

         return -1;
      }
   }
}
