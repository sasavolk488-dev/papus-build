package project.papus.implement.screens.menu.components.implement.other;

import net.minecraft.client.gui.DrawContext;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.util.math.MathUtil;
import project.papus.implement.screens.menu.components.AbstractComponent;

public class SettingComponent extends AbstractComponent {
   private Runnable action;

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      image.setTexture("textures/settings.png").render(ShapeProperties.create(var1.getMatrices(), this.x, this.y, 7.0, 7.0).color(-5263172).build());
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (MathUtil.isHovered(var1, var3, this.x, this.y, 7.0, 7.0) && var5 == 0) {
         this.action.run();
      }

      return super.mouseClicked(var1, var3, var5);
   }

   public SettingComponent setAction(Runnable var1) {
      this.action = var1;
      return this;
   }
}
