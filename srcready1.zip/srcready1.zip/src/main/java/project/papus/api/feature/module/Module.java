package project.papus.api.feature.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Formatting;
import project.papus.api.event.EventManager;
import project.papus.api.feature.draggable.AbstractDraggable;
import project.papus.api.feature.module.setting.SettingRepository;
import project.papus.api.system.animation.Animation;
import project.papus.api.system.animation.Direction;
import project.papus.api.system.animation.implement.DecelerateAnimation;
import project.papus.api.system.sound.SoundManager;
import project.papus.common.QuickImports;
import project.papus.core.Main;

public class Module extends SettingRepository implements QuickImports {
   private final String name;
   private final String visibleName;
   private final ModuleCategory category;
   private final Animation animation = new DecelerateAnimation().setMs(150).setValue(1.0);
   private int key = -1;
   private int type = 1;
   public boolean state;
   private boolean silent = false;

   public Module(String var1, ModuleCategory var2) {
      this.name = var1;
      this.category = var2;
      this.visibleName = var1;
   }

   public Module(String var1, String var2, ModuleCategory var3) {
      this.name = var1;
      this.visibleName = var2;
      this.category = var3;
   }

   public void setState(boolean var1) {
      this.silent = !var1;
   }

   public boolean isVisible() {
      return !this.silent;
   }

   public void switchState() {
      this.type = 1;
      this.setStateQuietly(!this.state);
   }

   public void setStateQuietly(boolean var1) {
      this.animation.setDirection(var1 ? Direction.FORWARDS : Direction.BACKWARDS);
      if (var1 != this.state) {
         this.state = var1;
         this.handleStateChange();
      }
   }

   public boolean isSilent() {
      return this.silent;
   }

   public void setSilent(boolean var1) {
      this.silent = var1;
   }

   private void handleStateChange() {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.player != null && var1.world != null) {
         if (this.state) {
            AbstractDraggable.NotificationsDraggable.getInstance()
               .addNotification(
                  "\u041c\u043e\u0434\u0443\u043b\u044c "
                     + Formatting.GREEN
                     + this.visibleName
                     + Formatting.RESET
                     + " - \u0432\u043a\u043b\u044e\u0447\u0435\u043d!",
                  2000L,
                  SoundManager.ENABLE_MODULE
               );
            this.activate();
         } else {
            AbstractDraggable.NotificationsDraggable.getInstance()
               .addNotification(
                  "\u041c\u043e\u0434\u0443\u043b\u044c "
                     + Formatting.RED
                     + this.visibleName
                     + Formatting.RESET
                     + " - \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d!",
                  2000L,
                  SoundManager.DISABLE_MODULE
               );
            this.deactivate();
         }
      }

      this.sendNotification(this.state);
   }

   private void sendNotification(boolean var1) {
      EventManager var2 = Main.getInstance().getEventManager();
      if (var1) {
         var2.register(this);
      } else {
         var2.unregister(this);
      }
   }

   public void activate() {
   }

   public void deactivate() {
   }

   public String getName() {
      return this.name;
   }

   public String getVisibleName() {
      return this.visibleName;
   }

   public ModuleCategory getCategory() {
      return this.category;
   }

   public Animation getAnimation() {
      return this.animation;
   }

   public int getKey() {
      return this.key;
   }

   public int getType() {
      return this.type;
   }

   public boolean isState() {
      return this.state;
   }

   public void setKey(int var1) {
      this.key = var1;
   }

   public void setType(int var1) {
      this.type = var1;
   }
}
