package project.papus.api.feature.draggable;

import java.util.ArrayList;
import java.util.List;

public class DraggableRepository {
   private final List<AbstractDraggable> draggables = new ArrayList<>();

   public void setup() {
      this.register(
         new AbstractDraggable.TargetHudDraggable(),
         new AbstractDraggable.NotificationsDraggable(),
         new AbstractDraggable.HotKeysDraggable(),
         new AbstractDraggable.PotionsDraggable(),
         new AbstractDraggable.WatermarkDraggable()
      );
   }

   public void register(AbstractDraggable... var1) {
      this.draggables.addAll(List.of(var1));
   }

   public List<AbstractDraggable> draggable() {
      return this.draggables;
   }

   public <T extends AbstractDraggable> T get(String var1) {
      return this.draggables.stream().filter(var1x -> var1x.getName().equalsIgnoreCase(var1)).map(var0 -> (T)var0).findFirst().orElse(null);
   }

   public <T extends AbstractDraggable> T get(Class<T> var1) {
      return this.draggables.stream().filter(var1x -> var1.isAssignableFrom(var1x.getClass())).map(var1::cast).findFirst().orElse(null);
   }
}
