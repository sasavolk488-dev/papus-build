package project.papus.api.system.shape;

public interface Shape {
   void render(ShapeProperties var1);
}
