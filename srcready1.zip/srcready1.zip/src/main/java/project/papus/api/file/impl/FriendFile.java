package project.papus.api.file.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import project.papus.api.file.ClientFile;
import project.papus.api.file.exception.FileLoadException;
import project.papus.api.file.exception.FileSaveException;
import project.papus.api.repository.friend.Friend;
import project.papus.api.repository.friend.FriendUtils;

public class FriendFile extends ClientFile {
   public FriendFile() {
      super("friends");
   }

   @Override
   public void saveToFile(File var1) {
      Gson var2 = new GsonBuilder().setPrettyPrinting().create();
      File var3 = new File(var1, this.getName() + ".json");

      try {
         try (FileWriter var4 = new FileWriter(var3)) {
            var2.toJson(FriendUtils.getFriends(), var4);
         }
      } catch (JsonIOException | IOException var9) {
         throw new FileSaveException(String.format("Failed to save %s to file", this.getName()), var9);
      }
   }

   @Override
   public void loadFromFile(File var1) {
      Gson var2 = new Gson();
      File var3 = new File(var1, this.getName() + ".json");

      try {
         try (FileReader var4 = new FileReader(var3)) {
            Friend[] var5 = (Friend[])var2.fromJson(var4, Friend[].class);
            FriendUtils.clear();
            FriendUtils.getFriends().addAll(Arrays.asList(var5));
         }
      } catch (IOException var9) {
         throw new FileLoadException(String.format("Failed to load %s from file", this.getName()), var9);
      } catch (JsonSyntaxException var10) {
         throw new FileLoadException(String.format("JSON syntax error, %s config cannot be loaded", this.getName()), var10);
      } catch (JsonIOException var11) {
         throw new FileLoadException(String.format("JSON IO error, %s config cannot be loaded", this.getName()), var11);
      }
   }
}
