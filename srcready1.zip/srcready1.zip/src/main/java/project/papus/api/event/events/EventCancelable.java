package project.papus.api.event.events;

public abstract class EventCancelable implements Event {
   private boolean cancelled;

   protected EventCancelable() {
   }

   public void uncancel() {
      this.cancelled = true;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }
}
