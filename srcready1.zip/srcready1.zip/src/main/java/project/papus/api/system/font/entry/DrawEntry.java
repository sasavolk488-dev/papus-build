package project.papus.api.system.font.entry;

import project.papus.api.system.font.glyph.Glyph;

public record DrawEntry(float atX, float atY, int color, Glyph toDraw) {
}
