package project.papus.api.system.shape;

import net.minecraft.client.util.math.MatrixStack;
import org.joml.Vector4f;
import org.joml.Vector4i;

public class ShapeProperties {
   private MatrixStack matrix;
   private float x;
   private float y;
   private float width;
   private float height;
   private float softness;
   private float thickness;
   private float start;
   private float end;
   private float quality;
   private Vector4f round;
   private int outlineColor;
   private Vector4i color;

   ShapeProperties(
      MatrixStack var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      float var10,
      Vector4f var11,
      int var12,
      Vector4i var13
   ) {
      this.matrix = var1;
      this.x = var2;
      this.y = var3;
      this.width = var4;
      this.height = var5;
      this.softness = var6;
      this.thickness = var7;
      this.round = var11 != null ? var11 : new Vector4f(0.0F);
      this.outlineColor = var12;
      this.color = var13 != null ? var13 : new Vector4i(-1);
      this.start = var8;
      this.end = var9;
      this.quality = var10;
   }

   public static ShapeProperties.ShapePropertiesBuilder create(MatrixStack var0, double var1, double var3, double var5, double var7) {
      return builder().matrix(var0).x((float)var1).y((float)var3).width((float)var5).height((float)var7);
   }

   public static ShapeProperties.ShapePropertiesBuilder builder() {
      return new ShapeProperties.ShapePropertiesBuilder();
   }

   public ShapeProperties.ShapePropertiesBuilder toBuilder() {
      return new ShapeProperties.ShapePropertiesBuilder()
         .matrix(this.matrix)
         .x(this.x)
         .y(this.y)
         .width(this.width)
         .height(this.height)
         .softness(this.softness)
         .thickness(this.thickness)
         .start(this.start)
         .end(this.end)
         .quality(this.quality)
         .round(this.round)
         .outlineColor(this.outlineColor)
         .color(this.color);
   }

   public MatrixStack getMatrix() {
      return this.matrix;
   }

   public float getX() {
      return this.x;
   }

   public float getY() {
      return this.y;
   }

   public float getWidth() {
      return this.width;
   }

   public float getHeight() {
      return this.height;
   }

   public float getSoftness() {
      return this.softness;
   }

   public float getThickness() {
      return this.thickness;
   }

   public float getStart() {
      return this.start;
   }

   public float getEnd() {
      return this.end;
   }

   public float getQuality() {
      return this.quality;
   }

   public Vector4f getRound() {
      return this.round;
   }

   public int getOutlineColor() {
      return this.outlineColor;
   }

   public Vector4i getColor() {
      return this.color;
   }

   public void setMatrix(MatrixStack var1) {
      this.matrix = var1;
   }

   public void setX(float var1) {
      this.x = var1;
   }

   public void setY(float var1) {
      this.y = var1;
   }

   public void setWidth(float var1) {
      this.width = var1;
   }

   public void setHeight(float var1) {
      this.height = var1;
   }

   public void setSoftness(float var1) {
      this.softness = var1;
   }

   public void setThickness(float var1) {
      this.thickness = var1;
   }

   public void setStart(float var1) {
      this.start = var1;
   }

   public void setEnd(float var1) {
      this.end = var1;
   }

   public void setQuality(float var1) {
      this.quality = var1;
   }

   public void setRound(Vector4f var1) {
      this.round = var1;
   }

   public void setOutlineColor(int var1) {
      this.outlineColor = var1;
   }

   public void setColor(Vector4i var1) {
      this.color = var1;
   }

   public static class ShapePropertiesBuilder {
      private MatrixStack matrix;
      private float x;
      private float y;
      private float width;
      private float height;
      private float softness;
      private float thickness;
      private float start;
      private float end;
      private boolean quality$set;
      private float quality$value;
      private Vector4f round;
      private boolean outlineColor$set;
      private int outlineColor$value;
      private Vector4i color;
      private float quality;
      private int outlineColor;

      public ShapeProperties.ShapePropertiesBuilder color(int var1) {
         this.color = new Vector4i(var1);
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder color(Vector4i var1) {
         this.color = var1;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder color(int... var1) {
         this.color = new Vector4i(var1);
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder round(float var1) {
         this.round = new Vector4f(var1);
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder round(Vector4f var1) {
         this.round = new Vector4f(var1);
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder round(float... var1) {
         this.round = new Vector4f(var1);
         return this;
      }

      ShapePropertiesBuilder() {
      }

      public ShapeProperties.ShapePropertiesBuilder matrix(MatrixStack var1) {
         this.matrix = var1;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder x(float var1) {
         this.x = var1;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder y(float var1) {
         this.y = var1;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder width(float var1) {
         this.width = var1;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder height(float var1) {
         this.height = var1;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder softness(float var1) {
         this.softness = var1;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder thickness(float var1) {
         this.thickness = var1;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder start(float var1) {
         this.start = var1;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder end(float var1) {
         this.end = var1;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder quality(float var1) {
         this.quality$value = var1;
         this.quality$set = true;
         return this;
      }

      public ShapeProperties.ShapePropertiesBuilder outlineColor(int var1) {
         this.outlineColor$value = var1;
         this.outlineColor$set = true;
         return this;
      }

      public ShapeProperties build() {
         float var1 = this.quality$value;
         if (!this.quality$set) {
            var1 = 20.0F;
         }

         int var2 = this.outlineColor$value;
         if (!this.outlineColor$set) {
            var2 = -1;
         }

         return new ShapeProperties(
            this.matrix, this.x, this.y, this.width, this.height, this.softness, this.thickness, this.start, this.end, var1, this.round, var2, this.color
         );
      }

      @Override
      public String toString() {
         return "ShapeProperties.ShapePropertiesBuilder(matrix="
            + this.matrix
            + ", x="
            + this.x
            + ", y="
            + this.y
            + ", width="
            + this.width
            + ", height="
            + this.height
            + ", softness="
            + this.softness
            + ", thickness="
            + this.thickness
            + ", start="
            + this.start
            + ", end="
            + this.end
            + ", quality$value="
            + this.quality$value
            + ", round="
            + this.round
            + ", outlineColor$value="
            + this.outlineColor$value
            + ", color="
            + this.color
            + ")";
      }
   }
}
