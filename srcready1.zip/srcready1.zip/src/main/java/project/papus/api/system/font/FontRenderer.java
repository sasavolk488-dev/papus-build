package project.papus.api.system.font;

import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.ObjectList;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import java.awt.Color;
import java.awt.Font;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.apache.commons.lang3.mutable.MutableFloat;
import org.apache.commons.lang3.mutable.MutableInt;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import project.papus.api.event.EventManager;
import project.papus.api.system.font.entry.DrawEntry;
import project.papus.api.system.font.glyph.Glyph;
import project.papus.api.system.font.glyph.GlyphMap;
import project.papus.common.QuickImports;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.other.StringUtil;
import project.papus.implement.events.render.TextFactoryEvent;

public class FontRenderer implements QuickImports {
   private final Object2ObjectMap<Identifier, ObjectList<DrawEntry>> GLYPH_PAGE_CACHE = new Object2ObjectOpenHashMap();
   private final ObjectList<GlyphMap> maps = new ObjectArrayList();
   private Font font;

   public FontRenderer(Font var1, float var2) {
      this.init(var1, var2);
   }

   private void init(Font var1, float var2) {
      this.font = var1.deriveFont(var2 * 2.0F);
   }

   private GlyphMap generateMap(char var1, char var2) {
      GlyphMap var3 = new GlyphMap(var1, var2, this.font, randomIdentifier(), 5);
      this.maps.add(var3);
      return var3;
   }

   Glyph locateGlyph(char var1) {
      ObjectListIterator var2 = this.maps.iterator();

      while (var2.hasNext()) {
         GlyphMap var3 = (GlyphMap)var2.next();
         if (var3.contains(var1)) {
            return var3.getGlyph(var1);
         }
      }

      char var4 = (char)MathUtil.randomInt(var1, 128);
      return this.generateMap(var4, (char)(var4 + 128)).getGlyph(var1);
   }

   public void drawText(MatrixStack var1, Text var2, double var3, double var5) {
      StringBuilder var7 = new StringBuilder();
      this.appendText(var7, var2);
      this.drawString(var1, var7.toString(), var3, var5, ColorUtil.getTextColor());
   }

   public void appendText(StringBuilder var1, Text var2) {
      Style var3 = var2.getStyle();
      if (var2.getSiblings().isEmpty()) {
         if (var3.getColor() != null) {
            var1.append(ColorUtil.colorToHex(var3.getColor().getRgb()));
         }

         var1.append(var2.getString()).append(Formatting.RESET);
      } else {
         var2.getWithStyle(var3).forEach(var2x -> this.appendText(var1, var2x));
      }
   }

   public void drawGradientString(MatrixStack var1, String var2, double var3, double var5, float var7, int var8) {
      String var9 = "  |  ";
      float var10 = this.getStringWidth(var2 + var9);
      if (var10 - var7 < 10.0F) {
         this.drawString(var1, var2, var3, var5, var8);
      } else {
         this.drawString(var1, var2 + var9 + var2, var3 - MathUtil.sinWave(var10), var5, var8);
      }
   }

   public void drawString(MatrixStack var1, String var2, double var3, double var5, int var7) {
      TextFactoryEvent var8 = new TextFactoryEvent(var2);
      EventManager.callEvent(var8);
      var2 = var8.getText();
      char[] var9 = var2.toCharArray();
      float var10 = 0.0F;
      float var11 = 0.0F;
      int var12 = 0;
      StringBuilder var13 = new StringBuilder();
      boolean var14 = false;
      boolean var15 = false;
      int var16 = var7;

      for (int var17 = 0; var17 < var9.length; var17++) {
         char var18 = var9[var17];
         if (var18 == 167) {
            var14 = true;
         } else if (var14) {
            var14 = false;
            char var19 = Character.toUpperCase(var18);
            if (ColorUtil.colorCodes.containsKey(var19)) {
               var16 = new Color(ColorUtil.colorCodes.get(var19)).getRGB();
            } else if (var19 == 'R') {
               var16 = var7;
            }
         } else if (var18 == 9167) {
            if (var15) {
               var16 = new Color(Integer.parseInt(var13.toString())).getRGB();
               var13.setLength(0);
            }

            var15 = !var15;
         } else if (var15) {
            var13.append(var18);
         } else if (var18 == '\n') {
            var11 += this.getStringHeight(var2.substring(var12, var17)) - 2.0F;
            var10 = 0.0F;
            var12 = var17 + 1;
         } else {
            Glyph var23 = this.locateGlyph(var18);
            if (var23 != null) {
               if (var23.value() != ' ') {
                  Identifier var20 = var23.owner().bindToTexture;
                  DrawEntry var21 = new DrawEntry(var10, var11, var16, var23);
                  ((ObjectList)this.GLYPH_PAGE_CACHE.computeIfAbsent(var20, var0 -> new ObjectArrayList())).add(var21);
               }

               var10 += var23.width();
            }
         }
      }

      if (!this.GLYPH_PAGE_CACHE.isEmpty()) {
         this.renderGlyphs(var1, var3, var5);
      }

      this.GLYPH_PAGE_CACHE.clear();
   }

   public void drawStringWithShadow(MatrixStack var1, String var2, double var3, double var5, int var7, int var8) {
      TextFactoryEvent var9 = new TextFactoryEvent(var2);
      EventManager.callEvent(var9);
      var2 = var9.getText();
      char[] var10 = var2.toCharArray();
      float var11 = 0.0F;
      float var12 = 0.0F;
      int var13 = 0;
      int var14 = var2.length();

      for (int var15 = 0; var15 < var10.length; var15++) {
         char var16 = var10[var15];
         if (var16 == '\n') {
            var12 += this.getStringHeight(var2.substring(var13, var15)) - 2.0F;
            var11 = 0.0F;
            var13 = var15 + 1;
         } else {
            Glyph var17 = this.locateGlyph(var16);
            if (var17 != null) {
               if (var17.value() != ' ') {
                  float var18 = (float)var15 / (var14 - 1);
                  int var19 = this.lerpColor(var7, var8, var18);
                  Identifier var20 = var17.owner().bindToTexture;
                  DrawEntry var21 = new DrawEntry(var11, var12, var19, var17);
                  ((ObjectList)this.GLYPH_PAGE_CACHE.computeIfAbsent(var20, var0 -> new ObjectArrayList())).add(var21);
               }

               var11 += var17.width();
            }
         }
      }

      if (!this.GLYPH_PAGE_CACHE.isEmpty()) {
         this.renderGlyphs(var1, var3, var5);
      }

      this.GLYPH_PAGE_CACHE.clear();
   }

   private void renderGlyphs(MatrixStack var1, double var2, double var4) {
      var1.push();
      var1.translate(var2, var4 - 3.0, 0.0);
      var1.scale(0.5F, 0.5F, 1.0F);
      Matrix4f var6 = var1.peek().getPositionMatrix();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      ObjectIterator var7 = this.GLYPH_PAGE_CACHE.keySet().iterator();

      while (var7.hasNext()) {
         Identifier var8 = (Identifier)var7.next();
         RenderSystem.setShaderTexture(0, var8);
         BufferBuilder var9 = QuickImports.tessellator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
         ObjectListIterator var10 = ((ObjectList)this.GLYPH_PAGE_CACHE.get(var8)).iterator();

         while (var10.hasNext()) {
            DrawEntry var11 = (DrawEntry)var10.next();
            float var12 = var11.atX();
            float var13 = var11.atY();
            Glyph var14 = var11.toDraw();
            GlyphMap var15 = var14.owner();
            float var16 = var14.width();
            float var17 = var14.height();
            float var18 = (float)var14.u() / var15.width;
            float var19 = (float)var14.v() / var15.height;
            float var20 = (float)(var14.u() + var14.width()) / var15.width;
            float var21 = (float)(var14.v() + var14.height()) / var15.height;
            int var22 = var11.color();
            var9.vertex(var6, var12 + 0.0F, var13 + var17, 0.0F).texture(var18, var21).color(var22);
            var9.vertex(var6, var12 + var16, var13 + var17, 0.0F).texture(var20, var21).color(var22);
            var9.vertex(var6, var12 + var16, var13 + 0.0F, 0.0F).texture(var20, var19).color(var22);
            var9.vertex(var6, var12 + 0.0F, var13 + 0.0F, 0.0F).texture(var18, var19).color(var22);
         }

         BufferRenderer.drawWithGlobalProgram(var9.end());
      }

      RenderSystem.disableBlend();
      var1.pop();
   }

   public void drawCenteredString(MatrixStack var1, String var2, double var3, double var5, int var7) {
      this.drawString(var1, var2, (int)(var3 - this.getStringWidth(var2) / 2.0F), (float)var5, var7);
   }

   public float getStringWidth(Text var1) {
      return var1 != null ? this.getStringWidth(var1.getString()) : 0.0F;
   }

   public float getStringWidth(String var1) {
      TextFactoryEvent var2 = new TextFactoryEvent(var1);
      EventManager.callEvent(var2);
      var1 = var2.getText();
      float var3 = 0.0F;
      float var4 = 0.0F;
      boolean var5 = false;

      for (char var9 : var1.toCharArray()) {
         if (var5) {
            var5 = false;
         } else if (var9 == 167) {
            var5 = true;
         } else if (var9 == '\n') {
            var4 = Math.max(var3, var4);
            var3 = 0.0F;
         } else {
            Glyph var10 = this.locateGlyph(var9);
            var3 += var10 == null ? 0.0F : var10.width();
         }
      }

      return Math.max(var3, var4) / 2.0F;
   }

   public float getStringHeight(Text var1) {
      return this.getStringHeight(var1.getString());
   }

   public float getStringHeight(String var1) {
      float var2 = 0.0F;
      float var3 = 0.0F;

      for (char var7 : (var1.isEmpty() ? " " : var1).toCharArray()) {
         if (var7 == '\n') {
            var2 = var2 == 0.0F ? this.locateGlyph(' ').height() : var2;
            var3 += var2;
            var2 = 0.0F;
         } else {
            Glyph var8 = this.locateGlyph(var7);
            var2 = Math.max(var8 == null ? 0.0F : var8.height(), var2);
         }
      }

      return var2 + var3;
   }

   public String trimToWidth(String var1, int var2, boolean var3) {
      return var3 ? this.wrapString(var1, var2) : this.trimToWidth(var1, var2);
   }

   public String trimToWidth(String var1, int var2) {
      return var1.substring(0, this.getTrimIndex(var1, var2));
   }

   private int getTrimIndex(String var1, int var2) {
      FontRenderer.ColoredTextSegment var3 = new FontRenderer.ColoredTextSegment(var2);
      this.parseGradient(var1, var3);
      return var3.getColor();
   }

   public String wrapString(String var1, int var2) {
      MutableFloat var3 = new MutableFloat(var2);
      MutableInt var4 = new MutableInt(var1.length());

      for (int var5 = var1.length() - 1; var5 >= 0; var5--) {
         char var6 = var1.charAt(var5);
         Glyph var7 = this.locateGlyph(var6);
         if (var7 != null) {
            var3.subtract(var7.width());
            if (var3.floatValue() < 0.0F) {
               var4.setValue(var5 + 1);
               break;
            }
         }
      }

      return var1.substring(var4.intValue());
   }

   private boolean parseGradient(String var1, FontRenderer.GradientTextPart var2) {
      int var3 = var1.length();

      for (int var4 = 0; var4 < var3; var4++) {
         char var5 = var1.charAt(var4);
         if (!var2.contains(var4, var5)) {
            return false;
         }
      }

      return true;
   }

   private int lerpColor(int var1, int var2, float var3) {
      float var4 = (var1 >> 24 & 0xFF) / 255.0F;
      float var5 = (var1 >> 16 & 0xFF) / 255.0F;
      float var6 = (var1 >> 8 & 0xFF) / 255.0F;
      float var7 = (var1 & 0xFF) / 255.0F;
      float var8 = (var2 >> 24 & 0xFF) / 255.0F;
      float var9 = (var2 >> 16 & 0xFF) / 255.0F;
      float var10 = (var2 >> 8 & 0xFF) / 255.0F;
      float var11 = (var2 & 0xFF) / 255.0F;
      float var12 = var4 + var3 * (var8 - var4);
      float var13 = var5 + var3 * (var9 - var5);
      float var14 = var6 + var3 * (var10 - var6);
      float var15 = var7 + var3 * (var11 - var7);
      return (int)(var12 * 255.0F) << 24 | (int)(var13 * 255.0F) << 16 | (int)(var14 * 255.0F) << 8 | (int)(var15 * 255.0F);
   }

   @Contract(value = "-> new", pure = true)
   @NotNull
   public static Identifier randomIdentifier() {
      return Identifier.of("papus", "temp/" + StringUtil.randomString(32));
   }

   @Contract(value = "_ -> new", pure = true)
   public static int @NotNull [] RGBIntToRGB(int var0) {
      int var1 = var0 >> 16 & 0xFF;
      int var2 = var0 >> 8 & 0xFF;
      int var3 = var0 & 0xFF;
      return new int[]{var1, var2, var3};
   }

   public FontRenderer setFont(Font var1) {
      this.font = var1;
      return this;
   }

   public Font getFont() {
      return this.font;
   }

   class ColoredTextSegment implements FontRenderer.GradientTextPart {
      private float progress;
      private int color;

      public ColoredTextSegment(float var2) {
         this.progress = var2;
      }

      @Override
      public boolean contains(int var1, char var2) {
         Glyph var3 = FontRenderer.this.locateGlyph(var2);
         if (var3 != null) {
            this.progress = this.progress - var3.width();
            if (this.progress >= 0.0F) {
               this.color = var1 + 1;
               return true;
            }
         }

         return false;
      }

      public int getColor() {
         return this.color;
      }
   }

   @FunctionalInterface
   public interface GradientTextPart {
      boolean contains(int var1, char var2);
   }
}
