package project.papus.api.system.animation;

public interface AnimationCalculation {
   default double calculation(double var1) {
      return 0.0;
   }
}
