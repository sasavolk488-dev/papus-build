package project.papus.api.file.exception;

public class FileLoadException extends FileProcessingException {
   public FileLoadException(String var1) {
      super(var1);
   }

   public FileLoadException(String var1, Throwable var2) {
      super(var1, var2);
   }
}
