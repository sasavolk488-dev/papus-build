package project.papus.api.system.localization;

import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;
import project.papus.common.QuickImports;

public class Localization implements QuickImports {
   private static final Map<Language, Map<String, String>> cache = new ConcurrentHashMap<>();

   public static String get(String var0) {
      Map<String, String> var1 = cache.computeIfAbsent(Language.ENG, var0x -> {
         try {
            Identifier var1x = Identifier.of("translations/" + var0x.getFile() + ".json");
            InputStream var2 = ((Resource)mc.getResourceManager().getResource(var1x).get()).getInputStream();
            BufferedReader var3 = new BufferedReader(new InputStreamReader(var2, StandardCharsets.UTF_8));
            return (Map<String, String>)gson.fromJson(var3, (new TypeToken<Map<String, String>>() {}).getType());
         } catch (Exception var4) {
            throw new RuntimeException(var4);
         }
      });
      return var1.getOrDefault(var0, var0);
   }
}
