package project.papus.api.system.draw;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector4i;
import project.papus.common.QuickImports;
import project.papus.common.util.render.Render3DUtil;

public class DrawEngineImpl implements DrawEngine, QuickImports {
   @Override
   public void quad(Matrix4f var1, BufferBuilder var2, float var3, float var4, float var5, float var6) {
      var2.vertex(var1, var3, var4, 0.0F);
      var2.vertex(var1, var3, var4 + var6, 0.0F);
      var2.vertex(var1, var3 + var5, var4 + var6, 0.0F);
      var2.vertex(var1, var3 + var5, var4, 0.0F);
   }

   @Override
   public void quadTexture(MatrixStack var1, Identifier var2, float var3, float var4, float var5, float var6, int var7) {
      Render3DUtil.drawTexture(var1.peek(), var2, var3, var4, var5, var6, new Vector4i(var7), false);
   }

   @Override
   public void quad(Matrix4f var1, BufferBuilder var2, float var3, float var4, float var5, float var6, int var7) {
      var2.vertex(var1, var3, var4, 0.0F).color(var7);
      var2.vertex(var1, var3, var4 + var6, 0.0F).color(var7);
      var2.vertex(var1, var3 + var5, var4 + var6, 0.0F).color(var7);
      var2.vertex(var1, var3 + var5, var4, 0.0F).color(var7);
   }

   @Override
   public void quad(Matrix4f var1, float var2, float var3, float var4, float var5, int var6) {
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      BufferBuilder var7 = QuickImports.tessellator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
      var7.vertex(var1, var2, var3 + var5, 0.0F).texture(0.0F, 0.0F).color(var6);
      var7.vertex(var1, var2 + var4, var3 + var5, 0.0F).texture(0.0F, 1.0F).color(var6);
      var7.vertex(var1, var2 + var4, var3, 0.0F).texture(1.0F, 1.0F).color(var6);
      var7.vertex(var1, var2, var3, 0.0F).texture(1.0F, 0.0F).color(var6);
      BufferRenderer.drawWithGlobalProgram(var7.end());
   }

   @Override
   public void quad(Entry var1, BufferBuilder var2, float var3, float var4, float var5, float var6, Vector4i var7) {
      var2.vertex(var1, var3, var4 + var6, 0.0F).texture(0.0F, 0.0F).color(var7.x);
      var2.vertex(var1, var3 + var5, var4 + var6, 0.0F).texture(0.0F, 1.0F).color(var7.y);
      var2.vertex(var1, var3 + var5, var4, 0.0F).texture(1.0F, 1.0F).color(var7.w);
      var2.vertex(var1, var3, var4, 0.0F).texture(1.0F, 0.0F).color(var7.z);
   }
}
