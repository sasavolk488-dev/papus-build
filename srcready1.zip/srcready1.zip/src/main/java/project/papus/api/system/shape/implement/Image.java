package project.papus.api.system.shape.implement;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import project.papus.api.system.shape.Shape;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.QuickImports;

public class Image implements Shape, QuickImports {
   private String texture;

   @Override
   public void render(ShapeProperties var1) {
      MatrixStack var2 = var1.getMatrix();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderTexture(0, Identifier.of(this.texture));
      float var3 = var1.getWidth();
      float var4 = var1.getX() + var3;
      float var5 = var1.getY();
      var2.push();
      var2.translate(var4, var5, 0.0F);
      var2.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(90.0F));
      var2.translate(-var4, -var5, 0.0F);
      drawEngine.quad(var2.peek().getPositionMatrix(), var4, var5, var1.getHeight(), var3, var1.getColor().x);
      var2.pop();
      RenderSystem.disableBlend();
   }

   public Image setTexture(String var1) {
      this.texture = var1;
      return this;
   }
}
