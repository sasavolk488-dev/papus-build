package project.papus.api.system.logger.implement;

import java.util.Arrays;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import project.papus.api.system.logger.Logger;
import project.papus.common.QuickImports;

public class MinecraftLogger implements Logger, QuickImports {
   @Override
   public void log(Object var1) {
   }

   @Override
   public void minecraftLog(Text... var1) {
      if (mc.player != null) {
         MutableText var2 = Text.literal("");
         Arrays.asList(var1).forEach(var2::append);
         mc.inGameHud.getChatHud().addMessage(var2);
      }
   }
}
