package project.papus.api.feature.module;

import java.util.ArrayList;
import java.util.List;
import project.papus.implement.features.modules.misc.ClickFriend;
import project.papus.implement.features.modules.misc.NoFriendDamage;
import project.papus.implement.features.modules.misc.Panic;
import project.papus.implement.features.modules.misc.ServerHelper;
import project.papus.implement.features.modules.player.AimAssist;
import project.papus.implement.features.modules.player.AutoSwap;
import project.papus.implement.features.modules.player.AutoTotem;
import project.papus.implement.features.modules.player.ClickPearl;
import project.papus.implement.features.modules.player.FakePlayer;
import project.papus.implement.features.modules.player.FastExp;
import project.papus.implement.features.modules.player.NoPush;
import project.papus.implement.features.modules.player.Sprint;
import project.papus.implement.features.modules.player.TriggerBot;
import project.papus.implement.features.modules.render.Arrows;
import project.papus.implement.features.modules.render.AspectRatio;
import project.papus.implement.features.modules.render.CameraClip;
import project.papus.implement.features.modules.render.CrossHair;
import project.papus.implement.features.modules.render.Esp;
import project.papus.implement.features.modules.render.FreeLook;
import project.papus.implement.features.modules.render.FullBright;
import project.papus.implement.features.modules.render.HandTweaks;
import project.papus.implement.features.modules.render.Hud;
import project.papus.implement.features.modules.render.JumpCircle;
import project.papus.implement.features.modules.render.NameTags;
import project.papus.implement.features.modules.render.NoRender;
import project.papus.implement.features.modules.render.Particles;
import project.papus.implement.features.modules.render.SeeInvisible;
import project.papus.implement.features.modules.render.TargetEsp;
import project.papus.implement.features.modules.render.TimeChanger;
import project.papus.implement.features.modules.render.WardenHelper;

public class ModuleRepository {
   private final List<Module> modules = new ArrayList<>();

   public void setup() {
      this.register(
         new Sprint(),
         new AimAssist(),
         new NoFriendDamage(),
         new NoPush(),
         new AspectRatio(),
         new FreeLook(),
         new FakePlayer(),
         new FastExp(),
         new HandTweaks(),
         new ServerHelper(),
         new Arrows(),
         new CameraClip(),
         new Panic(),
         new WardenHelper(),
         new FullBright(),
         new ClickFriend(),
         new JumpCircle(),
         new TargetEsp(),
         new NoRender(),
         new TriggerBot(),
         new ClickPearl(),
         new SeeInvisible(),
         new Esp(),
         new Hud(),
         new NameTags(),
         new AutoSwap(),
         new AutoTotem(),
         new CrossHair(),
         new TimeChanger(),
         new Particles()
      );
   }

   public void register(Module... var1) {
      this.modules.addAll(List.of(var1));
   }

   public List<Module> modules() {
      return this.modules;
   }
}
