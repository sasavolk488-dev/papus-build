package project.papus.api.system.logger.implement;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.apache.logging.log4j.LogManager;
import project.papus.api.system.logger.Logger;

public class ConsoleLogger implements Logger {
   private final org.apache.logging.log4j.Logger logger = LogManager.getLogger("PAPUS");

   @Override
   public void log(Object var1) {
      this.logger.info("[PAPUS] {}", Formatting.WHITE, Formatting.WHITE, var1);
   }

   @Override
   public void minecraftLog(Text... var1) {
   }
}
