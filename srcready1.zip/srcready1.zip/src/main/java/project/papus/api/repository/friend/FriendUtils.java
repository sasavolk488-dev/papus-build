package project.papus.api.repository.friend;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

public final class FriendUtils {
   public static final List<Friend> friends = new ArrayList<>();

   public static void addFriend(PlayerEntity var0) {
      addFriend(var0.getName().getString());
   }

   public static void addFriend(String var0) {
      friends.add(new Friend(var0));
   }

   public static void removeFriend(PlayerEntity var0) {
      removeFriend(var0.getName().getString());
   }

   public static void removeFriend(String var0) {
      friends.removeIf(var1 -> var1.getName().equalsIgnoreCase(var0));
   }

   public static boolean isFriend(Entity var0) {
      return var0 instanceof PlayerEntity var1 ? isFriend(var1.getName().getString()) : false;
   }

   public static boolean isFriend(String var0) {
      return friends.stream().anyMatch(var1 -> var1.getName().equals(var0));
   }

   public static void clear() {
      friends.clear();
   }

   private FriendUtils() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static List<Friend> getFriends() {
      return friends;
   }
}
