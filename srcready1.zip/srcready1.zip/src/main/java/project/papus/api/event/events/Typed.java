package project.papus.api.event.events;

public interface Typed {
   byte getType();
}
