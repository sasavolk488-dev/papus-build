package project.papus.api.feature.module;

import java.util.List;

public class ModuleProvider {
   private final List<Module> modules;

   public <T extends Module> T get(String var1) {
      return this.modules.stream().filter(var1x -> var1x.getName().equalsIgnoreCase(var1)).map(var0 -> (T)var0).findFirst().orElse(null);
   }

   public <T extends Module> T get(Class<T> var1) {
      return this.modules.stream().filter(var1x -> var1.isAssignableFrom(var1x.getClass())).map(var1::cast).findFirst().orElse(null);
   }

   public List<Module> getModules() {
      return this.modules;
   }

   public ModuleProvider(List<Module> var1) {
      this.modules = var1;
   }
}
