package project.papus.api.feature.module.exception;

public final class ModuleException extends RuntimeException {
   private final String message;
   private final String moduleName;

   public ModuleException(String var1, String var2) {
      this.message = var1;
      this.moduleName = var2;
   }

   @Override
   public String getMessage() {
      return this.message;
   }

   public String getModuleName() {
      return this.moduleName;
   }

   @Override
   public String toString() {
      return "ModuleException(message=" + this.getMessage() + ", moduleName=" + this.getModuleName() + ")";
   }

   @Override
   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else if (!(var1 instanceof ModuleException var2)) {
         return false;
      } else if (!var2.canEqual(this)) {
         return false;
      } else if (!super.equals(var1)) {
         return false;
      } else {
         String var3 = this.getMessage();
         String var4 = var2.getMessage();
         if (var3 == null ? var4 == null : var3.equals(var4)) {
            String var5 = this.getModuleName();
            String var6 = var2.getModuleName();
            return var5 == null ? var6 == null : var5.equals(var6);
         } else {
            return false;
         }
      }
   }

   protected boolean canEqual(Object var1) {
      return var1 instanceof ModuleException;
   }

   @Override
   public int hashCode() {
      byte var1 = 59;
      int var2 = super.hashCode();
      String var3 = this.getMessage();
      var2 = var2 * 59 + (var3 == null ? 43 : var3.hashCode());
      String var4 = this.getModuleName();
      return var2 * 59 + (var4 == null ? 43 : var4.hashCode());
   }
}
