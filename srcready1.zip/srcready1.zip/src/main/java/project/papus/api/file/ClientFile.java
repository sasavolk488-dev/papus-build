package project.papus.api.file;

import java.io.File;

public abstract class ClientFile {
   private final String name;

   public abstract void saveToFile(File var1);

   public abstract void loadFromFile(File var1);

   public void saveToFile(File var1, String var2) {
   }

   public void loadFromFile(File var1, String var2) {
   }

   public String getName() {
      return this.name;
   }

   public ClientFile(String var1) {
      this.name = var1;
   }
}
