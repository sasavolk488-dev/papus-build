package project.papus.api.file;

import java.io.File;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import project.papus.api.file.exception.FileLoadException;
import project.papus.api.file.exception.FileSaveException;
import project.papus.api.file.impl.ModuleFile;
import project.papus.common.util.logger.LoggerUtil;

public class FileController {
   private final List<ClientFile> clientFiles;
   private final File filesDir;
   private final File configsDir;
   private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
   private final AtomicBoolean autoSaveEnabled = new AtomicBoolean(false);

   public FileController(List<ClientFile> var1, File var2, File var3) {
      this.clientFiles = var1;
      this.filesDir = var2;
      this.configsDir = var3;
      this.startAutoSave();
   }

   public void startAutoSave() {
      LoggerUtil.info("Auto-save system started!");
      this.scheduler.scheduleAtFixedRate(() -> {
         try {
            LoggerUtil.info("Saving with auto-save.");
            this.saveFiles();
         } catch (FileSaveException var2) {
            LoggerUtil.error("Failed to auto-save files: " + var2.getMessage());
         }
      }, 1L, 1L, TimeUnit.MINUTES);
   }

   public void stopAutoSave() {
      LoggerUtil.info("Auto-save shutdown");
      this.scheduler.shutdown();

      try {
         if (!this.scheduler.awaitTermination(1L, TimeUnit.MINUTES)) {
            this.scheduler.shutdownNow();
         }
      } catch (InterruptedException var2) {
         this.scheduler.shutdownNow();
      }
   }

   public void saveCurrentConfig() {
      if (this.autoSaveEnabled.compareAndSet(false, true)) {
         try {
            LoggerUtil.info("Saving files on exit..");
            this.saveFiles();
            LoggerUtil.info("Files saved successfully on exit");
         } catch (FileSaveException var5) {
            LoggerUtil.error("Failed to save files on exit: " + var5.getMessage());
         } finally {
            this.autoSaveEnabled.set(false);
         }
      }
   }

   public void saveFiles() {
      if (this.clientFiles.isEmpty()) {
         LoggerUtil.warn("No files to save from directory: " + this.filesDir.getPath());
      } else {
         for (ClientFile var2 : this.clientFiles) {
            try {
               File var3;
               if (var2 instanceof ModuleFile) {
                  var3 = this.configsDir;
                  var2.saveToFile(this.configsDir);
               } else {
                  var3 = this.filesDir;
                  var2.saveToFile(this.filesDir);
               }

               File var4 = new File(var3, var2.getName() + ".json");
               LoggerUtil.info("Successfully saved file: " + var2.getName() + " -> " + var4.getPath());
            } catch (FileSaveException var5) {
               throw new FileSaveException("Failed to save file: " + var2.getName(), var5);
            }
         }
      }
   }

   public void loadFiles() {
      if (this.clientFiles.isEmpty()) {
         LoggerUtil.warn("No files to load from directory: " + this.filesDir.getPath());
      } else {
         for (ClientFile var2 : this.clientFiles) {
            try {
               File var3;
               if (var2 instanceof ModuleFile) {
                  var3 = this.configsDir;
               } else {
                  var3 = this.filesDir;
               }

               File var4 = new File(var3, var2.getName() + ".json");
               LoggerUtil.info("Loading file: " + var4.getPath());
               if (var2 instanceof ModuleFile) {
                  var2.loadFromFile(this.configsDir);
               } else {
                  var2.loadFromFile(this.filesDir);
               }

               LoggerUtil.info("Successfully loaded file: " + var2.getName());
            } catch (FileLoadException var5) {
               LoggerUtil.error("Failed to load file: " + var2.getName() + " - " + var5.getMessage());
            }
         }
      }
   }

   public void saveFile(String var1) {
      for (ClientFile var3 : this.clientFiles) {
         if (var3 instanceof ModuleFile) {
            try {
               var3.saveToFile(this.configsDir, var1);
               File var4 = new File(this.configsDir, var1 + ".json");
               LoggerUtil.info("Successfully saved file: " + var1 + " -> " + var4.getPath());
            } catch (FileSaveException var5) {
               throw new FileSaveException("Failed to save file: " + var1, var5);
            }
         }
      }
   }

   public void loadFile(String var1) {
      for (ClientFile var3 : this.clientFiles) {
         if (var3 instanceof ModuleFile) {
            try {
               File var4 = new File(this.configsDir, var1 + ".json");
               LoggerUtil.info("Loading file: " + var4.getPath());
               var3.loadFromFile(this.configsDir, var1);
               LoggerUtil.info("Successfully loaded file: " + var1);
            } catch (FileLoadException var5) {
               throw new FileLoadException("Failed to load file: " + var1, var5);
            }
         }
      }
   }

   public File getFilesDir() {
      return this.filesDir;
   }

   public File getConfigsDir() {
      return this.configsDir;
   }

   public List<ClientFile> getClientFiles() {
      return this.clientFiles;
   }
}
