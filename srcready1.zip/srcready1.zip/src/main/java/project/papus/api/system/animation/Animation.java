package project.papus.api.system.animation;

import project.papus.common.util.math.Counter;

public abstract class Animation implements AnimationCalculation {
   private final Counter counter = new Counter();
   protected int ms;
   protected double value;
   protected Direction direction = Direction.FORWARDS;

   public void reset() {
      this.counter.resetCounter();
   }

   public boolean isDone() {
      return this.counter.isReached(this.ms);
   }

   public boolean isFinished(Direction var1) {
      return this.direction == var1 && this.isDone();
   }

   public void setDirection(Direction var1) {
      if (this.direction != var1) {
         this.direction = var1;
         this.correctOutput();
      }
   }

   public boolean isDirection(Direction var1) {
      return this.direction == var1;
   }

   private void correctOutput() {
      this.counter.setLastMS(System.currentTimeMillis() - (this.ms - Math.min((long)this.ms, this.counter.getTime())));
   }

   public Double getOutput() {
      double var1 = (1.0 - this.calculation(this.counter.getTime())) * this.value;
      return this.direction == Direction.FORWARDS ? this.getTimePassed() : (this.isDone() ? 0.0 : var1);
   }

   private double getTimePassed() {
      return this.isDone() ? this.value : this.calculation(this.counter.getTime()) * this.value;
   }

   public Animation setMs(int var1) {
      this.ms = var1;
      return this;
   }

   public Animation setValue(double var1) {
      this.value = var1;
      return this;
   }
}
