package project.papus.api.system.sound;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import project.papus.common.QuickImports;
import project.papus.common.util.entity.PlayerHealthUtil;

public final class SoundManager implements QuickImports {
   public static SoundEvent OPEN_GUI = SoundEvent.of(Identifier.of("minecraft:gui_open"));
   public static SoundEvent CLOSE_GUI = SoundEvent.of(Identifier.of("minecraft:gui_close"));
   public static SoundEvent ENABLE_MODULE = SoundEvent.of(Identifier.of("minecraft:module_enable"));
   public static SoundEvent DISABLE_MODULE = SoundEvent.of(Identifier.of("minecraft:module_disable"));

   public static void init() {
      Registry.register(Registries.SOUND_EVENT, OPEN_GUI.id(), OPEN_GUI);
      Registry.register(Registries.SOUND_EVENT, CLOSE_GUI.id(), CLOSE_GUI);
      Registry.register(Registries.SOUND_EVENT, ENABLE_MODULE.id(), ENABLE_MODULE);
      Registry.register(Registries.SOUND_EVENT, DISABLE_MODULE.id(), DISABLE_MODULE);
   }

   public static void playSound(SoundEvent var0) {
      playSound(var0, 1.0F, 1.0F);
   }

   public static void playSound(SoundEvent var0, float var1, float var2) {
      if (!PlayerHealthUtil.nullCheck()) {
         mc.world.playSound(mc.player, mc.player.getBlockPos(), var0, SoundCategory.BLOCKS, var1, var2);
      }
   }

   private SoundManager() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
