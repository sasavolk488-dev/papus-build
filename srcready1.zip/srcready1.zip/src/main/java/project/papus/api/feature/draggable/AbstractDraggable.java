package project.papus.api.feature.draggable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.ItemPickupAnimationS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import project.papus.api.feature.module.Module;
import project.papus.api.system.animation.Animation;
import project.papus.api.system.animation.Direction;
import project.papus.api.system.animation.implement.DecelerateAnimation;
import project.papus.api.system.font.FontRenderer;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.api.system.sound.SoundManager;
import project.papus.common.QuickImports;
import project.papus.common.QuickLogger;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.entity.PlayerHealthUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.other.Instance;
import project.papus.common.util.other.StopWatch;
import project.papus.common.util.other.StringUtil;
import project.papus.common.util.render.Render2DUtil;
import project.papus.core.Main;
import project.papus.implement.events.container.SetScreenEvent;
import project.papus.implement.events.packet.PacketEvent;
import project.papus.implement.features.modules.render.Hud;

public abstract class AbstractDraggable implements QuickImports, QuickLogger, Draggable {
   private String name;
   private int x;
   private int y;
   private int width;
   private int height;
   private boolean dragging;
   private boolean canDrag;
   private int dragX;
   private int dragY;
   public final Animation scaleAnimation = new DecelerateAnimation().setValue(1.0).setMs(200);
   private static final Set<String> HUD_ELEMENTS = Set.of("Target Hud", "Notifications", "Hot Keys", "Potions", "Watermark");

   public AbstractDraggable(String var1, int var2, int var3, int var4, int var5, boolean var6) {
      this.name = var1;
      this.x = var2;
      this.y = var3;
      this.width = var4;
      this.height = var5;
      this.canDrag = var6;
   }

   @Override
   public boolean visible() {
      return true;
   }

   @Override
   public void tick() {
   }

   @Override
   public void onPacket(PacketEvent var1) {
   }

   @Override
   public void render(DrawContext var1, int var2, int var3, float var4) {
      float var5 = var2 + this.dragX;
      float var6 = var3 + this.dragY;
      int var7 = window.getScaledWidth();
      int var8 = window.getScaledHeight();
      byte var9 = 3;
      this.x = (int)Math.max(0.0F, Math.min(var5, (float)(var7 - this.width)));
      this.y = (int)Math.max(0.0F, Math.min(var6, (float)(var8 - this.height)));

      for (AbstractDraggable var11 : Main.getInstance().getDraggableRepository().draggable()) {
         if (var11.canDraw(var11) && var11.canDrag && var11 != this) {
            int var12 = var11.x + var11.width + var9;
            int var13 = var11.x - this.width - var9;
            int var14 = var11.y + var11.height + var9;
            int var15 = var11.y - this.height - var9;
            int var16 = var11.y;
            if (Math.abs(var12 - var5) <= var9) {
               this.drawRect(var12 - 1.5F, 0.0F, 1.0F, var8);
               this.x = var12;
            }

            if (Math.abs(var13 - var5) <= var9) {
               this.drawRect(var13 + this.width + 1, 0.0F, 1.0F, var8);
               this.x = var13;
            }

            if (Math.abs(var14 - var6) <= var9) {
               this.drawRect(0.0F, var14 - 1.5F, var7, 1.0F);
               this.y = var14;
            }

            if (Math.abs(var15 - var6) <= var9) {
               this.drawRect(0.0F, var15 + this.height + 1, var7, 1.0F);
               this.y = var15;
            }

            if (Math.abs(var16 - var6) <= var9) {
               this.drawRect(0.0F, var16 - 1.5F, var7, 1.0F);
               this.y = var16;
            }
         }
      }

      if (Math.abs(this.x + (this.width - var7) / 2) <= var9) {
         this.drawRect(var7 / 2.0F - 0.5F, 0.0F, 1.0F, var8);
         this.x = (var7 - this.width) / 2;
      }

      if (Math.abs(this.y + (this.height - var8) / 2) <= var9) {
         this.drawRect(0.0F, var8 / 2.0F - 0.5F, var7, 1.0F);
         this.y = (var8 - this.height) / 2;
      }
   }

   @Override
   public void onSetScreen(SetScreenEvent var1) {
      if (PlayerHealthUtil.isChat(var1.getScreen())) {
         this.dragging = false;
      }
   }

   @Override
   public boolean mouseClicked(double var1, double var3, int var5) {
      if (this.isHovered(var1, var3) && var5 == 0 && this.canDrag) {
         this.dragging = true;
         this.dragX = this.x - (int)var1;
         this.dragY = this.y - (int)var3;
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseReleased(double var1, double var3, int var5) {
      this.dragging = false;
      return true;
   }

   public abstract void drawDraggable(DrawContext var1);

   public void drawRect(float var1, float var2, float var3, float var4) {
      Render2DUtil.drawQuad(var1, var2, var3, var4, ColorUtil.getTextColor(0.5F));
   }

   public void stopAnimation() {
      this.scaleAnimation.setDirection(Direction.BACKWARDS);
   }

   public void startAnimation() {
      this.scaleAnimation.setDirection(Direction.FORWARDS);
   }

   public void validPosition() {
      if (this.x + this.width > window.getScaledWidth()) {
         this.x = window.getScaledWidth() - this.width;
      }

      if (this.y + this.height > window.getScaledHeight()) {
         this.y = window.getScaledHeight() - this.height;
      }

      if (this.y < 0) {
         this.y = 0;
      }

      if (this.x < 0) {
         this.x = 0;
      }
   }

   public boolean isHovered(double var1, double var3) {
      return var1 >= this.x && var1 <= this.x + this.width && var3 >= this.y && var3 <= this.y + this.height;
   }

   public boolean isCloseAnimationFinished() {
      return this.scaleAnimation.isFinished(Direction.BACKWARDS);
   }

   public boolean canDraw(AbstractDraggable var1) {
      String var2 = var1.getName();
      if (HUD_ELEMENTS.contains(var2)) {
         Hud var3 = Hud.getInstance();
         if (var3 == null || !var3.isState() || !var3.elementsSetting.isSelected(var2)) {
            return false;
         }
      }

      return this.visible();
   }

   public void setName(String var1) {
      this.name = var1;
   }

   public void setX(int var1) {
      this.x = var1;
   }

   public void setY(int var1) {
      this.y = var1;
   }

   public void setWidth(int var1) {
      this.width = var1;
   }

   public void setHeight(int var1) {
      this.height = var1;
   }

   public void setDragging(boolean var1) {
      this.dragging = var1;
   }

   public void setCanDrag(boolean var1) {
      this.canDrag = var1;
   }

   public void setDragX(int var1) {
      this.dragX = var1;
   }

   public void setDragY(int var1) {
      this.dragY = var1;
   }

   public String getName() {
      return this.name;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getWidth() {
      return this.width;
   }

   public int getHeight() {
      return this.height;
   }

   public boolean isDragging() {
      return this.dragging;
   }

   public boolean isCanDrag() {
      return this.canDrag;
   }

   public int getDragX() {
      return this.dragX;
   }

   public int getDragY() {
      return this.dragY;
   }

   public Animation getScaleAnimation() {
      return this.scaleAnimation;
   }

   public static class HotKeysDraggable extends AbstractDraggable {
      private List<Module> activeModules = new ArrayList<>();
      private float animatedHeight = 23.0F;
      private final Map<String, Animation> moduleAnimations = new HashMap<>();
      private boolean inChat = false;

      public HotKeysDraggable() {
         super("Hot Keys", 300, 10, 100, 23, true);
      }

      @Override
      public boolean visible() {
         Hud var1 = Hud.getInstance();
         if (var1 == null || !var1.isState()) {
            return false;
         } else {
            return !var1.elementsSetting.isSelected("Hot Keys") ? false : this.animatedHeight > 19.0F || !this.activeModules.isEmpty() || this.inChat;
         }
      }

      @Override
      public void onSetScreen(SetScreenEvent var1) {
         this.inChat = var1.getScreen() != null;
         if (this.inChat && PlayerHealthUtil.isChat(var1.getScreen())) {
            this.setDragging(false);
         }
      }

      @Override
      public void tick() {
         List<Module> var1 = Main.getInstance()
            .getModuleProvider()
            .getModules()
            .stream()
            .filter(var0 -> var0.getAnimation().getOutput().floatValue() != 0.0F && var0.getKey() != -1)
            .filter(var0 -> !"CustomScoreboard".equals(var0.getName()))
            .toList();

         for (Module var3 : var1) {
            if (!this.moduleAnimations.containsKey(var3.getVisibleName())) {
               Animation var4 = new DecelerateAnimation().setMs(300).setValue(1.0);
               this.moduleAnimations.put(var3.getVisibleName(), var4);
            }
         }

         List<String> var10 = new ArrayList<>();

         for (Module var14 : var1) {
            var10.add(var14.getVisibleName());
         }

         for (String var6 : this.moduleAnimations.keySet().toArray(new String[0])) {
            boolean var7 = false;

            for (String var9 : var10) {
               if (var9.equals(var6)) {
                  var7 = true;
                  break;
               }
            }

            if (!var7) {
               this.moduleAnimations.remove(var6);
            }
         }

         this.activeModules = var1;
         float var13 = this.activeModules.isEmpty() ? 18.0F : 20.0F + this.activeModules.size() * 13.0F;
         this.animatedHeight = this.animatedHeight + (var13 - this.animatedHeight) * 0.5F;
         if (this.activeModules.isEmpty() && this.animatedHeight < 18.5F) {
            this.animatedHeight = 18.0F;
         }

         this.setHeight((int)this.animatedHeight);
      }

      @Override
      public void drawDraggable(DrawContext var1) {
         if (!this.activeModules.isEmpty() || this.inChat) {
            MatrixStack var2 = var1.getMatrices();
            float var3 = this.getX() + this.getWidth() / 2.0F;
            FontRenderer var4 = Fonts.getSize(14, Fonts.Type.DEFAULT);
            FontRenderer var5 = Fonts.getSize(13, Fonts.Type.DEFAULT);
            float var6 = this.getWidth();
            float var7 = this.getHeight();
            rectangle.render(ShapeProperties.create(var2, this.getX(), this.getY(), var6, var7).round(6.0F).color(ColorUtil.getColor(12, 4, 18, 255)).build());
            var4.drawString(var2, "Keybinds", this.getX() + 6, this.getY() + 7, ColorUtil.getColor(255, 255, 255, 220));
            byte var8 = 20;
            int var9 = 0;

            for (Module var11 : this.activeModules) {
               String var12 = StringUtil.getShortBindName(var11.getKey());
               float var13 = this.getY() + var8 + 2.0F;
               float var14 = var11.getAnimation().getOutput().floatValue();
               Animation var15 = this.moduleAnimations.get(var11.getVisibleName());
               float var16 = var15 != null ? var15.getOutput().floatValue() : 1.0F;
               if (var15 != null && var16 < 1.0F) {
                  var15.setDirection(Direction.FORWARDS);
               }

               float var17 = Math.min(var14, var16);
               MathUtil.scale(
                  var2,
                  var3,
                  var13,
                  1.0F,
                  var17,
                  () -> {
                     var5.drawString(var2, var11.getVisibleName(), this.getX() + 6, var13 + 1.0F, ColorUtil.getColor(255, 255, 255, 220));
                     Fonts.getSize(12, Fonts.Type.DEFAULT)
                        .drawString(var2, var12, this.getX() + var6 - 6.0F - var5.getStringWidth(var12), var13 + 2.0F, ColorUtil.getColor(255, 255, 255, 220));
                  }
               );
               int var18 = (int)(var5.getStringWidth(var11.getVisibleName() + var12) + 20.0F);
               if (var18 > var9) {
                  var9 = var18;
               }

               var8 += 13;
            }

            this.setWidth(Math.max(var9, 80));
         }
      }
   }

   public static class NotificationsDraggable extends AbstractDraggable {
      private final List<AbstractDraggable.NotificationsDraggable.NotificationEntry> notifications = new ArrayList<>();
      private final List<AbstractDraggable.NotificationsDraggable.StackNotificationEntry> stackNotifications = new ArrayList<>();

      public static AbstractDraggable.NotificationsDraggable getInstance() {
         return Instance.getDraggable(AbstractDraggable.NotificationsDraggable.class);
      }

      public NotificationsDraggable() {
         super("Notifications", 0, 50, 100, 15, true);
      }

      @Override
      public boolean visible() {
         return true;
      }

      private boolean isNotificationsEnabled() {
         Hud var1 = Hud.getInstance();
         return var1 != null && var1.isState() && var1.elementsSetting.isSelected("Notifications");
      }

      @Override
      public void tick() {
         if (this.isNotificationsEnabled()) {
            this.notifications
               .forEach(
                  var0 -> {
                     if (System.currentTimeMillis() > var0.removeTime
                        || var0.text
                              .getString()
                              .contains("\u041f\u0440\u0438\u043c\u0435\u0440 \u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f")
                           && !PlayerHealthUtil.isChat(mc.currentScreen)) {
                        var0.anim.setDirection(Direction.BACKWARDS);
                     }
                  }
               );
            this.notifications.removeIf(var0 -> var0.anim.isFinished(Direction.BACKWARDS));

            while (!this.stackNotifications.isEmpty()) {
               if (this.isNotificationsEnabled()) {
                  this.addNotification(
                     AbstractDraggable.NotificationsDraggable.NotificationType.INVENTORY,
                     "\u041f\u043e\u0434\u043d\u044f\u0442\u044b \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u044b: "
                  );
               }
            }
         }
      }

      @Override
      public void onPacket(PacketEvent var1) {
         if (this.isNotificationsEnabled()) {
            if (!PlayerHealthUtil.nullCheck()) {
               Packet var2 = var1.getPacket();
               if (var2 instanceof ItemPickupAnimationS2CPacket var3) {
                  if (var3.getCollectorEntityId() == Objects.requireNonNull(mc.player).getId()
                     && Objects.requireNonNull(mc.world).getEntityById(var3.getEntityId()) instanceof ItemEntity var5) {
                     ItemStack var11 = var5.getStack();
                     ContainerComponent var7 = (ContainerComponent)var11.get(DataComponentTypes.CONTAINER);
                     if (var7 == null) {
                        Text var8 = var11.getName();
                        if (var8.getContent().toString().equals("empty")) {
                           MutableText var9 = Text.empty().append(var8);
                           if (var11.getCount() > 1) {
                              var9.append(Formatting.RESET + " [" + Formatting.RED + var11.getCount() + Formatting.GRAY + "x" + Formatting.RESET + "]");
                           }

                           this.stackNotifications
                              .add(
                                 new AbstractDraggable.NotificationsDraggable.StackNotificationEntry(
                                    AbstractDraggable.NotificationsDraggable.NotificationType.INVENTORY, var9
                                 )
                              );
                           return;
                        }
                     } else {
                        var7.stream()
                           .filter(var0 -> var0.getName().getContent().toString().equals("empty"))
                           .forEach(
                              var1x -> {
                                 MutableText var2x = Text.empty().append(var1x.getName());
                                 if (var1x.getCount() > 1) {
                                    var2x.append(Formatting.RESET + " [" + Formatting.RED + var1x.getCount() + Formatting.GRAY + "x" + Formatting.RESET + "]");
                                 }

                                 this.stackNotifications
                                    .add(
                                       new AbstractDraggable.NotificationsDraggable.StackNotificationEntry(
                                          AbstractDraggable.NotificationsDraggable.NotificationType.SHULKER, var2x
                                       )
                                    );
                              }
                           );
                     }

                     return;
                  }
               } else if (var2 instanceof ScreenHandlerSlotUpdateS2CPacket var4) {
                  int var10 = var4.getSlot();
                  ContainerComponent var12 = (ContainerComponent)var4.getStack().get(DataComponentTypes.CONTAINER);
                  if (var12 != null && var10 < Objects.requireNonNull(mc.player).currentScreenHandler.slots.size() && var4.getSyncId() == 0) {
                     ContainerComponent var13 = (ContainerComponent)mc.player.currentScreenHandler.getSlot(var10).getStack().get(DataComponentTypes.CONTAINER);
                     if (var13 != null) {
                        var12.stream()
                           .filter(
                              var1x -> var13.stream()
                                 .noneMatch(
                                    var1xx -> Objects.equals(var1xx.getComponents(), var1x.getComponents()) && var1xx.toString().equals(var1x.toString())
                                 )
                           )
                           .forEach(
                              var1x -> {
                                 MutableText var2x = Text.empty().append(var1x.getName());
                                 this.stackNotifications
                                    .add(
                                       new AbstractDraggable.NotificationsDraggable.StackNotificationEntry(
                                          AbstractDraggable.NotificationsDraggable.NotificationType.SHULKER_INVENTORY, var2x
                                       )
                                    );
                              }
                           );
                     }
                  }
               }
            }
         }
      }

      @Override
      public void onSetScreen(SetScreenEvent var1) {
         if (var1.getScreen() instanceof ChatScreen) {
            this.addTextIfNotExists("\u041f\u0440\u0438\u043c\u0435\u0440 \u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f", 99999999L);
         }
      }

      @Override
      public void drawDraggable(DrawContext var1) {
         if (this.isNotificationsEnabled()) {
            MatrixStack var2 = var1.getMatrices();
            FontRenderer var3 = Fonts.getSize(12, Fonts.Type.DEFAULT);
            this.setX((window.getScaledWidth() - this.getWidth()) / 2);
            float var4 = 0.0F;
            float var5 = 5.0F;

            for (AbstractDraggable.NotificationsDraggable.NotificationEntry var7 : this.notifications) {
               float var8 = var7.anim.getOutput().floatValue();
               float var9 = var3.getStringWidth(var7.text) + var5 * 2.0F;
               float var10 = this.getY() + var4;
               float var11 = this.getX() + (this.getWidth() - var9) / 2.0F;
               MathUtil.setAlpha(
                  var8,
                  () -> {
                     blur.render(
                        ShapeProperties.create(var2, var11, var10, var9, this.getHeight())
                           .round(3.0F)
                           .quality(5.0F)
                           .softness(1.0F)
                           .outlineColor(ColorUtil.getColor(120, 40, 180, 255))
                           .color(ColorUtil.getColor(12, 4, 18, 240))
                           .build()
                     );
                     var3.drawText(var2, var7.text, (int)(var11 + var5), var10 + 6.5F);
                  }
               );
               var4 += (this.getHeight() + 3) * var8;
            }
         }
      }

      private void addNotification(AbstractDraggable.NotificationsDraggable.NotificationType var1, String var2) {
         MutableText var3 = Text.empty();
         List var4 = this.stackNotifications.stream().filter(var1x -> var1x.type.equals(var1)).toList();
         int var5 = 0;

         for (int var6 = var4.size(); var5 < var6; var5++) {
            AbstractDraggable.NotificationsDraggable.StackNotificationEntry var7 = (AbstractDraggable.NotificationsDraggable.StackNotificationEntry)var4.get(
               var5
            );
            if (var7.type == var1) {
               var3.append(var7.text);
               this.stackNotifications.remove(var7);
               if (var3.getString().length() > 150) {
                  break;
               }

               if (var5 + 1 != var6) {
                  var3.append(" ,  ");
               }
            }
         }

         if (!var3.equals(Text.empty())) {
            this.addTextIfNotExists(Text.empty().append(var2).append(var3), 8000L);
         }
      }

      public void addTextIfNotExists(String var1, long var2) {
         this.addNotification(var1, var2, null);
      }

      public void addTextIfNotExists(Text var1, long var2) {
         this.addNotification(var1, var2, null);
      }

      public void addNotification(String var1, long var2, SoundEvent var4) {
         this.addNotification(Text.empty().append(var1), var2, var4);
      }

      public void addNotification(Text var1, long var2, SoundEvent var4) {
         this.notifications
            .add(
               new AbstractDraggable.NotificationsDraggable.NotificationEntry(
                  var1, new DecelerateAnimation().setMs(300).setValue(1.0), System.currentTimeMillis() + var2
               )
            );
         if (this.notifications.size() > 12) {
            this.notifications.removeFirst();
         }

         this.notifications.sort(Comparator.comparingDouble(var0 -> -var0.removeTime));
         if (var4 != null) {
            SoundManager.playSound(var4);
         }
      }

      public record NotificationEntry(Text text, Animation anim, long removeTime) {
      }

      public static enum NotificationType {
         INVENTORY,
         SHULKER,
         SHULKER_INVENTORY;
      }

      public record StackNotificationEntry(AbstractDraggable.NotificationsDraggable.NotificationType type, MutableText text) {
      }
   }

   public static class PotionsDraggable extends AbstractDraggable {
      private final List<AbstractDraggable.PotionsDraggable.AnimatedStatusEffect> effects = new ArrayList<>();
      private boolean inChat = false;

      public PotionsDraggable() {
         super("Potions", 1700, 10, 100, 23, true);
      }

      @Override
      public boolean visible() {
         Hud var1 = Hud.getInstance();
         if (var1 == null || !var1.isState()) {
            return false;
         } else {
            return !var1.elementsSetting.isSelected("Potions") ? false : !this.effects.isEmpty() || this.inChat;
         }
      }

      @Override
      public void onSetScreen(SetScreenEvent var1) {
         this.inChat = var1.getScreen() != null;
         if (this.inChat && PlayerHealthUtil.isChat(var1.getScreen())) {
            this.setDragging(false);
         }
      }

      @Override
      public void tick() {
         if (mc.player != null) {
            Collection<StatusEffectInstance> var1 = mc.player.getStatusEffects();

            for (AbstractDraggable.PotionsDraggable.AnimatedStatusEffect var3 : this.effects) {
               boolean var4 = false;

               for (StatusEffectInstance var6 : var1) {
                  if (var6.getEffectType().equals(var3.effect.getEffectType())) {
                     var4 = true;
                     break;
                  }
               }

               if (!var4) {
                  var3.animation.setDirection(Direction.BACKWARDS);
               }
            }

            for (StatusEffectInstance var8 : var1) {
               boolean var9 = false;

               for (AbstractDraggable.PotionsDraggable.AnimatedStatusEffect var12 : this.effects) {
                  if (var12.effect.getEffectType().equals(var8.getEffectType())) {
                     var9 = true;
                     break;
                  }
               }

               if (!var9) {
                  this.effects.add(new AbstractDraggable.PotionsDraggable.AnimatedStatusEffect(var8, new DecelerateAnimation().setMs(300).setValue(1.0)));
               } else {
                  for (int var11 = 0; var11 < this.effects.size(); var11++) {
                     AbstractDraggable.PotionsDraggable.AnimatedStatusEffect var13 = this.effects.get(var11);
                     if (var13.effect.getEffectType().equals(var8.getEffectType())) {
                        this.effects.set(var11, new AbstractDraggable.PotionsDraggable.AnimatedStatusEffect(var8, var13.animation));
                        break;
                     }
                  }
               }
            }
         }

         this.effects.removeIf(var0 -> var0.animation.isFinished(Direction.BACKWARDS));
      }

      @Override
      public void drawDraggable(DrawContext var1) {
         if (!this.effects.isEmpty() || this.inChat) {
            MatrixStack var2 = var1.getMatrices();
            float var3 = this.getX() + this.getWidth() / 2.0F;
            FontRenderer var4 = Fonts.getSize(14, Fonts.Type.DEFAULT);
            FontRenderer var5 = Fonts.getSize(13, Fonts.Type.DEFAULT);
            rectangle.render(
               ShapeProperties.create(var2, this.getX(), this.getY(), this.getWidth(), this.getHeight())
                  .round(6.0F)
                  .color(ColorUtil.getColor(12, 4, 18, 255))
                  .build()
            );
            var4.drawString(var2, "Potions", this.getX() + 6, this.getY() + 6, ColorUtil.getColor(255, 255, 255, 220));
            byte var6 = 18;
            int var7 = 0;

            for (AbstractDraggable.PotionsDraggable.AnimatedStatusEffect var9 : this.effects) {
               StatusEffectInstance var10 = var9.effect;
               float var11 = var9.animation.getOutput().floatValue();
               float var12 = this.getY() + var6 + 2.0F;
               int var13 = var10.getAmplifier();
               String var14 = ((StatusEffect)var10.getEffectType().value()).getName().getString();
               String var15 = this.getDurationString(var10);
               String var16 = var13 > 0 ? " " + (var13 + 1) : "";
               MathUtil.scale(
                  var2,
                  var3,
                  var12,
                  1.0F,
                  var11,
                  () -> {
                     Render2DUtil.drawSprite(var2, mc.getStatusEffectSpriteManager().getSprite(var10.getEffectType()), this.getX() + 4, (int)var12, 9.0F, 9);
                     var5.drawString(var2, var14 + var16, this.getX() + 16, var12 + 1.0F, ColorUtil.getColor(255, 255, 255, 220));
                     Fonts.getSize(12, Fonts.Type.DEFAULT)
                        .drawString(
                           var2, var15, this.getX() + this.getWidth() - 6 - var5.getStringWidth(var15), var12 + 2.0F, ColorUtil.getColor(255, 255, 255, 220)
                        );
                  }
               );
               int var17 = (int)(var5.getStringWidth(var14 + var16 + var15) + 28.0F);
               if (var17 > var7) {
                  var7 = var17;
               }

               var6 += 13;
            }

            this.setWidth(Math.max(var7, 95));
            this.setHeight(this.effects.isEmpty() ? 16 : var6 + 2);
         }
      }

      private String getDurationString(StatusEffectInstance var1) {
         int var2 = var1.getDuration();
         int var3 = var2 / 1200;
         return !var1.isInfinite() && var3 <= 60 ? var3 + ":" + String.format("%02d", var2 % 1200 / 20) : "**:**";
      }

      static class AnimatedStatusEffect {
         StatusEffectInstance effect;
         Animation animation;

         AnimatedStatusEffect(StatusEffectInstance var1, Animation var2) {
            this.effect = var1;
            this.animation = var2;
         }
      }
   }

   public static class TargetHudDraggable extends AbstractDraggable {
      private final Animation scaleAnim = new DecelerateAnimation().setMs(120).setValue(1.0);
      private final Animation hurtAnim = new DecelerateAnimation().setMs(800).setValue(0.0);
      private final Animation absorptionAnim = new DecelerateAnimation().setMs(600).setValue(0.0);
      private final StopWatch targetStopWatch = new StopWatch();
      private final StopWatch outStopWatch = new StopWatch();
      private LivingEntity lastTarget;
      private float health;
      private float absorption = -1.0F;
      private float hurtProgress;
      private float headScale;
      private boolean inChat = false;

      public TargetHudDraggable() {
         super("Target Hud", 9, 20, 120, 23, true);
         this.scaleAnimation.setMs(120);
      }

      @Override
      public boolean visible() {
         return this.scaleAnimation.isDirection(Direction.FORWARDS);
      }

      @Override
      public void onSetScreen(SetScreenEvent var1) {
         this.inChat = var1.getScreen() != null;
         if (this.inChat) {
            if (this.lastTarget == null) {
               ClientPlayerEntity var3 = mc.player;
               if (var3 instanceof LivingEntity) {
                  this.lastTarget = var3;
                  this.absorption = PlayerHealthUtil.getHealth(var3);
                  this.headScale = this.absorption;
               }
            }

            this.startAnimation();
         }

         if (PlayerHealthUtil.isChat(var1.getScreen())) {
            this.setDragging(false);
         }
      }

      @Override
      public void tick() {
         if (!this.inChat) {
            LivingEntity var1 = null;
            if (mc.crosshairTarget instanceof EntityHitResult var2 && var2.getEntity() instanceof LivingEntity var3) {
               var1 = var3;
            }

            if (var1 != null) {
               if (this.lastTarget == var1) {
                  float var6 = PlayerHealthUtil.getHealth(var1);
                  if (this.absorption != -1.0F && var6 < this.absorption - 0.1F) {
                     this.hurtAnim.setDirection(Direction.FORWARDS);
                     this.absorptionAnim.setDirection(Direction.FORWARDS);
                     this.outStopWatch.reset();
                     this.headScale = this.absorption;
                  }

                  if (Math.abs(var6 - this.absorption) > 0.05F) {
                     this.absorption = var6;
                  }
               } else {
                  this.absorption = PlayerHealthUtil.getHealth(var1);
                  this.headScale = this.absorption;
                  this.hurtAnim.setDirection(Direction.BACKWARDS);
                  this.absorptionAnim.setDirection(Direction.BACKWARDS);
               }

               this.lastTarget = var1;
               this.startAnimation();
               this.targetStopWatch.reset();
            } else if (this.targetStopWatch.every(500.0)) {
               this.stopAnimation();
               this.lastTarget = null;
               this.absorption = -1.0F;
               this.hurtAnim.setDirection(Direction.BACKWARDS);
               this.absorptionAnim.setDirection(Direction.BACKWARDS);
            }

            if (this.hurtAnim.isDirection(Direction.FORWARDS) && this.outStopWatch.every(600.0)) {
               this.hurtAnim.setDirection(Direction.BACKWARDS);
            }

            if (this.absorptionAnim.isDirection(Direction.FORWARDS) && this.outStopWatch.every(400.0)) {
               this.absorptionAnim.setDirection(Direction.BACKWARDS);
            }
         }
      }

      @Override
      public void drawDraggable(DrawContext var1) {
         if (this.lastTarget != null) {
            MatrixStack var2 = var1.getMatrices();
            float var3 = 0.9F;
            float var4 = this.scaleAnimation.getOutput().floatValue();
            MathUtil.setAlpha(var4, () -> this.drawHead(var1, var2, var3));
         }
      }

      private void drawHead(DrawContext var1, MatrixStack var2, float var3) {
         FontRenderer var4 = Fonts.getSize((int)(19.0F * var3), Fonts.Type.DEFAULT);
         float var5 = PlayerHealthUtil.getHealth(this.lastTarget);
         float var6 = 100.0F * var3;
         String var7 = PlayerHealthUtil.getHealthString(var5);
         this.health = MathHelper.clamp(
            MathUtil.interpolateSmooth(2.0, this.health, (float)Math.round(var5 / this.lastTarget.getMaxHealth() * var6)), 2.5F * var3, var6
         );
         float var8 = this.absorptionAnim.getOutput().floatValue();
         if (var8 > 0.0F) {
            this.hurtProgress = MathHelper.clamp(
               MathUtil.interpolateSmooth(1.0, this.hurtProgress, this.headScale / this.lastTarget.getMaxHealth() * var6), 2.5F * var3, var6
            );
         } else {
            this.headScale = var5;
            this.hurtProgress = this.health;
         }

         float var9 = this.getWidth() * var3;
         float var10 = this.getHeight() * var3;
         float var11 = 3.0F * var3;
         float var12 = 5.0F * var3;
         float var13 = this.getY() + var10 - var11 - var12;
         blur.render(
            ShapeProperties.create(var2, this.getX() - var12, this.getY() - var12, var9 + var12 * 2.0F, var10 + var12 * 2.0F)
               .round(7.0F * var3)
               .quality(5.0F)
               .softness(1.0F)
               .thickness(0.0F)
               .outlineColor(ColorUtil.getColor(120, 40, 180, 255))
               .color(ColorUtil.getColor(12, 4, 18, 240))
               .build()
         );
         String var14 = this.lastTarget.getName().getString();
         var4.drawString(var2, var14, this.getX() + var12, this.getY() + 3.0F * var3, ColorUtil.getTextColor());
         Fonts.getSize((int)(16.0F * var3), Fonts.Type.DEFAULT)
            .drawString(
               var2,
               var7,
               this.getX() + var9 - var12 - Fonts.getSize((int)(16.0F * var3)).getStringWidth(var7),
               this.getY() + 4.0F * var3,
               ColorUtil.getTextColor()
            );
         rectangle.render(
            ShapeProperties.create(var2, this.getX() + var12, var13, var6, var11).round(var11 / 2.0F).color(ColorUtil.getColor(80, 20, 120, 40)).build()
         );
         if (this.hurtProgress > this.health && var8 > 0.0F) {
            int var15 = (int)(var8 * 180.0F);
            rectangle.render(
               ShapeProperties.create(var2, this.getX() + var12, var13, this.hurtProgress, var11)
                  .round(var11 / 2.0F)
                  .color(ColorUtil.getColor(255, 50, 50, var15))
                  .build()
            );
         }

         rectangle.render(
            ShapeProperties.create(var2, this.getX() + var12, var13, this.health, var11)
               .softness(3.0F)
               .round(var11 / 2.0F)
               .color(ColorUtil.getColor(140, 50, 220, 120))
               .build()
         );
         rectangle.render(
            ShapeProperties.create(var2, this.getX() + var12, var13, this.health, var11).round(var11 / 2.0F).color(ColorUtil.getColor(170, 60, 255)).build()
         );
      }
   }

   public static class WatermarkDraggable extends AbstractDraggable {
      private int fpsCount = 0;

      public WatermarkDraggable() {
         super("Watermark", 10, 10, 92, 16, true);
      }

      @Override
      public boolean visible() {
         Hud var1 = Hud.getInstance();
         return var1 == null || !var1.isState() ? false : var1.elementsSetting.isSelected("Watermark");
      }

      @Override
      public void tick() {
         this.fpsCount = (int)MathUtil.interpolate((float)this.fpsCount, (float)mc.getCurrentFps());
      }

      @Override
      public void drawDraggable(DrawContext var1) {
         MatrixStack var2 = var1.getMatrices();
         float var3 = 0.8F;
         FontRenderer var4 = Fonts.getSize((int)(15.0F * var3), Fonts.Type.DEFAULT);
         int var5 = this.fpsCount;
         if (var5 > 9999) {
            var5 = 9999;
         }

         if (var5 < 0) {
            var5 = 0;
         }

         String var6 = mc.getNetworkHandler() != null && mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != null
            ? String.valueOf(mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()).getLatency())
            : "0";
         int var7 = 0;

         try {
            var7 = Integer.parseInt(var6);
         } catch (NumberFormatException var21) {
            var7 = 0;
         }

         if (var7 > 9999) {
            var7 = 9999;
         }

         if (var7 < 0) {
            var7 = 0;
         }

         String var8 = String.valueOf(var5);
         String var9 = String.valueOf(var7);
         String var10 = "\u26a1   Papus";
         float var11 = var4.getStringWidth(var10) * var3;
         float var12 = var4.getStringWidth(var9) * var3;
         float var13 = var4.getStringWidth("ms") * var3;
         float var14 = var4.getStringWidth(var8) * var3;
         float var15 = var4.getStringWidth("fps") * var3;
         float var16 = 10.0F + var11 + 8.0F + var12 + 3.0F + var13 + 8.0F + var14 + 3.0F + var15 + 20.0F;
         short var17 = 250;
         if (var16 > var17) {
            var16 = var17;
         }

         this.setWidth((int)Math.ceil(var16));
         this.setHeight((int)Math.ceil(20.0F * var3));
         rectangle.render(
            ShapeProperties.create(var2, this.getX(), this.getY(), this.getWidth(), this.getHeight())
               .round(6.0F * var3)
               .color(ColorUtil.getColor(12, 4, 18, 240))
               .build()
         );
         float var18 = this.getY() + (int)(7.5F * var3);
         float var19 = this.getX() + 8;
         String var20 = var10;
         if (var4.getStringWidth(var10) * var3 > 80.0F) {
            var20 = "\u26a1";
         }

         var4.drawString(var2, var20, var19, var18, ColorUtil.getColor(255, 255, 255, 255));
         var19 += var4.getStringWidth(var20) * var3 + 6.0F;
         Fonts.getSize((int)(18.0F * var3), Fonts.Type.BOLD)
            .drawString(var2, "\u2022", var19, this.getY() + (int)(4.5F * var3), ColorUtil.getColor(255, 255, 255, 150));
         var19 += 8.0F;
         var4.drawString(var2, var9, var19, var18, ColorUtil.getColor(255, 255, 255, 255));
         var19 += var12 + 3.0F;
         var4.drawString(var2, "ms", var19, var18, ColorUtil.getColor(255, 255, 255, 120));
         var19 += var13 + 6.0F;
         Fonts.getSize((int)(18.0F * var3), Fonts.Type.BOLD)
            .drawString(var2, "\u2022", var19, this.getY() + (int)(4.5F * var3), ColorUtil.getColor(255, 255, 255, 150));
         var19 += 8.0F;
         var4.drawString(var2, var8, var19, var18, ColorUtil.getColor(255, 255, 255, 255));
         var19 += var14 + 3.0F;
         var4.drawString(var2, "fps", var19, var18, ColorUtil.getColor(255, 255, 255, 120));
      }
   }
}
