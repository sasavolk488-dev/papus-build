package project.papus.api.system.shape.implement;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.Defines;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import project.papus.api.system.shape.Shape;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.QuickImports;
import project.papus.common.util.color.ColorUtil;

public class Rectangle implements Shape, QuickImports {
   private final ShaderProgramKey SHADER_KEY = new ShaderProgramKey(Identifier.of("minecraft", "core/round"), VertexFormats.POSITION, Defines.EMPTY);

   @Override
   public void render(ShapeProperties var1) {
      try {
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.enableDepthTest();
         RenderSystem.enableCull();
         float var2 = (float)mc.getWindow().getScaleFactor();
         float var3 = RenderSystem.getShaderColor()[3];
         Matrix4f var4 = var1.getMatrix().peek().getPositionMatrix();
         Vector3f var5 = var4.transformPosition(var1.getX(), var1.getY(), 0.0F, new Vector3f()).mul(var2);
         Vector3f var6 = var4.getScale(new Vector3f()).mul(var2);
         Vector4f var7 = var1.getRound().mul(var6.y);
         float var8 = var1.getSoftness();
         float var9 = var1.getThickness();
         float var10 = var1.getWidth() * var6.x;
         float var11 = var1.getHeight() * var6.y;
         BufferBuilder var12 = QuickImports.tessellator().begin(DrawMode.QUADS, VertexFormats.POSITION);
         drawEngine.quad(var4, var12, var1.getX() - var8 / 2.0F, var1.getY() - var8 / 2.0F, var1.getWidth() + var8, var1.getHeight() + var8);
         ShaderProgram var13 = RenderSystem.setShader(this.SHADER_KEY);
         if (var13 != null) {
            var13.getUniformOrDefault("size").set(var10, var11);
            var13.getUniformOrDefault("location").set(var5.x, window.getHeight() - var11 - var5.y);
            var13.getUniformOrDefault("radius").set(var7);
            var13.getUniformOrDefault("softness").set(var8);
            var13.getUniformOrDefault("thickness").set(var9);
            var13.getUniformOrDefault("color1")
               .set(
                  ColorUtil.redf(var1.getColor().x),
                  ColorUtil.greenf(var1.getColor().x),
                  ColorUtil.bluef(var1.getColor().x),
                  ColorUtil.alphaf(ColorUtil.setAlpha(var1.getColor().x, var3))
               );
            var13.getUniformOrDefault("color2")
               .set(
                  ColorUtil.redf(var1.getColor().y),
                  ColorUtil.greenf(var1.getColor().y),
                  ColorUtil.bluef(var1.getColor().y),
                  ColorUtil.alphaf(ColorUtil.setAlpha(var1.getColor().y, var3))
               );
            var13.getUniformOrDefault("color3")
               .set(
                  ColorUtil.redf(var1.getColor().z),
                  ColorUtil.greenf(var1.getColor().z),
                  ColorUtil.bluef(var1.getColor().z),
                  ColorUtil.alphaf(ColorUtil.setAlpha(var1.getColor().z, var3))
               );
            var13.getUniformOrDefault("color4")
               .set(
                  ColorUtil.redf(var1.getColor().w),
                  ColorUtil.greenf(var1.getColor().w),
                  ColorUtil.bluef(var1.getColor().w),
                  ColorUtil.alphaf(ColorUtil.setAlpha(var1.getColor().w, var3))
               );
            var13.getUniformOrDefault("outlineColor")
               .set(
                  ColorUtil.redf(var1.getOutlineColor()),
                  ColorUtil.greenf(var1.getOutlineColor()),
                  ColorUtil.bluef(var1.getOutlineColor()),
                  ColorUtil.alphaf(ColorUtil.setAlpha(var1.getOutlineColor(), var3))
               );
            BufferRenderer.drawWithGlobalProgram(var12.end());
            return;
         }
      } catch (Exception var17) {
         return;
      } finally {
         RenderSystem.disableBlend();
      }
   }

   public void renderOutline(ShapeProperties var1, float var2) {
      try {
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.enableDepthTest();
         RenderSystem.enableCull();
         float var3 = (float)mc.getWindow().getScaleFactor();
         float var4 = RenderSystem.getShaderColor()[3];
         Matrix4f var5 = var1.getMatrix().peek().getPositionMatrix();
         Vector3f var6 = var5.transformPosition(var1.getX(), var1.getY(), 0.0F, new Vector3f()).mul(var3);
         Vector3f var7 = var5.getScale(new Vector3f()).mul(var3);
         Vector4f var8 = var1.getRound().mul(var7.y);
         float var9 = var1.getSoftness();
         float var10 = var1.getWidth() * var7.x;
         float var11 = var1.getHeight() * var7.y;
         BufferBuilder var12 = QuickImports.tessellator().begin(DrawMode.QUADS, VertexFormats.POSITION);
         drawEngine.quad(var5, var12, var1.getX() - var9 / 2.0F, var1.getY() - var9 / 2.0F, var1.getWidth(), var1.getHeight() + var9);
         ShaderProgram var13 = RenderSystem.setShader(this.SHADER_KEY);
         if (var13 != null) {
            var13.getUniformOrDefault("size").set(var10, var11);
            var13.getUniformOrDefault("location").set(var6.x, window.getHeight() - var11 - var6.y);
            var13.getUniformOrDefault("radius").set(var8);
            var13.getUniformOrDefault("softness").set(var9);
            var13.getUniformOrDefault("thickness").set(var2 * var3);
            var13.getUniformOrDefault("color1").set(0.0F, 0.0F, 0.0F, 0.0F);
            var13.getUniformOrDefault("color2").set(0.0F, 0.0F, 0.0F, 0.0F);
            var13.getUniformOrDefault("color3").set(0.0F, 0.0F, 0.0F, 0.0F);
            var13.getUniformOrDefault("color4").set(0.0F, 0.0F, 0.0F, 0.0F);
            var13.getUniformOrDefault("outlineColor")
               .set(
                  ColorUtil.redf(var1.getOutlineColor()),
                  ColorUtil.greenf(var1.getOutlineColor()),
                  ColorUtil.bluef(var1.getOutlineColor()),
                  ColorUtil.alphaf(ColorUtil.setAlpha(var1.getOutlineColor(), var4))
               );
            BufferRenderer.drawWithGlobalProgram(var12.end());
            return;
         }
      } catch (Exception var17) {
         return;
      } finally {
         RenderSystem.disableBlend();
      }
   }
}
