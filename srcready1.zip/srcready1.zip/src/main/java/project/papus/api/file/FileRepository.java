package project.papus.api.file;

import java.util.ArrayList;
import java.util.List;
import project.papus.api.file.impl.FriendFile;
import project.papus.api.file.impl.ModuleFile;
import project.papus.core.Main;

public class FileRepository {
   private final List<ClientFile> clientFiles = new ArrayList<>();

   public void setup(Main var1) {
      this.register(new ModuleFile(var1.getModuleRepository(), var1.getDraggableRepository()), new FriendFile());
   }

   public void register(ClientFile... var1) {
      this.clientFiles.addAll(List.of(var1));
   }

   public List<ClientFile> getClientFiles() {
      return this.clientFiles;
   }
}
