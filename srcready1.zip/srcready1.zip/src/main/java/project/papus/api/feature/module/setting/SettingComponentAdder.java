package project.papus.api.feature.module.setting;

import java.util.List;
import project.papus.api.feature.module.setting.implement.BindSetting;
import project.papus.api.feature.module.setting.implement.BooleanSetting;
import project.papus.api.feature.module.setting.implement.ButtonSetting;
import project.papus.api.feature.module.setting.implement.ColorSetting;
import project.papus.api.feature.module.setting.implement.GroupSetting;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.api.feature.module.setting.implement.TextSetting;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.implement.screens.menu.components.implement.settings.AbstractSettingComponent;
import project.papus.implement.screens.menu.components.implement.settings.BindComponent;
import project.papus.implement.screens.menu.components.implement.settings.CheckboxComponent;
import project.papus.implement.screens.menu.components.implement.settings.ColorComponent;
import project.papus.implement.screens.menu.components.implement.settings.GroupComponent;
import project.papus.implement.screens.menu.components.implement.settings.SButtonComponent;
import project.papus.implement.screens.menu.components.implement.settings.TextComponent;
import project.papus.implement.screens.menu.components.implement.settings.ValueComponent;
import project.papus.implement.screens.menu.components.implement.settings.multiselect.MultiSelectButton;
import project.papus.implement.screens.menu.components.implement.settings.select.SelectButton;

public class SettingComponentAdder {
   public void addSettingComponent(List<Setting> var1, List<AbstractSettingComponent> var2) {
      var1.forEach(var1x -> {
         if (var1x instanceof BooleanSetting var2x) {
            var2.add(new CheckboxComponent(var2x));
         }

         if (var1x instanceof BindSetting var3) {
            var2.add(new BindComponent(var3));
         }

         if (var1x instanceof ColorSetting var4) {
            var2.add(new ColorComponent(var4));
         }

         if (var1x instanceof TextSetting var5) {
            var2.add(new TextComponent(var5));
         }

         if (var1x instanceof ValueSetting var6) {
            var2.add(new ValueComponent(var6));
         }

         if (var1x instanceof GroupSetting var7) {
            var2.add(new GroupComponent(var7));
         }

         if (var1x instanceof ButtonSetting var8) {
            var2.add(new SButtonComponent(var8));
         }

         if (var1x instanceof SelectSetting var9) {
            var2.add(new SelectButton(var9));
         }

         if (var1x instanceof MultiSelectSetting var10) {
            var2.add(new MultiSelectButton(var10));
         }
      });
   }
}
