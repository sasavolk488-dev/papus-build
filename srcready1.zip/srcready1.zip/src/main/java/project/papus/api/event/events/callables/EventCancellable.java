package project.papus.api.event.events.callables;

import project.papus.api.event.events.Cancellable;
import project.papus.api.event.events.Event;

public abstract class EventCancellable implements Cancellable, Event {
   private boolean cancelled;

   protected EventCancellable() {
   }

   @Override
   public boolean isCancelled() {
      return this.cancelled;
   }

   @Override
   public void cancel() {
      this.cancelled = true;
   }

   public void setCancelled(boolean var1) {
      this.cancelled = var1;
   }
}
