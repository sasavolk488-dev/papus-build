package project.papus.api.feature.module.setting.implement;

import java.util.function.Supplier;
import net.minecraft.util.math.MathHelper;
import project.papus.api.feature.module.setting.Setting;

public class ValueSetting extends Setting {
   private float value;
   private float min;
   private float max;
   private boolean integer;

   public ValueSetting(String var1, String var2) {
      super(var1, var2);
   }

   public ValueSetting range(float var1, float var2) {
      this.min = var1;
      this.max = var2;
      return this;
   }

   public ValueSetting range(int var1, int var2) {
      this.min = var1;
      this.max = var2;
      this.integer = true;
      return this;
   }

   public float getValue() {
      return MathHelper.clamp(this.value, this.min, this.max);
   }

   public ValueSetting setValue(float var1) {
      this.value = MathHelper.clamp(var1, this.min, this.max);
      return this;
   }

   public int getInt() {
      return (int)this.getValue();
   }

   public ValueSetting visible(Supplier<Boolean> var1) {
      this.setVisible(var1);
      return this;
   }

   public float getMin() {
      return this.min;
   }

   public float getMax() {
      return this.max;
   }

   public boolean isInteger() {
      return this.integer;
   }

   public ValueSetting setMin(float var1) {
      this.min = var1;
      return this;
   }

   public ValueSetting setMax(float var1) {
      this.max = var1;
      return this;
   }

   public ValueSetting setInteger(boolean var1) {
      this.integer = var1;
      return this;
   }
}
