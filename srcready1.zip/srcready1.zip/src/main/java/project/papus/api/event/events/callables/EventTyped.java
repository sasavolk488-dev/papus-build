package project.papus.api.event.events.callables;

import project.papus.api.event.events.Event;
import project.papus.api.event.events.Typed;

public abstract class EventTyped implements Event, Typed {
   private final byte type;

   protected EventTyped(byte var1) {
      this.type = var1;
   }

   @Override
   public byte getType() {
      return this.type;
   }
}
