package project.papus.api.file;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import project.papus.common.util.logger.LoggerUtil;

public class DirectoryCreator {
   public void createDirectories(File... var1) {
      ArrayList var2 = new ArrayList();
      Arrays.stream(var1).filter(var0 -> !var0.exists()).forEach(var1x -> {
         if (var1x.mkdirs()) {
            var2.add(var1x.getName());
         }
      });
      LoggerUtil.info("Number of directories created: " + var2.size());
      if (!var2.isEmpty()) {
         LoggerUtil.info("Directories created:");
         var2.forEach(LoggerUtil::info);
      }
   }
}
