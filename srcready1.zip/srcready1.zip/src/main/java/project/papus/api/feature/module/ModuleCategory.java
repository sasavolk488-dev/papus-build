package project.papus.api.feature.module;

public enum ModuleCategory {
   RENDER("Render"),
   PLAYER("Player"),
   MISC("Misc"),
   FRIEND("Friends");

   final String readableName;

   private ModuleCategory(String var3) {
      this.readableName = var3;
   }

   public String getReadableName() {
      return this.readableName;
   }
}
