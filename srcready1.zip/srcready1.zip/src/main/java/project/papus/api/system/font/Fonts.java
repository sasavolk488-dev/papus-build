package project.papus.api.system.font;

import java.awt.Font;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import project.papus.core.Main;

public class Fonts {
   private static final Map<Fonts.FontKey, FontRenderer> fontCache = new HashMap<>();

   public static FontRenderer create(float var0, String var1) {
      try {
         String var2 = "assets/minecraft/fonts/" + var1 + ".otf";

         FontRenderer var3;
         try (InputStream var4 = Main.class.getClassLoader().getResourceAsStream(var2)) {
            Font var5 = Font.createFont(0, Objects.requireNonNull(var4)).deriveFont(0, var0 / 2.0F);
            var3 = new FontRenderer(var5, var0 / 2.0F);
         }

         return var3;
      } catch (Exception var9) {
         throw new RuntimeException(var9);
      }
   }

   public static void init() {
      for (Fonts.Type var3 : Fonts.Type.values()) {
         for (int var4 = 4; var4 <= 32; var4++) {
            fontCache.put(new Fonts.FontKey(var4, var3), create(var4, var3.getType()));
         }
      }
   }

   public static FontRenderer getSize(int var0) {
      return getSize(var0, Fonts.Type.BOLD);
   }

   public static FontRenderer getSize(int var0, Fonts.Type var1) {
      return fontCache.computeIfAbsent(new Fonts.FontKey(var0, var1), var2 -> create(var0, var1.getType()));
   }

   record FontKey(int size, Fonts.Type type) {
   }

   public static enum Type {
      DEFAULT("sfpromedium"),
      BOLD("sfprosemibold"),
      HUD("icon"),
      GUI("apexgui");

      private final String type;

      public String getType() {
         return this.type;
      }

      private Type(String var3) {
         this.type = var3;
      }
   }
}
