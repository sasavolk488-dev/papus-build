package project.papus.api.event.events;

public interface Event {
}
