package project.papus.api.feature.module;

import java.util.List;
import net.minecraft.util.Formatting;
import project.papus.api.event.EventHandler;
import project.papus.api.event.EventManager;
import project.papus.api.feature.module.exception.ModuleException;
import project.papus.api.system.logger.implement.ConsoleLogger;
import project.papus.common.QuickImports;
import project.papus.common.QuickLogger;
import project.papus.implement.events.keyboard.KeyEvent;

public class ModuleSwitcher implements QuickImports, QuickLogger {
   private final List<Module> modules;

   public ModuleSwitcher(List<Module> var1, EventManager var2) {
      this.modules = var1;
      var2.register(this);
   }

   @EventHandler
   public void onKey(KeyEvent var1) {
      if (mc.currentScreen == null) {
         for (Module var3 : this.modules) {
            try {
               if (var1.key() == var3.getKey()) {
                  this.handleModuleState(var3, var1.action());
               }
            } catch (Exception var5) {
               this.handleException(var3.getName(), var5);
            }
         }
      }
   }

   private void handleModuleState(Module var1, int var2) {
      if (var1.getType() == 1 && var2 == 1) {
         var1.switchState();
      }
   }

   private void handleException(String var1, Exception var2) {
      ConsoleLogger var3 = new ConsoleLogger();
      if (var2 instanceof ModuleException) {
         this.logDirect("[" + var1 + "] " + Formatting.RED + var2.getMessage());
      } else {
         var3.log("Error in module " + var1 + ": " + var2.getMessage());
      }
   }
}
