package project.papus.api.file.exception;

public class FileSaveException extends FileProcessingException {
   public FileSaveException(String var1) {
      super(var1);
   }

   public FileSaveException(String var1, Throwable var2) {
      super(var1, var2);
   }
}
