package project.papus.api.feature.module.setting.implement;

import java.awt.Color;
import java.util.function.Supplier;
import project.papus.api.feature.module.setting.Setting;
import project.papus.common.util.math.MathUtil;

public class ColorSetting extends Setting {
   private float hue = 0.0F;
   private float saturation = 1.0F;
   private float brightness = 1.0F;
   private float alpha = 1.0F;
   private int[] presets;

   public ColorSetting(String var1, String var2) {
      super(var1, var2);
   }

   public ColorSetting color(int var1) {
      this.setColor(var1);
      return this;
   }

   public ColorSetting presets(int... var1) {
      this.presets = var1;
      return this;
   }

   public ColorSetting visible(Supplier<Boolean> var1) {
      this.setVisible(var1);
      return this;
   }

   public int getColor() {
      return this.getColorWithAlpha() & 16777215 | Math.round(this.alpha * 255.0F) << 24;
   }

   public int getColorWithAlpha() {
      return Color.HSBtoRGB(this.hue, this.saturation, this.brightness);
   }

   public ColorSetting setColor(int var1) {
      float[] var2 = Color.RGBtoHSB(MathUtil.getRed(var1), MathUtil.getGreen(var1), MathUtil.getBlue(var1), null);
      this.hue = var2[0];
      this.saturation = var2[1];
      this.brightness = var2[2];
      this.alpha = MathUtil.getAlpha(var1) / 255.0F;
      return this;
   }

   public float getHue() {
      return this.hue;
   }

   public float getSaturation() {
      return this.saturation;
   }

   public float getBrightness() {
      return this.brightness;
   }

   public float getAlpha() {
      return this.alpha;
   }

   public int[] getPresets() {
      return this.presets;
   }

   public void setHue(float var1) {
      this.hue = var1;
   }

   public void setSaturation(float var1) {
      this.saturation = var1;
   }

   public void setBrightness(float var1) {
      this.brightness = var1;
   }

   public void setAlpha(float var1) {
      this.alpha = var1;
   }

   public void setPresets(int[] var1) {
      this.presets = var1;
   }
}
