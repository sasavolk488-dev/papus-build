package project.papus.api.system.animation;

public enum Direction {
   FORWARDS,
   BACKWARDS;
}
