package project.papus.api.system.shape.implement;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.Defines;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import project.papus.api.system.shape.Shape;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.QuickImports;
import project.papus.common.util.color.ColorUtil;

public class Arc implements Shape, QuickImports {
   private final ShaderProgramKey SHADER_KEY = new ShaderProgramKey(Identifier.of("minecraft", "core/arc"), VertexFormats.POSITION, Defines.EMPTY);

   @Override
   public void render(ShapeProperties var1) {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableDepthTest();
      RenderSystem.enableCull();
      float var2 = (float)mc.getWindow().getScaleFactor();
      float var3 = RenderSystem.getShaderColor()[3];
      Matrix4f var4 = var1.getMatrix().peek().getPositionMatrix();
      Vector3f var5 = var4.transformPosition(var1.getX(), var1.getY(), 0.0F, new Vector3f()).mul(var2);
      Vector3f var6 = var4.getScale(new Vector3f()).mul(var2);
      Vector4f var7 = var1.getRound().mul(var6.y);
      float var8 = var1.getWidth() * var6.x;
      float var9 = var1.getHeight() * var6.y;
      BufferBuilder var10 = QuickImports.tessellator().begin(DrawMode.QUADS, VertexFormats.POSITION);
      drawEngine.quad(var4, var10, var1.getX(), var1.getY(), var1.getWidth(), var1.getHeight());
      ShaderProgram var11 = RenderSystem.setShader(this.SHADER_KEY);
      var11.getUniformOrDefault("size").set(var8, var9);
      var11.getUniformOrDefault("location").set(var5.x, window.getHeight() - var9 - var5.y);
      var11.getUniformOrDefault("radius").set(var7.x);
      var11.getUniformOrDefault("thickness").set(var1.getThickness());
      var11.getUniformOrDefault("start").set(var1.getStart());
      var11.getUniformOrDefault("end").set(var1.getEnd());
      var11.getUniformOrDefault("color1")
         .set(
            ColorUtil.redf(var1.getColor().x),
            ColorUtil.greenf(var1.getColor().x),
            ColorUtil.bluef(var1.getColor().x),
            ColorUtil.alphaf(ColorUtil.setAlpha(var1.getColor().x, var3))
         );
      var11.getUniformOrDefault("color2")
         .set(
            ColorUtil.redf(var1.getColor().y),
            ColorUtil.greenf(var1.getColor().y),
            ColorUtil.bluef(var1.getColor().y),
            ColorUtil.alphaf(ColorUtil.setAlpha(var1.getColor().y, var3))
         );
      BufferRenderer.drawWithGlobalProgram(var10.end());
      RenderSystem.disableBlend();
   }
}
