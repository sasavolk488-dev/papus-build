package project.papus.api.file.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import project.papus.api.feature.draggable.AbstractDraggable;
import project.papus.api.feature.draggable.DraggableRepository;
import project.papus.api.feature.module.Module;
import project.papus.api.feature.module.ModuleRepository;
import project.papus.api.feature.module.setting.Setting;
import project.papus.api.feature.module.setting.implement.BindSetting;
import project.papus.api.feature.module.setting.implement.BooleanSetting;
import project.papus.api.feature.module.setting.implement.ColorSetting;
import project.papus.api.feature.module.setting.implement.GroupSetting;
import project.papus.api.feature.module.setting.implement.MultiSelectSetting;
import project.papus.api.feature.module.setting.implement.SelectSetting;
import project.papus.api.feature.module.setting.implement.TextSetting;
import project.papus.api.feature.module.setting.implement.ValueSetting;
import project.papus.api.file.ClientFile;
import project.papus.api.file.exception.FileLoadException;
import project.papus.api.file.exception.FileSaveException;

public class ModuleFile extends ClientFile {
   private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
   private final ModuleRepository moduleRepository;
   private final DraggableRepository draggableRepository;

   public ModuleFile(ModuleRepository var1, DraggableRepository var2) {
      super("autoCfg");
      this.moduleRepository = var1;
      this.draggableRepository = var2;
   }

   @Override
   public void saveToFile(File var1) {
      this.saveToFile(var1, this.getName() + ".json");
   }

   @Override
   public void loadFromFile(File var1) {
      this.loadFromFile(var1, this.getName() + ".json");
   }

   @Override
   public void saveToFile(File var1, String var2) {
      JsonObject var3 = this.createJsonObjectFromModules();
      File var4 = new File(var1, var2);
      this.writeJsonToFile(var3, var4);
      super.saveToFile(var1, var2);
   }

   @Override
   public void loadFromFile(File var1, String var2) {
      File var3 = new File(var1, var2);
      JsonObject var4 = this.readJsonFromFile(var3);
      if (var4 != null) {
         this.updateModulesFromJsonObject(var4);
      }

      super.loadFromFile(var1, var2);
   }

   private JsonObject createJsonObjectFromModules() {
      JsonObject var1 = new JsonObject();

      for (Module var3 : this.moduleRepository.modules()) {
         JsonObject var4 = new JsonObject();
         var4.addProperty("bind", var3.getKey());
         var4.addProperty("state", var3.isState());
         var3.settings().forEach(var2 -> this.addSettingToJsonObject(var4, var2));
         var1.add(var3.getName().toLowerCase(), var4);
      }

      for (AbstractDraggable var6 : this.draggableRepository.draggable()) {
         JsonObject var7 = new JsonObject();
         var7.addProperty("posX", var6.getX());
         var7.addProperty("posY", var6.getY());
         var1.add(var6.getName().toLowerCase(), var7);
      }

      return var1;
   }

   private void addSettingToJsonObject(JsonObject var1, Setting var2) {
      if (var2 instanceof BooleanSetting var3) {
         var1.addProperty(var2.getName(), var3.isValue());
      }

      if (var2 instanceof ValueSetting var7) {
         var1.addProperty(var2.getName(), var7.getValue());
      }

      if (var2 instanceof ColorSetting var8) {
         var1.addProperty(var2.getName(), var8.getColor());
      }

      if (var2 instanceof BindSetting var9) {
         var1.addProperty(var2.getName(), var9.getKey());
      }

      if (var2 instanceof TextSetting var10) {
         var1.addProperty(var2.getName(), var10.getText());
      }

      if (var2 instanceof SelectSetting var11) {
         var1.addProperty(var2.getName(), var11.getSelected());
      }

      if (var2 instanceof MultiSelectSetting var12) {
         List var4 = var12.getSelected();
         String var5 = String.join(",", var4);
         var1.addProperty(var2.getName(), var5);
      }

      if (var2 instanceof GroupSetting var13) {
         JsonObject var14 = new JsonObject();
         var14.addProperty("state", var13.isValue());

         for (Setting var6 : var13.getSubSettings()) {
            this.addSettingToJsonObject(var14, var6);
         }

         var1.add(var2.getName(), var14);
      }
   }

   private void writeJsonToFile(JsonObject var1, File var2) {
      try {
         try (FileWriter var3 = new FileWriter(var2)) {
            this.gson.toJson(var1, var3);
         }
      } catch (IOException var8) {
         throw new FileSaveException("Failed to save module to file", var8);
      }
   }

   private JsonObject readJsonFromFile(File var1) {
      try {
         JsonObject var2;
         try (FileReader var3 = new FileReader(var1)) {
            var2 = JsonParser.parseReader(var3).getAsJsonObject();
         }

         return var2;
      } catch (IOException var8) {
         throw new FileLoadException("Failed to load module from file", var8);
      } catch (JsonSyntaxException | JsonIOException var9) {
         throw new FileLoadException("Failed to parse JSON from file", var9);
      }
   }

   private void updateModulesFromJsonObject(JsonObject var1) {
      for (Module var3 : this.moduleRepository.modules()) {
         JsonObject var4 = var1.getAsJsonObject(var3.getName().toLowerCase());
         if (var4 != null) {
            if (var4.has("bind") && var4.has("state")) {
               var3.setKey(var4.get("bind").getAsInt());
               var3.setStateQuietly(var4.get("state").getAsBoolean());
            }

            var3.settings().forEach(var2 -> this.updateSettingFromJsonObject(var4, var2));
         }
      }

      for (AbstractDraggable var6 : this.draggableRepository.draggable()) {
         JsonObject var7 = var1.getAsJsonObject(var6.getName().toLowerCase());
         if (var7 != null && var7.has("posX") && var7.has("posY")) {
            var6.setX(var7.get("posX").getAsInt());
            var6.setY(var7.get("posY").getAsInt());
         }
      }
   }

   private void updateSettingFromJsonObject(JsonObject var1, Setting var2) {
      JsonElement var3 = var1.get(var2.getName());
      if (var3 != null && !var3.isJsonNull()) {
         if (var2 instanceof BooleanSetting var4) {
            var4.setValue(var3.getAsBoolean());
         }

         if (var2 instanceof ValueSetting var8) {
            var8.setValue(var3.getAsFloat());
         }

         if (var2 instanceof ColorSetting var9) {
            var9.setColor(var3.getAsInt());
         }

         if (var2 instanceof BindSetting var10) {
            var10.setKey(var3.getAsInt());
         }

         if (var2 instanceof TextSetting var11) {
            var11.setText(var3.getAsString());
         }

         if (var2 instanceof SelectSetting var12) {
            var12.setSelected(var3.getAsString());
         }

         if (var2 instanceof MultiSelectSetting var13) {
            String var5 = var3.getAsString();
            ArrayList var6 = new ArrayList<>(Arrays.asList(var5.split(",")));
            var6.removeIf(var1x -> !var13.getList().contains(var1x));
            var13.setSelected(var6);
         }

         if (var2 instanceof GroupSetting var14) {
            JsonObject var15 = var3.getAsJsonObject();
            if (var15.has("state")) {
               var14.setValue(var15.get("state").getAsBoolean());
            }

            for (Setting var7 : var14.getSubSettings()) {
               this.updateSettingFromJsonObject(var15, var7);
            }
         }
      }
   }
}
