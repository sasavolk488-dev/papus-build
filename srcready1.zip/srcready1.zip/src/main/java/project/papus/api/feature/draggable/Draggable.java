package project.papus.api.feature.draggable;

import net.minecraft.client.gui.DrawContext;
import project.papus.implement.events.container.SetScreenEvent;
import project.papus.implement.events.packet.PacketEvent;

public interface Draggable {
   boolean visible();

   void tick();

   void render(DrawContext var1, int var2, int var3, float var4);

   void onPacket(PacketEvent var1);

   void onSetScreen(SetScreenEvent var1);

   boolean mouseClicked(double var1, double var3, int var5);

   boolean mouseReleased(double var1, double var3, int var5);
}
