package project.papus.api.event;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import project.papus.api.event.events.Event;
import project.papus.api.event.events.EventCancelable;
import project.papus.api.event.types.Priority;
import project.papus.api.feature.module.exception.ModuleException;
import project.papus.api.system.logger.implement.ConsoleLogger;
import project.papus.api.system.logger.implement.MinecraftLogger;

public final class EventManager {
   private static final Map<Class<? extends Event>, List<EventManager.MethodData>> REGISTRY_MAP = new HashMap<>();

   public void register(Object var1) {
      for (Method var5 : var1.getClass().getDeclaredMethods()) {
         if (!isMethodBad(var5)) {
            this.register(var5, var1);
         }
      }
   }

   public void register(Object var1, Class<? extends Event> var2) {
      for (Method var6 : var1.getClass().getDeclaredMethods()) {
         if (!isMethodBad(var6, var2)) {
            this.register(var6, var1);
         }
      }
   }

   public void unregister(Object var1) {
      for (List<EventManager.MethodData> var3 : REGISTRY_MAP.values()) {
         for (EventManager.MethodData var5 : var3) {
            if (var5.source().equals(var1)) {
               var3.remove(var5);
            }
         }
      }

      cleanMap(true);
   }

   public void unregister(Object var1, Class<? extends Event> var2) {
      if (REGISTRY_MAP.containsKey(var2)) {
         for (EventManager.MethodData var4 : REGISTRY_MAP.get(var2)) {
            if (var4.source().equals(var1)) {
               REGISTRY_MAP.get(var2).remove(var4);
            }
         }

         cleanMap(true);
      }
   }

   private void register(Method var1, Object var2) {
      Class var3 = var1.getParameterTypes()[0];
      final EventManager.MethodData var4 = new EventManager.MethodData(var2, var1, var1.getAnnotation(EventHandler.class).value());
      if (!var4.target().isAccessible()) {
         var4.target().setAccessible(true);
      }

      if (REGISTRY_MAP.containsKey(var3)) {
         if (!REGISTRY_MAP.get(var3).contains(var4)) {
            REGISTRY_MAP.get(var3).add(var4);
            sortListValue(var3);
         }
      } else {
         REGISTRY_MAP.put(var3, new CopyOnWriteArrayList<EventManager.MethodData>() {
            private static final long serialVersionUID = 666L;

            {
               this.add(var4);
            }
         });
      }
   }

   public void removeEntry(Class<? extends Event> var1) {
      Iterator var2 = REGISTRY_MAP.entrySet().iterator();

      while (var2.hasNext()) {
         if (((Class)((Entry)var2.next()).getKey()).equals(var1)) {
            var2.remove();
            break;
         }
      }
   }

   public static void cleanMap(boolean var0) {
      Iterator var1 = REGISTRY_MAP.entrySet().iterator();

      while (var1.hasNext()) {
         if (!var0 || ((List)((Entry)var1.next()).getValue()).isEmpty()) {
            var1.remove();
         }
      }
   }

   private static void sortListValue(Class<? extends Event> var0) {
      CopyOnWriteArrayList<EventManager.MethodData> var1 = new CopyOnWriteArrayList<>();

      for (byte var5 : Priority.VALUE_ARRAY) {
         for (EventManager.MethodData var7 : REGISTRY_MAP.get(var0)) {
            if (var7.priority() == var5) {
               var1.add(var7);
            }
         }
      }

      REGISTRY_MAP.put(var0, var1);
   }

   private static boolean isMethodBad(Method var0) {
      return var0.getParameterTypes().length != 1 || !var0.isAnnotationPresent(EventHandler.class);
   }

   private static boolean isMethodBad(Method var0, Class<? extends Event> var1) {
      return isMethodBad(var0) || !var0.getParameterTypes()[0].equals(var1);
   }

   public static Event callEvent(Event var0) {
      List<EventManager.MethodData> var1 = REGISTRY_MAP.get(var0.getClass());
      if (var1 != null) {
         if (var0 instanceof EventCancelable var2) {
            for (EventManager.MethodData var4 : var1) {
               invoke(var4, var0);
               if (var2.isCancelled()) {
                  break;
               }
            }
         } else {
            for (EventManager.MethodData var8 : var1) {
               try {
                  invoke(var8, var0);
               } catch (Exception var6) {
                  var6.printStackTrace();
               }
            }
         }
      }

      return var0;
   }

   private static void invoke(EventManager.MethodData var0, Event var1) {
      try {
         var0.target().invoke(var0.source(), var1);
      } catch (IllegalAccessException var8) {
         ConsoleLogger var12 = new ConsoleLogger();
         String var17 = "Illegal access to method. ";
         var17 = var17 + "Method: " + var0.target().getName() + ", ";
         var17 = var17 + "Argument: " + var1.toString() + ", ";
         var17 = var17 + "Log: " + var8.fillInStackTrace();
         var12.log(var17);
      } catch (IllegalArgumentException var9) {
         ConsoleLogger var11 = new ConsoleLogger();
         String var13 = "Illegal arguments passed to method. ";
         var13 = var13 + "Method: " + var0.target().getName() + ", ";
         var13 = var13 + "Argument: " + var1.toString() + ", ";
         var13 = var13 + "Log: " + var9.getCause();
         var11.log(var13);
      } catch (InvocationTargetException var10) {
         Throwable var3 = var10.getCause();
         ConsoleLogger var4 = new ConsoleLogger();
         MinecraftLogger var5 = new MinecraftLogger();
         if (var3 instanceof ModuleException var6) {
            var5.minecraftLog(Text.literal("[" + var6.getModuleName() + "] " + Formatting.RED + var6.getMessage()));
         } else {
            String var7 = "Exception occurred within invoked method. ";
            var7 = var7 + "Method: " + var0.target().getName() + ", ";
            var7 = var7 + "Argument: " + var1.toString() + ", ";
            var7 = var7 + "Log: " + var10.getCause();
            var4.log(var7);
         }
      }
   }

   record MethodData(Object source, Method target, byte priority) {
   }
}
