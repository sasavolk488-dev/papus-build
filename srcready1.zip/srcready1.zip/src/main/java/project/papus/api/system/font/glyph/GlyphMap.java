package project.papus.api.system.font.glyph;

import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.chars.Char2ObjectArrayMap;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.NativeImage.Format;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.ColorHelper;
import org.lwjgl.system.MemoryUtil;

public class GlyphMap {
   private final Char2ObjectArrayMap<Glyph> glyphs = new Char2ObjectArrayMap();
   private final char fromIncl;
   private final char toExcl;
   private final Font font;
   public final Identifier bindToTexture;
   private final int pixelPadding;
   public int width;
   public int height;
   private boolean generated = false;

   public GlyphMap(char var1, char var2, Font var3, Identifier var4, int var5) {
      this.fromIncl = var1;
      this.toExcl = var2;
      this.font = var3;
      this.bindToTexture = var4;
      this.pixelPadding = var5;
   }

   public Glyph getGlyph(char var1) {
      if (!this.generated) {
         this.generate();
      }

      return (Glyph)this.glyphs.get(var1);
   }

   public boolean contains(char var1) {
      return var1 >= this.fromIncl && var1 < this.toExcl;
   }

   private Font getFontForGlyph(char var1) {
      return this.font.canDisplay(var1)
         ? this.font
         : Arrays.stream(GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts())
            .filter(var1x -> var1x.canDisplay(var1))
            .map(var1x -> new Font(var1x.getFontName(), 1, this.font.getSize()))
            .findFirst()
            .orElse(new Font("SansSerif", 1, 0));
   }

   public void generate() {
      if (!this.generated) {
         int var1 = this.toExcl - this.fromIncl - 1;
         int var2 = (int)(Math.ceil(Math.sqrt(var1)) * 1.5);
         this.glyphs.clear();
         int var3 = 0;
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         int var7 = 0;
         int var8 = 0;
         int var9 = 0;
         ArrayList<Glyph> var10 = new ArrayList<>();
         AffineTransform var11 = new AffineTransform();

         for (FontRenderContext var12 = new FontRenderContext(var11, true, false); var3 <= var1; var4++) {
            char var13 = (char)(this.fromIncl + var3);
            Font var14 = this.getFontForGlyph(var13);
            Rectangle2D var15 = var14.getStringBounds(String.valueOf(var13), var12);
            int var16 = (int)Math.ceil(var15.getWidth());
            int var17 = (int)Math.ceil(var15.getHeight());
            var3++;
            var5 = Math.max(var5, var7 + var16);
            var6 = Math.max(var6, var8 + var17);
            if (var4 >= var2) {
               var7 = 0;
               var8 += var9 + this.pixelPadding;
               var4 = 0;
               var9 = 0;
            }

            var9 = Math.max(var9, var17);
            var10.add(new Glyph(var7, var8, var16, var17, var13, this));
            var7 += var16 + this.pixelPadding;
         }

         BufferedImage var18 = new BufferedImage(Math.max(var5 + this.pixelPadding, 1), Math.max(var6 + this.pixelPadding, 1), 2);
         this.width = var18.getWidth();
         this.height = var18.getHeight();
         Graphics2D var19 = var18.createGraphics();
         var19.setColor(new Color(255, 255, 255, 0));
         var19.fillRect(0, 0, this.width, this.height);
         var19.setColor(Color.WHITE);
         var19.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
         var19.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
         var19.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

         for (Glyph var21 : var10) {
            var19.setFont(this.getFontForGlyph(var21.value()));
            FontMetrics var22 = var19.getFontMetrics();
            var19.drawString(String.valueOf(var21.value()), var21.u(), var21.v() + var22.getAscent());
            this.glyphs.put(var21.value(), var21);
         }

         registerBufferedImageTexture(this.bindToTexture, var18);
         this.generated = true;
      }
   }

   public static void registerBufferedImageTexture(Identifier var0, BufferedImage var1) {
      try {
         int var2 = var1.getWidth();
         int var3 = var1.getHeight();
         NativeImage var4 = new NativeImage(Format.RGBA, var2, var3, false);
         IntBuffer var5 = MemoryUtil.memIntBuffer(var4.pointer, var4.getWidth() * var4.getHeight());
         WritableRaster var6 = var1.getRaster();
         ColorModel var7 = var1.getColorModel();
         Object var8 = getRasterData(var6);

         for (int var9 = 0; var9 < var3; var9++) {
            for (int var10 = 0; var10 < var2; var10++) {
               var6.getDataElements(var10, var9, var8);
               int var11 = var7.getAlpha(var8);
               int var12 = var7.getRed(var8);
               int var13 = var7.getGreen(var8);
               int var14 = var7.getBlue(var8);
               var5.put(ColorHelper.getArgb(var11, var14, var13, var12));
            }
         }

         NativeImageBackedTexture var16 = new NativeImageBackedTexture(var4);
         var16.upload();
         if (RenderSystem.isOnRenderThread()) {
            MinecraftClient.getInstance().getTextureManager().registerTexture(var0, var16);
         } else {
            RenderSystem.recordRenderCall(() -> MinecraftClient.getInstance().getTextureManager().registerTexture(var0, var16));
         }
      } catch (Throwable var15) {
         throw var15;
      }
   }

   private static Object getRasterData(WritableRaster var0) {
      return switch (var0.getDataBuffer().getDataType()) {
         case 0 -> new byte[var0.getNumDataElements()];
         case 1 -> new short[var0.getNumDataElements()];
         default -> throw new IllegalArgumentException("Unsupported data buffer type: " + var0.getDataBuffer().getDataType());
         case 3 -> new int[var0.getNumDataElements()];
         case 4 -> new float[var0.getNumDataElements()];
         case 5 -> new double[var0.getNumDataElements()];
      };
   }
}
