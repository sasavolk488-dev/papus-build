package project.papus.api.file.exception;

public class FileProcessingException extends RuntimeException {
   public FileProcessingException(String var1) {
      super(var1);
   }

   public FileProcessingException(String var1, Throwable var2) {
      super(var1, var2);
   }
}
