package project.papus.api.event.events;

public interface Cancellable {
   boolean isCancelled();

   void cancel();
}
