package project.papus.api.system.shape.implement;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.Defines;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import project.papus.api.system.shape.Shape;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.QuickImports;
import project.papus.common.util.color.ColorUtil;

public class Blur implements Shape, QuickImports {
   private final ShaderProgramKey SHADER_KEY = new ShaderProgramKey(Identifier.of("minecraft", "core/blur"), VertexFormats.POSITION, Defines.EMPTY);
   public Framebuffer input;
   public Vector2f resolution = new Vector2f();

   @Override
   public void render(ShapeProperties var1) {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.enableDepthTest();
      RenderSystem.enableCull();
      float var2 = (float)mc.getWindow().getScaleFactor();
      float var3 = RenderSystem.getShaderColor()[3];
      Matrix4f var4 = var1.getMatrix().peek().getPositionMatrix();
      Vector3f var5 = var4.transformPosition(var1.getX(), var1.getY(), 0.0F, new Vector3f()).mul(var2);
      Vector3f var6 = var4.getScale(new Vector3f()).mul(var2);
      Vector4f var7 = var1.getRound().mul(var6.y);
      float var8 = var1.getQuality();
      float var9 = var1.getSoftness();
      float var10 = var1.getThickness();
      float var11 = var1.getWidth() * var6.x;
      float var12 = var1.getHeight() * var6.y;
      BufferBuilder var13 = QuickImports.tessellator().begin(DrawMode.QUADS, VertexFormats.POSITION);
      drawEngine.quad(var4, var13, var1.getX() - var9 / 2.0F, var1.getY() - var9 / 2.0F, var1.getWidth() + var9, var1.getHeight() + var9);
      GlStateManager._activeTexture(33984);
      if (this.input != null) {
         RenderSystem.bindTexture(this.input.getColorAttachment());
      }

      ShaderProgram var14 = RenderSystem.setShader(this.SHADER_KEY);
      var14.getUniformOrDefault("size").set(var11, var12);
      var14.getUniformOrDefault("location").set(var5.x, window.getHeight() - var12 - var5.y);
      var14.getUniformOrDefault("radius").set(var7);
      var14.getUniformOrDefault("softness").set(var9);
      var14.getUniformOrDefault("thickness").set(var10);
      var14.getUniformOrDefault("Quality").set(var8);
      var14.getUniformOrDefault("color1")
         .set(
            ColorUtil.redf(var1.getColor().x),
            ColorUtil.greenf(var1.getColor().x),
            ColorUtil.bluef(var1.getColor().x),
            ColorUtil.alphaf(ColorUtil.setAlpha(var1.getColor().x, var3))
         );
      var14.getUniformOrDefault("color2")
         .set(
            ColorUtil.redf(var1.getColor().y),
            ColorUtil.greenf(var1.getColor().y),
            ColorUtil.bluef(var1.getColor().y),
            ColorUtil.alphaf(ColorUtil.setAlpha(var1.getColor().y, var3))
         );
      var14.getUniformOrDefault("color3")
         .set(
            ColorUtil.redf(var1.getColor().z),
            ColorUtil.greenf(var1.getColor().z),
            ColorUtil.bluef(var1.getColor().z),
            ColorUtil.alphaf(ColorUtil.setAlpha(var1.getColor().z, var3))
         );
      var14.getUniformOrDefault("color4")
         .set(
            ColorUtil.redf(var1.getColor().w),
            ColorUtil.greenf(var1.getColor().w),
            ColorUtil.bluef(var1.getColor().w),
            ColorUtil.alphaf(ColorUtil.setAlpha(var1.getColor().w, var3))
         );
      var14.getUniformOrDefault("outlineColor")
         .set(
            ColorUtil.redf(var1.getOutlineColor()),
            ColorUtil.greenf(var1.getOutlineColor()),
            ColorUtil.bluef(var1.getOutlineColor()),
            ColorUtil.alphaf(ColorUtil.setAlpha(var1.getOutlineColor(), var3))
         );
      var14.getUniformOrDefault("InputResolution").set(this.resolution.x, this.resolution.y);
      BufferRenderer.drawWithGlobalProgram(var13.end());
      RenderSystem.disableBlend();
   }

   public void setup() {
      Framebuffer var1 = mc.getFramebuffer();
      if (this.input == null) {
         this.input = new SimpleFramebuffer(mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight(), false);
      }

      this.input.beginWrite(false);
      var1.draw(this.input.textureWidth, this.input.textureHeight);
      var1.beginWrite(false);
      if (this.input != null
         && (this.input.textureWidth != mc.getWindow().getFramebufferWidth() || this.input.textureHeight != mc.getWindow().getFramebufferHeight())) {
         this.input.resize(mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight());
      }

      this.resolution.set(var1.textureWidth, var1.textureHeight);
   }
}
