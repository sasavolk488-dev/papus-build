package project.papus.common.util.particle;

public class EaseAnimation {
   private long start;
   private double duration;
   private double fromValue;
   private double toValue;
   private double value;
   private Easing easing = Easings.LINEAR;
   private Runnable finishAction;

   public EaseAnimation animate(double var1, double var3, Easing var5, boolean var6) {
      if (!var6 || this.isDone() || var1 != this.fromValue && var1 != this.toValue && var1 != this.value) {
         this.easing = var5;
         this.duration = var3 * 1000.0;
         this.start = System.currentTimeMillis();
         this.fromValue = this.value;
         this.toValue = var1;
      }

      return this;
   }

   public boolean update() {
      boolean var1 = !this.isDone();
      if (var1) {
         double var2 = Math.min(1.0, (System.currentTimeMillis() - this.start) / this.duration);
         this.value = this.fromValue + (this.toValue - this.fromValue) * this.easing.ease(var2);
      } else {
         this.start = 0L;
         this.value = this.toValue;
         if (this.finishAction != null) {
            this.finishAction.run();
            this.finishAction = null;
         }
      }

      return var1;
   }

   public boolean isAlive() {
      return !this.isDone();
   }

   public boolean isDone() {
      return this.duration <= 0.0 || System.currentTimeMillis() - this.start >= this.duration;
   }

   public float getFloatValue() {
      return (float)this.value;
   }

   public double getValue() {
      return this.value;
   }

   public void reset(double var1) {
      this.animate(var1, 0.0, Easings.LINEAR, false);
      this.update();
      this.value = var1;
   }

   public long getStart() {
      return this.start;
   }

   public double getDuration() {
      return this.duration;
   }

   public double getFromValue() {
      return this.fromValue;
   }

   public double getToValue() {
      return this.toValue;
   }

   public Easing getEasing() {
      return this.easing;
   }
}
