package project.papus.common.util.math;

public class Counter {
   public long lastMS = System.currentTimeMillis();

   public Counter() {
      this.resetCounter();
   }

   public static Counter create() {
      return new Counter();
   }

   public void resetCounter() {
      this.lastMS = System.currentTimeMillis();
   }

   public boolean isReached(long var1) {
      return System.currentTimeMillis() - this.lastMS > var1;
   }

   public void setTime(long var1) {
      this.lastMS = System.currentTimeMillis() + var1;
   }

   public void setLastMS(long var1) {
      this.lastMS = var1;
   }

   public long getTime() {
      return System.currentTimeMillis() - this.lastMS;
   }

   public boolean isRunning() {
      return System.currentTimeMillis() - this.lastMS <= 0L;
   }

   public boolean hasTimeElapsed() {
      return this.lastMS < System.currentTimeMillis();
   }

   public long getLastMS() {
      return this.lastMS;
   }
}
