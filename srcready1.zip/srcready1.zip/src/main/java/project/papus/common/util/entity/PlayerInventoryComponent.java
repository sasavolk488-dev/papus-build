package project.papus.common.util.entity;

import java.util.List;
import net.minecraft.client.gui.screen.ingame.AbstractCommandBlockScreen;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.SignEditScreen;
import net.minecraft.client.gui.screen.ingame.StructureBlockScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import project.papus.common.QuickImports;
import project.papus.common.util.task.scripts.Script;
import project.papus.common.util.world.ServerUtil;
import project.papus.implement.events.player.KeyboardInputEvent;
import project.papus.implement.screens.menu.MenuScreen;

public final class PlayerInventoryComponent implements QuickImports {
   public static final List<KeyBinding> moveKeys = List.of(
      mc.options.forwardKey, mc.options.backKey, mc.options.leftKey, mc.options.rightKey, mc.options.jumpKey
   );
   public static final Script script = new Script();
   public static final Script postScript = new Script();
   public static boolean canMove = true;

   public static void tick() {
      script.update();
   }

   public static void postMotion() {
      postScript.update();
   }

   public static void onKeyboardInput(KeyboardInputEvent var0) {
      if (!canMove) {
         var0.resetDirectional();
      }
   }

   public static void addTask(Runnable var0) {
      if (script.isFinished() && MovingUtil.hasPlayerMovement()) {
         String var1 = ServerUtil.server;
         switch (var1) {
            case "FunTime":
               script.cleanup().addTimeStep(0, () -> {
                  disableMove();
                  closeScreen();
               }).addTimeStep(1, () -> {
                  var0.run();
                  enableMove();
               });
               return;
            case "ReallyWorld":
               if (mc.player.isOnGround()) {
                  script.cleanup()
                     .addTimeStep(0, PlayerInventoryComponent::disableMove)
                     .addTimeStep(2, PlayerInventoryComponent::closeScreen)
                     .addTimeStep(3, var0::run)
                     .addTimeStep(4, PlayerInventoryComponent::enableMove);
                  return;
               }
               break;
            case "SpookyTime":
            case "CopyTime":
               script.cleanup().addTimeStep(0, () -> {
                  disableMove();
                  closeScreen();
               }).addTimeStep(1, var0::run).addTimeStep(2, PlayerInventoryComponent::enableMove);
               return;
         }
      }

      script.addTimeStep(0, PlayerInventoryComponent::closeScreen);
      postScript.cleanup().addTimeStep(0, () -> {
         var0.run();
         PlayerInventoryUtil.closeScreen(true);
      });
   }

   private static void closeScreen() {
   }

   public static void disableMove() {
      canMove = false;
      unPressMoveKeys();
   }

   public static void enableMove() {
      PlayerInventoryUtil.closeScreen(true);
      canMove = true;
      updateMoveKeys();
   }

   public static void unPressMoveKeys() {
      moveKeys.forEach(var0 -> var0.setPressed(false));
   }

   public static void updateMoveKeys() {
      moveKeys.forEach(var0 -> var0.setPressed(InputUtil.isKeyPressed(mc.getWindow().getHandle(), var0.getDefaultKey().getCode())));
   }

   public static boolean shouldSkipExecution() {
      return mc.currentScreen != null
         && !PlayerHealthUtil.isChat(mc.currentScreen)
         && !(mc.currentScreen instanceof SignEditScreen)
         && !(mc.currentScreen instanceof AnvilScreen)
         && !(mc.currentScreen instanceof AbstractCommandBlockScreen)
         && !(mc.currentScreen instanceof StructureBlockScreen)
         && !(mc.currentScreen instanceof MenuScreen);
   }

   private PlayerInventoryComponent() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
