package project.papus.common.util.entity;

import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import it.unimi.dsi.fastutil.ints.IntPredicate;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.EnderChestInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import project.papus.api.feature.draggable.AbstractDraggable;
import project.papus.common.QuickImports;
import project.papus.common.util.item.ItemUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.rotation.Angle;
import project.papus.common.util.rotation.AngleUtil;

public final class PlayerInventoryUtil implements QuickImports {
   public static void moveItem(Slot var0, int var1) {
      if (var0 != null) {
         moveItem(var0.id, var1, false, false);
      }
   }

   public static void moveItem(Slot var0, int var1, boolean var2) {
      moveItem(var0, var1, var2, false);
   }

   public static void moveItem(Slot var0, int var1, boolean var2, boolean var3) {
      if (var0 != null) {
         moveItem(var0.id, var1, var2, var3);
      }
   }

   public static void moveItem(int var0, int var1, boolean var2, boolean var3) {
      if (var0 != var1 && var0 != -1) {
         int var4 = Math.toIntExact(slots().count()) - 10;
         if (var0 >= var4 && var4 == 36) {
            if (var2) {
               PlayerInventoryComponent.addTask(() -> clickSlot(var1, var0 - var4, SlotActionType.SWAP, false));
            } else {
               clickSlot(var1, var0 - var4, SlotActionType.SWAP, false);
            }
         } else if (var2) {
            PlayerInventoryComponent.addTask(() -> swapAndUse(var0, var1, var3));
         } else {
            swapAndUse(var0, var1, var3);
         }
      }
   }

   public static void swapAndUse(int var0, int var1, boolean var2) {
      clickSlot(var0, 0, SlotActionType.SWAP, false);
      clickSlot(var1, 0, SlotActionType.SWAP, false);
      clickSlot(var0, 0, SlotActionType.SWAP, false);
      if (var2) {
         closeScreen();
      }
   }

   public static void swapHand(Slot var0, Hand var1, boolean var2) {
      swapHand(var0, var1, var2, false);
   }

   public static void swapHand(Slot var0, Hand var1, boolean var2, boolean var3) {
      if (var0 != null
         && var0.id != -1
         && (!var1.equals(Hand.OFF_HAND) || var0.inventory instanceof PlayerInventory || var0.inventory instanceof EnderChestInventory)) {
         int var4 = var1.equals(Hand.MAIN_HAND) ? mc.player.getInventory().selectedSlot : 40;
         if (var2) {
            PlayerInventoryComponent.addTask(() -> swapWithHotbar(var0, var4, var3));
         } else {
            swapWithHotbar(var0, var4, var3);
         }
      }
   }

   public static void swapWithHotbar(Slot var0, int var1, boolean var2) {
      clickSlot(var0, var1, SlotActionType.SWAP, false);
      if (var2) {
         closeScreen();
      }
   }

   public static void swapAndUse(Slot var0, String var1, boolean var2) {
      if (var0 == null) {
         AbstractDraggable.NotificationsDraggable.getInstance()
            .addTextIfNotExists(Formatting.RED + var1 + Formatting.RESET + " - \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d!", 3000L);
      } else if (var2) {
         PlayerInventoryComponent.addTask(() -> useSlot(var0, AngleUtil.cameraAngle()));
      } else {
         useSlot(var0, AngleUtil.cameraAngle());
      }
   }

   public static void swapAndUse(Item var0) {
      swapAndUse(var0, AngleUtil.cameraAngle(), true);
   }

   public static void swapAndUse(Item var0, Angle var1, boolean var2) {
      float var3 = ItemUtil.getCooldownProgress(var0);
      if (var3 > 0.0F) {
         String var4 = MathUtil.round((double)var3, 0.1) + "\u0441";
         AbstractDraggable.NotificationsDraggable.getInstance()
            .addTextIfNotExists(Formatting.RED + var0.getName().getString() + Formatting.RESET + " - \u0432 \u043a\u0434 \u0435\u0449\u0435 " + var4, 2000L);
      } else {
         Slot var5 = getSlot(var0);
         if (var5 == null) {
            AbstractDraggable.NotificationsDraggable.getInstance()
               .addTextIfNotExists(
                  Formatting.RED + var0.getName().getString() + Formatting.RESET + " - \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d!", 2000L
               );
         } else if (var2) {
            PlayerInventoryComponent.addTask(() -> useSlot(var5, var1));
         } else {
            useSlot(var5, var1);
         }
      }
   }

   public static void useSlot(Slot var0, Angle var1) {
      swapHand(var0, Hand.MAIN_HAND, false);
      PlayerHealthUtil.interactItem(Hand.MAIN_HAND, var1);
      swapHand(var0, Hand.MAIN_HAND, false, true);
   }

   public static void closeScreen() {
      ScreenHandler var0 = mc.player.currentScreenHandler;
      ItemStack var1 = ((Item)Registries.ITEM.get(MathUtil.getRandom(0, 100))).getDefaultStack();
      mc.player
         .networkHandler
         .sendPacket(new ClickSlotC2SPacket(var0.syncId, var0.getRevision(), 0, 0, SlotActionType.PICKUP_ALL, var1, Int2ObjectMaps.singleton(0, var1)));
   }

   public static void closeScreen(boolean var0) {
      if (var0) {
         mc.player.networkHandler.sendPacket(new CloseHandledScreenC2SPacket(mc.player.currentScreenHandler.syncId));
      } else {
         mc.player.closeHandledScreen();
      }
   }

   public static void clickSlot(Slot var0, int var1, SlotActionType var2, boolean var3) {
      if (var0 != null) {
         clickSlot(var0.id, var1, var2, var3);
      }
   }

   public static void clickSlot(int var0, int var1, SlotActionType var2, boolean var3) {
      clickSlot(mc.player.currentScreenHandler.syncId, var0, var1, var2, var3);
   }

   public static void clickSlot(int var0, int var1, int var2, SlotActionType var3, boolean var4) {
      mc.interactionManager.clickSlot(var0, var1, var2, var3, mc.player);
      if (var4) {
         mc.player.currentScreenHandler.onSlotClick(var1, var2, var3, mc.player);
      }
   }

   public static Slot getSlot(Item var0) {
      return getSlot(var0, var0x -> true);
   }

   public static Slot getSlot(Item var0, Predicate<Slot> var1) {
      return getSlot(var0, Comparator.comparingInt(var0x -> 0), var1);
   }

   public static Slot getSlot(Predicate<Slot> var0) {
      return slots().filter(var0).findFirst().orElse(null);
   }

   public static Slot getSlot(Predicate<Slot> var0, Comparator<Slot> var1) {
      return slots().filter(var0).max(var1).orElse(null);
   }

   public static Slot getSlot(Item var0, Comparator<Slot> var1, Predicate<Slot> var2) {
      return slots().filter(var1x -> var1x.getStack().getItem().equals(var0)).filter(var2).max(var1).orElse(null);
   }

   public static Slot getFoodMaxSaturationSlot() {
      return slots()
         .filter(var0 -> var0.getStack().get(DataComponentTypes.FOOD) != null && !((FoodComponent)var0.getStack().get(DataComponentTypes.FOOD)).canAlwaysEat())
         .max(Comparator.comparingDouble(var0 -> ((FoodComponent)var0.getStack().get(DataComponentTypes.FOOD)).saturation()))
         .orElse(null);
   }

   public static Slot getSlot(List<Item> var0) {
      return slots().filter(var1 -> var0.contains(var1.getStack().getItem())).findFirst().orElse(null);
   }

   public static Slot getPotion(RegistryEntry<StatusEffect> var0) {
      return slots()
         .filter(
            var1 -> {
               PotionContentsComponent var2 = (PotionContentsComponent)var1.getStack().get(DataComponentTypes.POTION_CONTENTS);
               return var2 == null
                  ? false
                  : StreamSupport.<StatusEffectInstance>stream(var2.getEffects().spliterator(), false).anyMatch(var1x -> var1x.getEffectType().equals(var0));
            }
         )
         .findFirst()
         .orElse(null);
   }

   public static Slot getPotionFromCategory(StatusEffectCategory var0) {
      return slots()
         .filter(
            var1 -> {
               ItemStack var2 = var1.getStack();
               PotionContentsComponent var3 = (PotionContentsComponent)var2.get(DataComponentTypes.POTION_CONTENTS);
               if (var2.getItem().equals(Items.SPLASH_POTION) && var3 != null) {
                  StatusEffectCategory var4 = var0.equals(StatusEffectCategory.BENEFICIAL) ? StatusEffectCategory.HARMFUL : StatusEffectCategory.BENEFICIAL;
                  long var5 = StreamSupport.<StatusEffectInstance>stream(var3.getEffects().spliterator(), false)
                     .filter(var1x -> ((StatusEffect)var1x.getEffectType().value()).getCategory().equals(var0))
                     .count();
                  long var7 = StreamSupport.<StatusEffectInstance>stream(var3.getEffects().spliterator(), false)
                     .filter(var1x -> ((StatusEffect)var1x.getEffectType().value()).getCategory().equals(var4))
                     .count();
                  return var5 >= var7;
               } else {
                  return false;
               }
            }
         )
         .findFirst()
         .orElse(null);
   }

   public static int getInventoryCount(Item var0) {
      return IntStream.range(0, 45)
         .filter(var1 -> Objects.requireNonNull(mc.player).getInventory().getStack(var1).getItem().equals(var0))
         .map(var0x -> mc.player.getInventory().getStack(var0x).getCount())
         .sum();
   }

   public static int getInventoryCount(List<Item> var0) {
      return IntStream.range(0, 9).filter(var1 -> var0.contains(mc.player.getInventory().getStack(var1).getItem())).findFirst().orElse(-1);
   }

   public static int getCount(IntPredicate var0) {
      return IntStream.range(0, 9).filter(var0).findFirst().orElse(-1);
   }

   public static int getCount(Predicate<Slot> var0) {
      return slots().filter(var0).mapToInt(var0x -> var0x.getStack().getCount()).sum();
   }

   public static Slot mainHandSlot() {
      long var0 = slots().count();
      int var2 = var0 == 46L ? 10 : 9;
      return slots().toList().get(Math.toIntExact(var0 - var2 + mc.player.getInventory().selectedSlot));
   }

   public static boolean isServerScreen() {
      return slots().toList().size() != 46;
   }

   public static Stream<Slot> slots() {
      return mc.player.currentScreenHandler.slots.stream();
   }

   private PlayerInventoryUtil() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
