package project.papus.common.util.builders;

public interface Builder<T> {
   T create();
}
