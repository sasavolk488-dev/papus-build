package project.papus.common.util.entity;

import net.minecraft.util.math.Vec3d;

public interface SimulatedEntity {
   Vec3d pos();

   void tick();
}
