package project.papus.common;

import com.google.gson.Gson;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.util.Window;
import project.papus.api.system.draw.DrawEngine;
import project.papus.api.system.draw.DrawEngineImpl;
import project.papus.api.system.shape.implement.Arc;
import project.papus.api.system.shape.implement.Blur;
import project.papus.api.system.shape.implement.Image;
import project.papus.api.system.shape.implement.Rectangle;
import project.papus.implement.screens.menu.components.implement.window.WindowManager;

public interface QuickImports extends QuickLogger {
   MinecraftClient mc = MinecraftClient.getInstance();
   RenderTickCounter renderTickCounter = mc.getRenderTickCounter();
   Window window = mc.getWindow();
   DrawEngine drawEngine = new DrawEngineImpl();
   Rectangle rectangle = new Rectangle();
   Blur blur = new Blur();
   Arc arc = new Arc();
   Image image = new Image();
   Gson gson = new Gson();
   WindowManager windowManager = new WindowManager();

   static Tessellator tessellator() {
      return Tessellator.getInstance();
   }
}
