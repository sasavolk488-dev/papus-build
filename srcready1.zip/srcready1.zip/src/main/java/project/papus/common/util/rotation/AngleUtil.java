package project.papus.common.util.rotation;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import project.papus.common.QuickImports;

public class AngleUtil implements QuickImports {
   public static Angle fromVec3d(Vec3d var0, Vec3d var1) {
      Vec3d var2 = var1.subtract(var0);
      double var3 = Math.sqrt(var2.x * var2.x + var2.z * var2.z);
      float var5 = (float)Math.toDegrees(Math.atan2(-var2.x, var2.z));
      float var6 = (float)(-Math.toDegrees(Math.atan2(var2.y, var3)));
      return new Angle(var5, var6);
   }

   public static Angle entityAngle(Entity var0) {
      return mc.player == null ? new Angle() : fromVec3d(mc.player.getEyePos(), var0.getPos());
   }

   public static Angle fromVec3d(Vec3d var0) {
      return mc.player == null ? new Angle() : fromVec3d(mc.player.getEyePos(), var0);
   }

   public static Angle cameraAngle() {
      return mc.player == null ? new Angle() : new Angle(mc.player.getYaw(), mc.player.getPitch());
   }

   public static Angle playerAngle(float var0) {
      return mc.player == null ? new Angle(0.0F, var0) : new Angle(mc.player.getYaw(), var0);
   }

   public static Angle pitchToYaw(Vec3d var0) {
      double var1 = Math.sqrt(var0.x * var0.x + var0.z * var0.z);
      float var3 = (float)Math.toDegrees(Math.atan2(-var0.x, var0.z));
      float var4 = (float)(-Math.toDegrees(Math.atan2(var0.y, var1)));
      return new Angle(var3, var4);
   }
}
