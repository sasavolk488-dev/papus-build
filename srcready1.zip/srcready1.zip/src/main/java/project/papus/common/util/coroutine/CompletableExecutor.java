package project.papus.common.util.coroutine;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CompletableExecutor {
   private final ExecutorService executor = Executors.newSingleThreadExecutor();
   private final CompletableFuture<Void> future;

   public CompletableExecutor(Runnable var1) {
      this.future = CompletableFuture.runAsync(var1, this.executor);
   }

   @lombok.SneakyThrows
   public void reset() {
      this.future.get();
   }

   public void await() {
      this.executor.shutdown();
   }
}
