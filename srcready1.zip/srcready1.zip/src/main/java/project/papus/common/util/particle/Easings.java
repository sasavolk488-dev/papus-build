package project.papus.common.util.particle;

public final class Easings {
   public static final Easing LINEAR = var0 -> var0;
   public static final Easing QUAD_BOTH = powIn(2.0);
   public static final Easing CUBIC_BOTH = powOut(2.0);
   public static final Easing QUART_BOTH = powInOut(2.0);

   public static Easing powIn(double var0) {
      return var2 -> Math.pow(var2, var0);
   }

   public static Easing powOut(double var0) {
      return var2 -> 1.0 - Math.pow(1.0 - var2, var0);
   }

   public static Easing powInOut(double var0) {
      return var2 -> var2 < 0.5 ? Math.pow(2.0, var0 - 1.0) * Math.pow(var2, var0) : 1.0 - Math.pow(-2.0 * var2 + 2.0, var0) / 2.0;
   }
}
