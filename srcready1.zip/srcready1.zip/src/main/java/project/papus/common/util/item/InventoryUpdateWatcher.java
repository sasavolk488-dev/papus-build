package project.papus.common.util.item;

import java.util.Objects;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket.Mode;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.util.Hand;
import project.papus.api.event.EventHandler;
import project.papus.common.QuickImports;
import project.papus.core.Main;
import project.papus.implement.events.packet.PacketEvent;

public class InventoryUpdateWatcher implements QuickImports {
   public static final InventoryUpdateWatcher INSTANCE = new InventoryUpdateWatcher();
   public boolean holdItem;
   public boolean changed = true;

   public InventoryUpdateWatcher() {
      Main.getInstance().getEventManager().register(this);
   }

   @EventHandler
   public void onPacket(PacketEvent var1) {
      Object var2 = var1.getPacket();
      Objects.requireNonNull(var2);
      Objects.requireNonNull(var2);
      switch (var2) {
         case PlayerActionC2SPacket var6 when var6.getAction().equals(Action.RELEASE_USE_ITEM):
            this.changed = true;
            break;
         case ClientStatusC2SPacket var7 when var7.getMode().equals(Mode.PERFORM_RESPAWN):
            this.changed = true;
            break;
         case PlayerRespawnS2CPacket var8:
            this.changed = true;
            break;
         case GameJoinS2CPacket var9:
            this.changed = true;
            break;
         default:
      }
   }

   public void useItem(Hand var1) {
      if (this.changed) {
         mc.interactionManager.interactItem(mc.player, var1);
         this.changed = false;
      }

      this.holdItem = true;
   }

   public void setHoldItem(boolean var1) {
      this.holdItem = var1;
   }

   public void setChanged(boolean var1) {
      this.changed = var1;
   }

   public boolean isHoldItem() {
      return this.holdItem;
   }

   public boolean isChanged() {
      return this.changed;
   }
}
