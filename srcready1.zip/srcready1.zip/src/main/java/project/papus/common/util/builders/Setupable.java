package project.papus.common.util.builders;

import project.papus.api.feature.module.setting.Setting;

public interface Setupable {
   void setup(Setting... var1);
}
