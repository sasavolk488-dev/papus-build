package project.papus.common.util.rotation;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Angle {
   private float yaw;
   private float pitch;

   public Angle() {
      this(0.0F, 0.0F);
   }

   public Vec3d toVector() {
      float var1 = this.pitch * (float) (Math.PI / 180.0);
      float var2 = -this.yaw * (float) (Math.PI / 180.0);
      float var3 = MathHelper.cos(var2);
      float var4 = MathHelper.sin(var2);
      float var5 = MathHelper.cos(var1);
      float var6 = MathHelper.sin(var1);
      return new Vec3d(var4 * var5, -var6, var3 * var5);
   }

   public Angle adjustSensitivity() {
      return new Angle(this.yaw, this.pitch);
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPitch() {
      return this.pitch;
   }

   public void setYaw(float var1) {
      this.yaw = var1;
   }

   public void setPitch(float var1) {
      this.pitch = var1;
   }

   @Override
   public boolean equals(Object var1) {
      if (var1 == this) {
         return true;
      } else if (var1 instanceof Angle var2) {
         if (!var2.canEqual(this)) {
            return false;
         } else {
            return Float.compare(this.getYaw(), var2.getYaw()) != 0 ? false : Float.compare(this.getPitch(), var2.getPitch()) == 0;
         }
      } else {
         return false;
      }
   }

   protected boolean canEqual(Object var1) {
      return var1 instanceof Angle;
   }

   @Override
   public int hashCode() {
      byte var1 = 59;
      int var2 = 1;
      var2 = var2 * 59 + Float.floatToIntBits(this.getYaw());
      return var2 * 59 + Float.floatToIntBits(this.getPitch());
   }

   @Override
   public String toString() {
      return "Angle(yaw=" + this.getYaw() + ", pitch=" + this.getPitch() + ")";
   }

   public Angle(float var1, float var2) {
      this.yaw = var1;
      this.pitch = var2;
   }
}
