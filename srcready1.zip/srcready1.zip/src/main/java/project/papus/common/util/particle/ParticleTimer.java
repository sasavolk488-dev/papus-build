package project.papus.common.util.particle;

public class ParticleTimer {
   private long lastMS;

   public ParticleTimer() {
      this.reset();
   }

   public boolean passed(double var1) {
      return System.currentTimeMillis() - var1 >= this.lastMS;
   }

   public void reset() {
      this.lastMS = System.currentTimeMillis();
   }

   public long getElapsedTime() {
      return System.currentTimeMillis() - this.lastMS;
   }
}
