package project.papus.common.util.other;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import project.papus.api.feature.draggable.AbstractDraggable;
import project.papus.api.feature.module.Module;
import project.papus.core.Main;

public final class Instance {
   private static final ConcurrentMap<Class<? extends Module>, Module> instanceModules = new ConcurrentHashMap<>();
   private static final ConcurrentMap<Class<? extends AbstractDraggable>, AbstractDraggable> instanceDraggables = new ConcurrentHashMap<>();

   public static <T extends Module> T get(Class<T> var0) {
      return (T)var0.cast(instanceModules.computeIfAbsent(var0, var0x -> Main.getInstance().getModuleProvider().get((Class<? extends Module>)var0x)));
   }

   public static <T extends Module> T get(String var0) {
      return Main.getInstance().getModuleProvider().get(var0);
   }

   public static <T extends AbstractDraggable> T getDraggable(Class<T> var0) {
      return (T)var0.cast(
         instanceDraggables.computeIfAbsent(var0, var0x -> Main.getInstance().getDraggableRepository().get((Class<? extends AbstractDraggable>)var0x))
      );
   }

   public static <T extends AbstractDraggable> T getDraggable(String var0) {
      return Main.getInstance().getDraggableRepository().get(var0);
   }

   private Instance() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
