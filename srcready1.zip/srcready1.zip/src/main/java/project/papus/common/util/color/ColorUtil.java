package project.papus.common.util.color;

import it.unimi.dsi.fastutil.chars.Char2IntArrayMap;
import java.awt.Color;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import net.minecraft.util.math.MathHelper;
import org.joml.Vector4i;

public final class ColorUtil {
   private static final long CACHE_EXPIRE_TIME = 60000L;
   private static final ConcurrentHashMap<ColorUtil.ColorKey, ColorUtil.ColorCacheEntry> colorCache = new ConcurrentHashMap<>();
   private static final ScheduledExecutorService cacheCleaner = Executors.newScheduledThreadPool(1);
   private static final DelayQueue<ColorUtil.ColorCacheEntry> cleanupQueue = new DelayQueue<>();
   public static final Pattern FORMATTING_CODE_PATTERN = Pattern.compile("(?i)\u00a7[0-9a-f-or]");
   public static Char2IntArrayMap colorCodes = new Char2IntArrayMap() {
      {
         this.put('0', 0);
         this.put('1', 170);
         this.put('2', 43520);
         this.put('3', 43690);
         this.put('4', 11141120);
         this.put('5', 11141290);
         this.put('6', 16755200);
         this.put('7', 11184810);
         this.put('8', 5592405);
         this.put('9', 5592575);
         this.put('A', 5635925);
         this.put('B', 5636095);
         this.put('C', 16733525);
         this.put('D', 16733695);
         this.put('E', 16777045);
         this.put('F', 16777215);
      }
   };
   public static final int RED = getColor(255, 0, 0);
   public static final int GREEN = getColor(0, 255, 0);
   public static final int BLUE = getColor(0, 0, 255);
   public static final int YELLOW = getColor(255, 255, 0);
   public static final int WHITE = multDark(255);
   public static final int BLACK = multDark(0);
   public static final int HALF_BLACK = replAlpha(0, 0.5F);
   public static final int MAIN_THEM = getColor(255, 85, 85);

   public static int red(int var0) {
      return var0 >> 16 & 0xFF;
   }

   public static int green(int var0) {
      return var0 >> 8 & 0xFF;
   }

   public static int blue(int var0) {
      return var0 & 0xFF;
   }

   public static int alpha(int var0) {
      return var0 >> 24 & 0xFF;
   }

   public static float redf(int var0) {
      return red(var0) / 255.0F;
   }

   public static float greenf(int var0) {
      return green(var0) / 255.0F;
   }

   public static float bluef(int var0) {
      return blue(var0) / 255.0F;
   }

   public static float alphaf(int var0) {
      return alpha(var0) / 255.0F;
   }

   public static int[] toRGBA(int var0) {
      return new int[]{red(var0), green(var0), blue(var0), alpha(var0)};
   }

   public static int[] toRGB(int var0) {
      return new int[]{red(var0), green(var0), blue(var0)};
   }

   public static float[] toRGBAf(int var0) {
      return new float[]{redf(var0), greenf(var0), bluef(var0), alphaf(var0)};
   }

   public static float[] toRGBf(int var0) {
      return new float[]{redf(var0), greenf(var0), bluef(var0)};
   }

   public static int getColor(float var0, float var1, float var2, float var3) {
      return getColor(Math.round(var0 * 255.0F), Math.round(var1 * 255.0F), Math.round(var2 * 255.0F), Math.round(var3 * 255.0F));
   }

   public static int getColor(int var0, int var1, int var2, float var3) {
      return getColor(var0, var1, var2, Math.round(var3 * 255.0F));
   }

   public static int getColor(float var0, float var1, float var2) {
      return getColor(var0, var1, var2, 1.0F);
   }

   public static int replAlpha(int var0, int var1) {
      return getColor(var0, var0, var0, var1);
   }

   public static int replAlpha(int var0, float var1) {
      return replAlpha(var0, Math.round(var1 * 255.0F));
   }

   public static int multDark(int var0) {
      return getColor(var0, var0, var0);
   }

   public static int multAlpha(int var0, int var1) {
      return getColor(red(var0), green(var0), blue(var0), var1);
   }

   public static int multAlpha(int var0, float var1) {
      return getColor(red(var0), green(var0), blue(var0), var1);
   }

   public static int overCol(int var0, int var1) {
      return getColor(red(var0), green(var0), blue(var0), var1);
   }

   public static int setAlpha(int var0, float var1) {
      return getColor(red(var0), green(var0), blue(var0), Math.round(alpha(var0) * var1));
   }

   public static int overCol(int var0, int var1, float var2) {
      return getColor(
         Math.round(red(var0) * (redf(var1) * var2)),
         Math.round(green(var0) * (greenf(var1) * var2)),
         Math.round(blue(var0) * (bluef(var1) * var2)),
         Math.round(alpha(var0) * (alphaf(var1) * var2))
      );
   }

   public static int lerp(int var0, int var1, float var2) {
      return getColor(
         Math.round(red(var0) * (redf(var1) * var2)),
         Math.round(green(var0) * (greenf(var1) * var2)),
         Math.round(blue(var0) * (bluef(var1) * var2)),
         Math.round(alpha(var0) * (alphaf(var1) * var2))
      );
   }

   public static int multBright(int var0, float var1) {
      return getColor(Math.round(red(var0) * var1), Math.round(green(var0) * var1), Math.round(blue(var0) * var1), alpha(var0));
   }

   public static int multDark(int var0, float var1) {
      return getColor(
         Math.min(255, Math.round(red(var0) / var1)), Math.min(255, Math.round(green(var0) / var1)), Math.min(255, Math.round(blue(var0) / var1)), alpha(var0)
      );
   }

   public static int interpolateColor(int var0, int var1, float var2) {
      float var3 = MathHelper.clamp(var2, 0.0F, 1.0F);
      return getColor(
         MathHelper.lerp(var3, red(var0), red(var1)),
         MathHelper.lerp(var3, green(var0), green(var1)),
         MathHelper.lerp(var3, blue(var0), blue(var1)),
         MathHelper.lerp(var3, alpha(var0), alpha(var1))
      );
   }

   public static Vector4i multDark(Vector4i var0, float var1, float var2) {
      return new Vector4i(
         multRedAndAlpha(var0.x, var1, var2), multRedAndAlpha(var0.y, var1, var2), multRedAndAlpha(var0.w, var1, var2), multRedAndAlpha(var0.z, var1, var2)
      );
   }

   public static int multRedAndAlpha(int var0, float var1, float var2) {
      return getColor(red(var0), Math.min(255, Math.round(green(var0) / var1)), Math.min(255, Math.round(blue(var0) / var1)), Math.round(alpha(var0) * var2));
   }

   public static int saturate(int var0, float var1) {
      return getColor(red(var0), Math.min(255, Math.round(green(var0) / var1)), Math.min(255, Math.round(blue(var0) / var1)), alpha(var0));
   }

   public static int hue(int var0, float var1) {
      return getColor(Math.min(255, Math.round(green(var0) / var1)), green(var0), Math.min(255, Math.round(blue(var0) / var1)), alpha(var0));
   }

   public static int[] genGradientForText(int var0, int var1, int var2) {
      int[] var3 = new int[var2];

      for (int var4 = 0; var4 < var2; var4++) {
         float var5 = (float)var4 / (var2 - 1);
         var3[var4] = interpolateColor(var0, var1, var5);
      }

      return var3;
   }

   public static int gradient(int var0, int var1, float var2, float var3, float var4) {
      int var5 = (int)((System.currentTimeMillis() / var0 + var1) % 360L);
      float var6 = var5 / 360.0F;
      int var7 = Color.HSBtoRGB(var6, var2, var3);
      return getColor(red(var7), green(var7), blue(var7), Math.round(var4 * 255.0F));
   }

   public static int fade(int var0, int var1, int var2, int var3) {
      int var4 = (int)((System.currentTimeMillis() / var0 + var1) % 360L);
      var4 = var4 >= 180 ? 360 - var4 : var4;
      return interpolateColor(var2, var3, var4 / 180.0F);
   }

   public static int fade(int var0) {
      Color var1 = new Color(getFriendColor());
      return fade(8, var0, var1.brighter().getRGB(), var1.darker().getRGB());
   }

   public static Vector4i roundClientColor(float var0) {
      return new Vector4i(setAlpha(fade(270), var0), setAlpha(fade(0), var0), setAlpha(fade(180), var0), setAlpha(fade(90), var0));
   }

   public static int getColor(int var0, int var1, int var2, int var3) {
      ColorUtil.ColorKey var4 = new ColorUtil.ColorKey(var0, var1, var2, var3);
      ColorUtil.ColorCacheEntry var5 = colorCache.computeIfAbsent(var4, var4x -> {
         ColorUtil.ColorCacheEntry var5x = new ColorUtil.ColorCacheEntry(var4x, computeColor(var0, var1, var2, var3), 60000L);
         cleanupQueue.offer(var5x);
         return var5x;
      });
      return var5.getColor();
   }

   public static int getColor(int var0, int var1, int var2) {
      return getColor(var0, var1, var2, 255);
   }

   private static int computeColor(int var0, int var1, int var2, int var3) {
      return MathHelper.clamp(var3, 0, 255) << 24 | MathHelper.clamp(var0, 0, 255) << 16 | MathHelper.clamp(var1, 0, 255) << 8 | MathHelper.clamp(var2, 0, 255);
   }

   private static String colorToHex(int var0, int var1, int var2, int var3) {
      return var0 + "," + var1 + "," + var2 + "," + var3;
   }

   public static String colorToHex(int var0) {
      return "\u23cf" + var0 + "\u23cf";
   }

   public static String removeFormatting(String var0) {
      return var0 != null && !var0.isEmpty() ? FORMATTING_CODE_PATTERN.matcher(var0).replaceAll("") : null;
   }

   public static int getClientColor() {
      return new Color(1579037).getRGB();
   }

   public static int getClientColor(float var0) {
      return setAlpha(new Color(1710623).getRGB(), var0);
   }

   public static int getGuiBackgroundColor(float var0) {
      return setAlpha(new Color(1973798).getRGB(), var0);
   }

   public static int getFriendColor(float var0) {
      return setAlpha(new Color(1579036).getRGB(), var0);
   }

   public static int getOutlineColor(float var0) {
      return setAlpha(new Color(1579038).getRGB(), var0);
   }

   public static int getTextColor(float var0) {
      return setAlpha(getTextColor(), var0);
   }

   public static int getTextColor() {
      return new Color(15132390).getRGB();
   }

   public static int getFriendColor() {
      return new Color(6986705).getRGB();
   }

   public static int getMainGuiColor(float var0) {
      return setAlpha(getFriendColor(), var0);
   }

   public static int getMainGuiColor() {
      return new Color(5635925).getRGB();
   }

   public static int getClientColor(float var0, float var1) {
      return multDark(setAlpha(getOutlineColor(), var0), var1);
   }

   public static int getSecondaryGuiColor(float var0) {
      return setAlpha(getOutlineColor(), var0);
   }

   public static int getOutlineColor() {
      return new Color(369098751, true).getRGB();
   }

   private ColorUtil() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   static {
      cacheCleaner.scheduleWithFixedDelay(() -> {
         for (ColorUtil.ColorCacheEntry var0 = cleanupQueue.poll(); var0 != null; var0 = cleanupQueue.poll()) {
            if (var0.isExpired()) {
               colorCache.remove(var0.getKey());
            }
         }
      }, 0L, 1L, TimeUnit.SECONDS);
   }

   static class ColorCacheEntry implements Delayed {
      private final ColorUtil.ColorKey key;
      private final int color;
      private final long expirationTime;

      ColorCacheEntry(ColorUtil.ColorKey var1, int var2, long var3) {
         this.key = var1;
         this.color = var2;
         this.expirationTime = System.currentTimeMillis() + var3;
      }

      @Override
      public long getDelay(TimeUnit var1) {
         long var2 = this.expirationTime - System.currentTimeMillis();
         return var1.convert(var2, TimeUnit.MILLISECONDS);
      }

      public int compareTo(Delayed var1) {
         return var1 instanceof ColorUtil.ColorCacheEntry ? Long.compare(this.expirationTime, ((ColorUtil.ColorCacheEntry)var1).expirationTime) : 0;
      }

      public boolean isExpired() {
         return System.currentTimeMillis() > this.expirationTime;
      }

      public ColorUtil.ColorKey getKey() {
         return this.key;
      }

      public int getColor() {
         return this.color;
      }

      public long getExpirationTime() {
         return this.expirationTime;
      }
   }

   static class ColorKey {
      final int red;
      final int green;
      final int blue;
      final int alpha;

      public int getRed() {
         return this.red;
      }

      public int getGreen() {
         return this.green;
      }

      public int getBlue() {
         return this.blue;
      }

      public int getAlpha() {
         return this.alpha;
      }

      public ColorKey(int var1, int var2, int var3, int var4) {
         this.red = var1;
         this.green = var2;
         this.blue = var3;
         this.alpha = var4;
      }

      @Override
      public boolean equals(Object var1) {
         if (var1 == this) {
            return true;
         } else if (var1 instanceof ColorUtil.ColorKey var2) {
            if (!var2.canEqual(this)) {
               return false;
            } else if (this.getRed() != var2.getRed()) {
               return false;
            } else if (this.getGreen() != var2.getGreen()) {
               return false;
            } else {
               return this.getBlue() != var2.getBlue() ? false : this.getAlpha() == var2.getAlpha();
            }
         } else {
            return false;
         }
      }

      protected boolean canEqual(Object var1) {
         return var1 instanceof ColorUtil.ColorKey;
      }

      @Override
      public int hashCode() {
         byte var1 = 59;
         int var2 = 1;
         var2 = var2 * 59 + this.getRed();
         var2 = var2 * 59 + this.getGreen();
         var2 = var2 * 59 + this.getBlue();
         return var2 * 59 + this.getAlpha();
      }
   }
}
