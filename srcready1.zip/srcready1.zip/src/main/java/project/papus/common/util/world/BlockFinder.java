package project.papus.common.util.world;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.entity.BlockEntity;
import project.papus.api.event.EventHandler;
import project.papus.common.QuickImports;
import project.papus.core.Main;
import project.papus.implement.events.block.BlockEntityProgressEvent;
import project.papus.implement.events.render.WorldLoadEvent;

public class BlockFinder implements QuickImports {
   public final List<BlockEntity> blockEntities = new ArrayList<>();
   public static BlockFinder INSTANCE = new BlockFinder();

   public BlockFinder() {
      Main.getInstance().getEventManager().register(this);
   }

   @EventHandler
   public void onWorldLoad(WorldLoadEvent var1) {
      this.blockEntities.clear();
   }

   @EventHandler
   public void onBlockEntityProgress(BlockEntityProgressEvent var1) {
      BlockEntity var2 = var1.blockEntity();
      switch (var1.type()) {
         case ADD:
            if (!this.blockEntities.stream().map(BlockEntity::getPos).toList().contains(var2.getPos())) {
               this.blockEntities.add(var2);
            }
            break;
         case REMOVE:
            this.blockEntities.remove(var2);
      }
   }
}
