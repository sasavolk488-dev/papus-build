package project.papus.common.util.rotation;

import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import project.papus.common.QuickImports;

public class MovementCorrection implements QuickImports {
   public static HitResult raycast(double var0, Angle var2, boolean var3) {
      if (mc.player != null && mc.world != null) {
         Vec3d var4 = mc.player.getEyePos();
         Vec3d var5 = var2.toVector();
         Vec3d var6 = var4.add(var5.multiply(var0));
         FluidHandling var7 = var3 ? FluidHandling.ANY : FluidHandling.NONE;
         RaycastContext var8 = new RaycastContext(var4, var6, ShapeType.OUTLINE, var7, mc.player);
         BlockHitResult var9 = mc.world.raycast(var8);
         Box var10 = mc.player.getBoundingBox().stretch(var5.multiply(var0)).expand(1.0);
         EntityHitResult var11 = ProjectileUtil.raycast(mc.player, var4, var6, var10, var0x -> !var0x.isSpectator() && var0x.canHit(), var0 * var0);
         if (var11 != null) {
            double var12 = var4.squaredDistanceTo(var11.getPos());
            double var14 = var4.squaredDistanceTo(var9.getPos());
            if (var12 < var14) {
               return var11;
            }
         }

         return var9;
      } else {
         return null;
      }
   }

   public static HitResult raycast(Vec3d var0, double var1, Angle var3, boolean var4) {
      if (mc.player != null && mc.world != null) {
         Vec3d var5 = var3.toVector();
         Vec3d var6 = var0.add(var5.multiply(var1));
         FluidHandling var7 = var4 ? FluidHandling.ANY : FluidHandling.NONE;
         RaycastContext var8 = new RaycastContext(var0, var6, ShapeType.OUTLINE, var7, mc.player);
         return mc.world.raycast(var8);
      } else {
         return null;
      }
   }
}
