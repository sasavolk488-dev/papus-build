package project.papus.common.util.world;

import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.math.MathHelper;
import org.apache.commons.lang3.StringUtils;
import project.papus.common.QuickImports;
import project.papus.common.util.entity.PlayerHealthUtil;
import project.papus.common.util.other.StopWatch;
import project.papus.implement.events.packet.PacketEvent;

public final class ServerUtil implements QuickImports {
   private static final StopWatch pvpWatch = new StopWatch();
   public static String server = "Vanilla";
   public static float TPS = 20.0F;
   public static long timestamp;
   public static int anarchy;
   public static boolean pvpState;

   public static void tick() {
      anarchy = getAnarchyFromScoreboard();
      server = parseAnarchy();
      pvpState = hasScoreboardPvp();
      if (hasBossBarPvp()) {
         pvpWatch.reset();
      }
   }

   public static void onPacket(PacketEvent var0) {
      switch (var0.getPacket()) {
         case WorldTimeUpdateS2CPacket var3:
            long var4 = System.nanoTime();
            float var6 = 20.0F;
            float var7 = var6 * (1.0E9F / (float)(var4 - timestamp));
            TPS = MathHelper.clamp(var7, 0.0F, var6);
            timestamp = var4;
         default:
      }
   }

   private static String parseAnarchy() {
      if (!PlayerHealthUtil.nullCheck()
         && mc.getNetworkHandler() != null
         && mc.getNetworkHandler().getServerInfo() != null
         && mc.getNetworkHandler().getBrand() != null) {
         String var0 = mc.getNetworkHandler().getServerInfo().address.toLowerCase();
         String var1 = mc.getNetworkHandler().getBrand().toLowerCase();
         if (var1.contains("botfilter")) {
            return "FunTime";
         } else if (var1.contains("\u00a76spooky\u00a7ccore")) {
            return "SpookyTime";
         } else if (var0.contains("funtime") || var0.contains("skytime") || var0.contains("space-times") || var0.contains("funsky")) {
            return "CopyTime";
         } else if (!var1.contains("holyworld") && !var1.contains("vk.com/idwok")) {
            return var0.contains("reallyworld") ? "ReallyWorld" : "Vanilla";
         } else {
            return "HolyWorld";
         }
      } else {
         return "Vanilla";
      }
   }

   private static int getAnarchyFromScoreboard() {
      Scoreboard var0 = mc.world.getScoreboard();
      ScoreboardObjective var1 = var0.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
      String var2 = server;
      switch (var2) {
         case "FunTime":
            if (var1 != null) {
               String[] var9 = var1.getDisplayName().getString().split("-");
               if (var9.length > 1) {
                  return Integer.parseInt(var9[1]);
               }
            }
            break;
         case "HolyWorld":
            for (ScoreboardEntry var6 : var0.getScoreboardEntries(var1)) {
               String var7 = Team.decorateName(var0.getScoreHolderTeam(var6.owner()), var6.name()).getString();
               if (!var7.isEmpty()) {
                  String var8 = StringUtils.substringBetween(var7, "#", " -\u25c6-");
                  if (var8 != null && !var8.isEmpty()) {
                     return Integer.parseInt(var8.replace(" (1.20)", ""));
                  }
               }
            }
      }

      return -1;
   }

   public static boolean isPvp() {
      return !pvpWatch.every(500.0);
   }

   private static boolean hasBossBarPvp() {
      return mc.inGameHud
         .getBossBarHud()
         .bossBars
         .values()
         .stream()
         .map(var0 -> var0.getName().getString().toLowerCase())
         .anyMatch(var0 -> var0.contains("pvp") || var0.contains("\u043f\u0432\u043f"));
   }

   private static boolean hasScoreboardPvp() {
      return mc.inGameHud
         .getBossBarHud()
         .bossBars
         .values()
         .stream()
         .map(var0 -> var0.getName().getString().toLowerCase())
         .anyMatch(var0 -> (var0.contains("pvp") || var0.contains("\u043f\u0432\u043f")) && (var0.contains("0") || var0.contains("1")));
   }

   public static String getWorldType() {
      return mc.world.getRegistryKey().getValue().getPath();
   }

   public static boolean isCopyTime() {
      return server.equals("CopyTime") || server.equals("SpookyTime") || server.equals("FunTime");
   }

   public static boolean isFunTime() {
      return server.equals("FunTime");
   }

   public static boolean isReallyWorld() {
      return server.equals("ReallyWorld");
   }

   public static boolean isHolyWorld() {
      return server.equals("HolyWorld");
   }

   public static boolean isSpookyTime() {
      return server.equals("Vanilla");
   }

   private ServerUtil() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static int getAnarchy() {
      return anarchy;
   }

   public static boolean isPvpState() {
      return pvpState;
   }
}
