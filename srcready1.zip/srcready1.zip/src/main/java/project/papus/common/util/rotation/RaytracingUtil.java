package project.papus.common.util.rotation;

public class RaytracingUtil {
   public static final RaytracingUtil DEFAULT = new RaytracingUtil(false, false);
   private final boolean moveCorrection;
   private final boolean freeCorrection;

   public RaytracingUtil(boolean var1, boolean var2) {
      this.moveCorrection = var1;
      this.freeCorrection = var2;
   }

   public boolean isMoveCorrection() {
      return this.moveCorrection;
   }

   public boolean isFreeCorrection() {
      return this.freeCorrection;
   }
}
