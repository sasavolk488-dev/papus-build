package project.papus.common;

import java.util.Arrays;
import java.util.stream.Stream;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public interface QuickLogger {
   static Text getPrefix() {
      MutableText var0 = Text.literal("[CMD" + Formatting.RESET + "]");
      var0.setStyle(var0.getStyle().withColor(Formatting.WHITE));
      var0.append(" -> ");
      return var0;
   }

   default void logDirect(Text... var1) {
      MutableText var2 = Text.literal("");
      var2.append(getPrefix());
      var2.append(Text.literal(" "));
      Arrays.asList(var1).forEach(var2::append);
      if (MinecraftClient.getInstance().player != null) {
         MinecraftClient.getInstance().inGameHud.getChatHud().addMessage(var2);
      }
   }

   default void logDirect(String var1, Formatting var2) {
      Stream.of(var1.split("\n")).forEach(var2x -> {
         MutableText var3 = Text.literal(var2x.replace("\t", "    "));
         var3.setStyle(var3.getStyle().withColor(var2));
         this.logDirect(var3);
      });
   }

   default void logDirect(String var1) {
      this.logDirect(var1, Formatting.GRAY);
   }
}
