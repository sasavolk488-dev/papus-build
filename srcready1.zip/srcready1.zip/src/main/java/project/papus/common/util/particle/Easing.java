package project.papus.common.util.particle;

@FunctionalInterface
public interface Easing {
   double ease(double var1);
}
