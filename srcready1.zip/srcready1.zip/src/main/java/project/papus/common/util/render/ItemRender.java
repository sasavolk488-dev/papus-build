package project.papus.common.util.render;

import java.util.HashMap;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.math.ColorHelper;
import project.papus.api.system.font.FontRenderer;
import project.papus.api.system.font.Fonts;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.QuickImports;
import project.papus.common.util.color.ColorUtil;

public final class ItemRender implements QuickImports {
   public static final HashMap<ItemStack, ItemRender.CachedSprite> SPRITE_CACHE = new HashMap<>();

   public static void drawItem(MatrixStack var0, ItemStack var1, float var2, float var3, boolean var4, boolean var5) {
      ItemRender.CachedSprite var6 = getSpriteTexture(var1);
      if (var6 != null) {
         Render2DUtil.drawSprite(var0, var6.sprite, var2, var3, 16.0F, 16);
      }

      if (var4) {
         drawStackCount(var0, var1, var2, var3);
      }

      if (var5) {
         drawItemBar(var0, var1, var2, var3);
      }
   }

   private static void drawStackCount(MatrixStack var0, ItemStack var1, float var2, float var3) {
      int var4 = var1.getCount();
      String var5 = var4 > 1 ? var4 + "" : "";
      if (!var5.isEmpty()) {
         FontRenderer var6 = Fonts.getSize(16);
         var6.drawString(var0, var5, var2 + 16.0F - var6.getStringWidth(var5), var3 + 11.0F, ColorUtil.getTextColor());
      }
   }

   private static void drawItemBar(MatrixStack var0, ItemStack var1, float var2, float var3) {
      if (var1.isItemBarVisible()) {
         rectangle.render(ShapeProperties.create(var0, var2 + 1.5F, var3 + 13.0F, 13.0, 2.0).color(-16777216).build());
         rectangle.render(
            ShapeProperties.create(var0, var2 + 1.5F, var3 + 13.0F, var1.getItemBarStep(), 1.0).color(ColorHelper.fullAlpha(var1.getItemBarColor())).build()
         );
      }
   }

   private static ItemRender.CachedSprite getSpriteTexture(ItemStack var0) {
      return SPRITE_CACHE.computeIfAbsent(var0, var1 -> {
         ItemRenderState var2 = new ItemRenderState();
         mc.getItemModelManager().update(var2, var0, ModelTransformationMode.GUI, mc.world, null, 0);
         Sprite var3 = extractSprite(var2);
         if (var3 != null) {
            int var4 = mc.getTextureManager().getTexture(var3.getAtlasId()).getGlId();
            return new ItemRender.CachedSprite(var3, var4, 16777215);
         } else {
            return null;
         }
      });
   }

   private static Sprite extractSprite(ItemRenderState var0) {
      BakedModel var1 = var0.layers[0].model;
      return var0.layerCount != 0 && var1 != null ? var1.getParticleSprite() : null;
   }

   private ItemRender() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public record CachedSprite(Sprite sprite, int glId, int color) {
   }
}
