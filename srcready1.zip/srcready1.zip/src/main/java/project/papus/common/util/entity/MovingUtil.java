package project.papus.common.util.entity;

import java.util.Objects;
import net.minecraft.entity.Entity;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import project.papus.common.QuickImports;

public final class MovingUtil implements QuickImports {
   public static boolean hasPlayerMovement() {
      return mc.player.input.movementForward != 0.0F || mc.player.input.movementSideways != 0.0F;
   }

   public static double[] calculateDirection(double var0) {
      return calculateDirection(mc.player.input.movementForward, mc.player.input.movementSideways, var0);
   }

   public static double[] calculateDirection(float var0, float var1, double var2) {
      float var4 = mc.player.getYaw();
      if (var0 != 0.0F) {
         if (var1 > 0.0F) {
            var4 += var0 > 0.0F ? -45.0F : 45.0F;
         } else if (var1 < 0.0F) {
            var4 += var0 > 0.0F ? 45.0F : -45.0F;
         }

         var1 = 0.0F;
         var0 = var0 > 0.0F ? 1.0F : -1.0F;
      }

      double var5 = Math.sin(Math.toRadians(var4 + 90.0F));
      double var7 = Math.cos(Math.toRadians(var4 + 90.0F));
      double var9 = var0 * var2 * var7 + var1 * var2 * var5;
      double var11 = var0 * var2 * var5 - var1 * var2 * var7;
      return new double[]{var9, var11};
   }

   public static double getSpeed(Entity var0) {
      return Math.sqrt(var0.squaredDistanceTo(new Vec3d(var0.prevX, var0.prevY, var0.prevZ)));
   }

   public static void setVelocity(double var0) {
      double[] var2 = calculateDirection(var0);
      Objects.requireNonNull(mc.player).setVelocity(var2[0], mc.player.getVelocity().getY(), var2[1]);
   }

   public static void setVelocity(double var0, double var2) {
      double[] var4 = calculateDirection(var0);
      Objects.requireNonNull(mc.player).setVelocity(var4[0], var2, var4[1]);
   }

   public static double getDegreesRelativeToView(Vec3d var0, float var1) {
      float var2 = (float)Math.atan2(-var0.x, var0.z);
      double var3 = Math.toRadians(MathHelper.wrapDegrees(var1));
      return Math.toDegrees(MathHelper.wrapDegrees(var2 - var3));
   }

   public static PlayerInput setDirection(PlayerInput var0, double var1, float var3) {
      boolean var4 = var0.forward();
      boolean var5 = var0.backward();
      boolean var6 = var0.left();
      boolean var7 = var0.right();
      if (var1 >= -90.0F + var3 && var1 <= 90.0F - var3) {
         var4 = true;
      } else if (var1 < -90.0F - var3 || var1 > 90.0F + var3) {
         var5 = true;
      }

      if (var1 >= 0.0F + var3 && var1 <= 180.0F - var3) {
         var7 = true;
      } else if (var1 >= -180.0F + var3 && var1 <= 0.0F - var3) {
         var6 = true;
      }

      return new PlayerInput(var4, var5, var6, var7, var0.jump(), var0.sneak(), var0.sprint());
   }

   public static PlayerInput setDirection(PlayerInput var0, double var1) {
      return setDirection(var0, var1, 20.0F);
   }

   private MovingUtil() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
