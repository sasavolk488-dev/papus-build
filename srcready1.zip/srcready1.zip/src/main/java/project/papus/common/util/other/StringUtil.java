package project.papus.common.util.other;

import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import project.papus.api.system.font.Fonts;
import project.papus.common.util.entity.PlayerHealthUtil;

public final class StringUtil {
   public static String randomString(int length) {
      return IntStream.range(0, length).mapToObj(i -> String.valueOf((char)new Random().nextInt(97, 123))).collect(Collectors.joining());
   }

   public static String getBindName(int key) {
      return key < 0
         ? "N/A"
         : PlayerHealthUtil.getKeyType(key)
            .createFromCode(key)
            .getTranslationKey()
            .replace("key.keyboard.", "")
            .replace("key.mouse.", "mouse ")
            .replace(".", " ")
            .toUpperCase();
   }

   public static String getShortBindName(int key) {
      String name = getBindName(key);
      if ("N/A".equals(name)) {
         return name;
      } else {
         return switch (name) {
            case "LEFT ALT" -> "LA";
            case "RIGHT ALT" -> "RA";
            case "LEFT SHIFT" -> "LS";
            case "RIGHT SHIFT" -> "RS";
            case "LEFT CONTROL" -> "LC";
            case "RIGHT CONTROL" -> "RC";
            case "LEFT WIN" -> "LW";
            case "RIGHT WIN" -> "RW";
            case "CAPS LOCK" -> "CAPS";
            case "NUM LOCK" -> "NUM";
            case "SCROLL LOCK" -> "SCR";
            case "PRINT SCREEN" -> "PRT";
            case "PAGE UP" -> "PUP";
            case "PAGE DOWN" -> "PDN";
            case "INSERT" -> "INS";
            case "DELETE" -> "DEL";
            case "HOME" -> "HM";
            case "END" -> "END";
            case "BACKSPACE" -> "BS";
            case "ENTER" -> "ENT";
            case "ESCAPE" -> "ESC";
            case "SPACE" -> "SPC";
            case "TAB" -> "TAB";
            case "MENU" -> "MNU";
            case "PAUSE" -> "PAU";
            case "MOUSE LEFT" -> "M1";
            case "MOUSE RIGHT" -> "M2";
            case "MOUSE MIDDLE" -> "M3";
            case "MOUSE 4" -> "M4";
            case "MOUSE 5" -> "M5";
            case "MOUSE 6" -> "M6";
            case "MOUSE 7" -> "M7";
            case "MOUSE 8" -> "M8";
            default -> {
               if (name.length() > 8 && name.split(" ").length > 1) {
                  String[] parts = name.split(" ");
                  StringBuilder sb = new StringBuilder();
                  for (String part : parts) {
                     if (!part.isEmpty()) {
                        sb.append(part.charAt(0));
                     }
                  }
                  yield sb.toString();
               } else {
                  yield name;
               }
            }
         };
      }
   }

   public static String wrap(String text, int width, int fontSize) {
      String[] words = text.split(" ");
      StringBuilder sb = new StringBuilder();
      float lineWidth = 0.0F;

      for (String word : words) {
         float wordWidth = Fonts.getSize(fontSize).getStringWidth(word);
         if (lineWidth + wordWidth > width) {
            sb.append("\n");
            lineWidth = 0.0F;
         } else if (lineWidth > 0.0F) {
            sb.append(" ");
            lineWidth += Fonts.getSize(fontSize).getStringWidth(" ");
         }

         sb.append(word);
         lineWidth += wordWidth;
      }

      return sb.toString();
   }

   public static String getUserRole() {
      return "USER";
   }

   public static String getDuration(int seconds) {
      int minutes = seconds / 60;
      String sec = String.format("%02d", seconds % 60);
      return minutes + ":" + sec;
   }

   private StringUtil() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
