package project.papus.common.util.logger;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LoggerUtil {
   private static final Logger LOGGER = LogManager.getLogger(LoggerUtil.class);

   public static void info(Object var0) {
      LOGGER.info("\u001b[0;30m\u001b[42m" + var0 + "\u001b[0m");
   }

   public static void info(Object var0, Throwable var1) {
      LOGGER.info("\u001b[0;30m\u001b[42m" + var0 + "\u001b[0m", var1);
   }

   public static void info(Object var0, Object var1) {
      LOGGER.info("\u001b[0;30m\u001b[42m" + var0 + "\u001b[0m", var1);
   }

   public static void warn(Object var0) {
      LOGGER.warn("\u001b[0;30m\u001b[43m" + var0 + "\u001b[0m");
   }

   public static void warn(Object var0, Throwable var1) {
      LOGGER.warn("\u001b[0;30m\u001b[43m" + var0 + "\u001b[0m", var1);
   }

   public static void warn(Object var0, Object var1) {
      LOGGER.warn("\u001b[0;30m\u001b[43m" + var0 + "\u001b[0m", var1);
   }

   public static void error(Object var0) {
      LOGGER.error("\u001b[0;30m\u001b[41m" + var0 + "\u001b[0m");
   }

   public static void error(Object var0, Throwable var1) {
      LOGGER.error("\u001b[0;30m\u001b[41m" + var0 + "\u001b[0m", var1);
   }

   public void error(Object var1, Object var2) {
      LOGGER.error("\u001b[0;30m\u001b[41m" + var1 + "\u001b[0m", var2);
   }
}
