package project.papus.common.util.math;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3d;
import project.papus.common.QuickImports;

public final class MathUtil implements QuickImports {
   public static double PI2 = Math.PI * 2;

   public static boolean isHovered(double var0, double var2, double var4, double var6, double var8, double var10) {
      return var0 >= var4 && var0 <= var4 + var8 && var2 >= var6 && var2 <= var6 + var10;
   }

   public static double computeGcd() {
      return Math.pow((Double)mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2, 3.0) * 1.2;
   }

   public static int getRandom(int var0, int var1) {
      return (int)getRandom((float)var0, var1 + 1.0F);
   }

   public static float getRandom(float var0, float var1) {
      return (float)getRandom((double)var0, (double)var1);
   }

   public static double getRandom(double var0, double var2) {
      if (var0 == var2) {
         return var0;
      } else {
         if (var0 > var2) {
            double var4 = var0;
            var0 = var2;
            var2 = var4;
         }

         return ThreadLocalRandom.current().nextDouble(var0, var2);
      }
   }

   public static void scale(MatrixStack var0, float var1, float var2, float var3, Runnable var4) {
      if (var3 != 1.0F) {
         float var5 = 0.5F + var3 / 2.0F;
         var0.push();
         var0.translate(var1, var2, 0.0F);
         var0.scale(var5, var5, 1.0F);
         var0.translate(-var1, -var2, 0.0F);
         setAlpha(var3, var4);
         var0.pop();
      } else {
         var4.run();
      }
   }

   public static void scale(MatrixStack var0, float var1, float var2, float var3, float var4, Runnable var5) {
      float var6 = var3 * var4;
      if (var6 != 1.0F) {
         var0.push();
         var0.translate(var1, var2, 0.0F);
         var0.scale(var3, var4, 1.0F);
         var0.translate(-var1, -var2, 0.0F);
         setAlpha(var6, var5);
         var0.pop();
      } else {
         var5.run();
      }
   }

   public static float round(double var0, float var2) {
      float var3 = (float)(System.currentTimeMillis() % var0 / (var0 / var2));
      if (var3 > var2 / 2.0F) {
         var3 = var2 - var3;
      }

      return var3;
   }

   public static float sinWave(float var0) {
      int var1 = (int)(var0 * 75.0F);
      return (float)MathHelper.clamp(System.currentTimeMillis() % var1 * Math.PI / var1, 0.0, 1.0) * var0;
   }

   public static void setAlpha(float var0, Runnable var1) {
      scissor(1.0F, 1.0F, 1.0F, var0, var1);
   }

   public static void scissor(float var0, float var1, float var2, float var3, Runnable var4) {
      RenderSystem.setShaderColor(
         MathHelper.clamp(var0, 0.0F, 1.0F), MathHelper.clamp(var1, 0.0F, 1.0F), MathHelper.clamp(var2, 0.0F, 1.0F), MathHelper.clamp(var3, 0.0F, 1.0F)
      );
      var4.run();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   public static double round(double var0, double var2) {
      double var4 = Math.round(var0 / var2) * var2;
      return Math.round(var4 * 100.0) / 100.0;
   }

   public static int randomInt(int var0, int var1) {
      return var1 * (int)Math.floor((double)var0 / var1);
   }

   public static int getRed(int var0) {
      return var0 >> 16 & 0xFF;
   }

   public static int getGreen(int var0) {
      return var0 >> 8 & 0xFF;
   }

   public static int getBlue(int var0) {
      return var0 & 0xFF;
   }

   public static int getAlpha(int var0) {
      return var0 >> 24 & 0xFF;
   }

   public static int applyOpacity(int var0, float var1) {
      return ColorHelper.getArgb((int)(getAlpha(var0) * var1 / 255.0F), getRed(var0), getGreen(var0), getBlue(var0));
   }

   public static Vec3d getMousePos(int var0, int var1, double var2) {
      int var4 = Math.min(var0, var1);
      float var5 = (float)(Math.cos(var4 * PI2 / var1) * var2);
      float var6 = (float)(-Math.sin(var4 * PI2 / var1) * var2);
      return new Vec3d(var5, 0.0, var6);
   }

   public static double getTimeDelta(double var0) {
      return Math.abs(1.0 + Math.sin(var0)) / 2.0;
   }

   public static Vector3d interpolate(Vector3d var0, Vector3d var1) {
      return new Vector3d(interpolate(var0.x, var1.x), interpolate(var0.y, var1.y), interpolate(var0.z, var1.z));
   }

   public static Vec3d interpolate(Vec3d var0, Vec3d var1) {
      return new Vec3d(interpolate(var0.x, var1.x), interpolate(var0.y, var1.y), interpolate(var0.z, var1.z));
   }

   public static Vec3d interpolate(Entity var0) {
      return var0 == null
         ? Vec3d.ZERO
         : new Vec3d(interpolate(var0.prevX, var0.getX()), interpolate(var0.prevY, var0.getY()), interpolate(var0.prevZ, var0.getZ()));
   }

   public static float interpolate(float var0, float var1) {
      return MathHelper.lerp(renderTickCounter.getTickDelta(false), var0, var1);
   }

   public static double interpolate(double var0, double var2) {
      return MathHelper.lerp(renderTickCounter.getTickDelta(false), var0, var2);
   }

   public static int interpolateSmooth(double var0, int var2, int var3) {
      return (int)MathHelper.lerp(renderTickCounter.getLastDuration() / var0, var2, var3);
   }

   public static float interpolateSmooth(double var0, float var2, float var3) {
      return (float)MathHelper.lerp(renderTickCounter.getLastDuration() / var0, var2, var3);
   }

   public static double interpolateSmooth(double var0, double var2, double var4) {
      return MathHelper.lerp(renderTickCounter.getLastDuration() / var0, var2, var4);
   }

   private MathUtil() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
