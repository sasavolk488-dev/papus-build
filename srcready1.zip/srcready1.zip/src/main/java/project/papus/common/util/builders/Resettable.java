package project.papus.common.util.builders;

public interface Resettable {
   Resettable position(float var1, float var2);

   Resettable size(float var1, float var2);
}
