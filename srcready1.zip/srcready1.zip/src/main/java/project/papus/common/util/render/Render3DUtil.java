package project.papus.common.util.render;

import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.ProjectionType;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Pair;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4i;
import org.lwjgl.opengl.GL11;
import project.papus.common.QuickImports;
import project.papus.common.util.color.ColorUtil;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.math.ProjectionUtil;
import project.papus.implement.events.render.WorldRenderEvent;

public final class Render3DUtil implements QuickImports {
   private static final Map<VoxelShape, Pair<List<Box>, List<Render3DUtil.Line>>> SHAPE_BOXES = new HashMap<>();
   private static final Map<VoxelShape, List<Box>> SHAPE_OUTLINES = new HashMap<>();
   public static final List<Render3DUtil.Texture> TEXTURE_DEPTH = new ArrayList<>();
   public static final List<Render3DUtil.Texture> TEXTURE = new ArrayList<>();
   public static final List<Render3DUtil.Line> LINE_DEPTH = new ArrayList<>();
   public static final List<Render3DUtil.Line> LINE = new ArrayList<>();
   public static final List<Render3DUtil.Quad> QUAD_DEPTH = new ArrayList<>();
   public static final List<Render3DUtil.Quad> QUAD = new ArrayList<>();
   public static final List<Render3DUtil.Quad> SHINE_QUAD = new ArrayList<>();
   public static final List<Render3DUtil.Line> SHINE_LINE = new ArrayList<>();
   public static Matrix4f lastProjMat = new Matrix4f();
   public static Entry lastModMat = new MatrixStack().peek();
   private static final Identifier captureId = Identifier.of("textures/capture.png");
   private static final Identifier bloomId = Identifier.of("textures/bloom.png");
   private static float espValue = 1.0F;
   private static float espSpeed = 1.0F;
   private static float prevEspValue;
   private static float circleStep;
   private static boolean flipSpeed;

   public static void onWorldRender(WorldRenderEvent var0) {
      if (!TEXTURE.isEmpty()) {
         Set<Identifier> var1 = TEXTURE.stream().map(var0x -> var0x.id).collect(Collectors.toCollection(LinkedHashSet::new));
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
         var1.forEach(
            var0x -> {
               RenderSystem.setShaderTexture(0, var0x);
               RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
               BufferBuilder var1x = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
               TEXTURE.stream()
                  .filter(var1xx -> var1xx.id.equals(var0x))
                  .forEach(var1xx -> quadTexture(var1xx.entry, var1x, var1xx.x, var1xx.y, var1xx.width, var1xx.height, var1xx.color));
               BufferRenderer.drawWithGlobalProgram(var1x.end());
            }
         );
         RenderSystem.disableBlend();
         TEXTURE.clear();
      }

      if (!TEXTURE_DEPTH.isEmpty()) {
         Set<Identifier> var2 = TEXTURE_DEPTH.stream().map(var0x -> var0x.id).collect(Collectors.toCollection(LinkedHashSet::new));
         RenderSystem.enableBlend();
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
         var2.forEach(
            var0x -> {
               RenderSystem.setShaderTexture(0, var0x);
               RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
               BufferBuilder var1x = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
               TEXTURE_DEPTH.stream()
                  .filter(var1xx -> var1xx.id.equals(var0x))
                  .forEach(var1xx -> quadTexture(var1xx.entry, var1x, var1xx.x, var1xx.y, var1xx.width, var1xx.height, var1xx.color));
               BufferRenderer.drawWithGlobalProgram(var1x.end());
            }
         );
         RenderSystem.depthMask(true);
         RenderSystem.disableBlend();
         TEXTURE_DEPTH.clear();
      }

      if (!LINE.isEmpty()) {
         GL11.glEnable(2881);
         Set<Float> var3 = LINE.stream().map(var0x -> var0x.width).collect(Collectors.toCollection(LinkedHashSet::new));
         RenderSystem.enableBlend();
         RenderSystem.disableCull();
         RenderSystem.disableDepthTest();
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
         RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);
         var3.forEach(
            var0x -> {
               RenderSystem.lineWidth(var0x);
               BufferBuilder var1x = QuickImports.tessellator().begin(DrawMode.LINES, VertexFormats.LINES);
               LINE.stream()
                  .filter(var1xx -> var1xx.width == var0x)
                  .forEach(var1xx -> vertexLine(var1xx.entry, var1x, var1xx.start.toVector3f(), var1xx.end.toVector3f(), var1xx.colorStart, var1xx.colorEnd));
               BufferRenderer.drawWithGlobalProgram(var1x.end());
            }
         );
         RenderSystem.enableDepthTest();
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         LINE.clear();
         GL11.glDisable(2881);
      }

      if (!QUAD.isEmpty()) {
         RenderSystem.enableBlend();
         RenderSystem.disableCull();
         RenderSystem.disableDepthTest();
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
         RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
         BufferBuilder var4 = QuickImports.tessellator().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
         QUAD.forEach(var1x -> quad(var1x.entry, var4, var1x.x, var1x.y, var1x.w, var1x.z, var1x.color));
         BufferRenderer.drawWithGlobalProgram(var4.end());
         RenderSystem.enableDepthTest();
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         QUAD.clear();
      }

      if (!LINE_DEPTH.isEmpty()) {
         GL11.glEnable(2881);
         Set<Float> var5 = LINE_DEPTH.stream().map(var0x -> var0x.width).collect(Collectors.toCollection(LinkedHashSet::new));
         RenderSystem.enableBlend();
         RenderSystem.disableCull();
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
         RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);
         var5.forEach(
            var0x -> {
               RenderSystem.lineWidth(var0x);
               BufferBuilder var1x = QuickImports.tessellator().begin(DrawMode.LINES, VertexFormats.LINES);
               LINE_DEPTH.stream()
                  .filter(var1xx -> var1xx.width == var0x)
                  .forEach(var1xx -> vertexLine(var1xx.entry, var1x, var1xx.start.toVector3f(), var1xx.end.toVector3f(), var1xx.colorStart, var1xx.colorEnd));
               BufferRenderer.drawWithGlobalProgram(var1x.end());
            }
         );
         RenderSystem.depthMask(true);
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         LINE_DEPTH.clear();
         GL11.glDisable(2881);
      }

      if (!QUAD_DEPTH.isEmpty()) {
         RenderSystem.enableBlend();
         RenderSystem.disableCull();
         RenderSystem.enableDepthTest();
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
         RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
         BufferBuilder var6 = QuickImports.tessellator().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
         QUAD_DEPTH.forEach(var1x -> quad(var1x.entry, var6, var1x.x, var1x.y, var1x.w, var1x.z, var1x.color));
         BufferRenderer.drawWithGlobalProgram(var6.end());
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         QUAD_DEPTH.clear();
      }
   }

   public static void onWorldRenderEnd() {
      if (!SHINE_QUAD.isEmpty() || !SHINE_LINE.isEmpty()) {
         RenderSystem.setProjectionMatrix(lastProjMat, ProjectionType.PERSPECTIVE);
         RenderSystem.enableBlend();
         RenderSystem.disableCull();
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
         if (!SHINE_QUAD.isEmpty()) {
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferBuilder var0 = QuickImports.tessellator().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            SHINE_QUAD.forEach(var1x -> quad(var1x.entry, var0, var1x.x, var1x.y, var1x.w, var1x.z, var1x.color));
            BufferRenderer.drawWithGlobalProgram(var0.end());
            SHINE_QUAD.clear();
         }

         if (!SHINE_LINE.isEmpty()) {
            GL11.glEnable(2881);
            Set<Float> var1 = SHINE_LINE.stream().map(var0x -> var0x.width).collect(Collectors.toCollection(LinkedHashSet::new));
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(ShaderProgramKeys.RENDERTYPE_LINES);
            var1.forEach(
               var0x -> {
                  RenderSystem.lineWidth(var0x);
                  BufferBuilder var1x = QuickImports.tessellator().begin(DrawMode.LINES, VertexFormats.LINES);
                  SHINE_LINE.stream()
                     .filter(var1xx -> var1xx.width == var0x)
                     .forEach(var1xx -> vertexLine(var1xx.entry, var1x, var1xx.start.toVector3f(), var1xx.end.toVector3f(), var1xx.colorStart, var1xx.colorEnd));
                  BufferRenderer.drawWithGlobalProgram(var1x.end());
               }
            );
            SHINE_LINE.clear();
            GL11.glDisable(2881);
         }

         RenderSystem.enableDepthTest();
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
      }
   }

   public static void drawShape(BlockPos var0, VoxelShape var1, int var2, float var3) {
      drawShape(var0, var1, var2, var3, true, false);
   }

   public static void drawShape(BlockPos var0, VoxelShape var1, int var2, float var3, boolean var4, boolean var5) {
      if (SHAPE_OUTLINES.containsKey(var1)) {
         SHAPE_OUTLINES.get(var1).forEach(var5x -> {
            var5x = var5x.offset(var0);
            if (ProjectionUtil.canSee(var5x)) {
               drawBox(var5x, var2, var3, true, var4, var5);
            }
         });
      } else {
         SHAPE_OUTLINES.put(var1, var1.getBoundingBoxes());
      }
   }

   public static void drawShapeAlternative(BlockPos var0, VoxelShape var1, int var2, float var3, boolean var4, boolean var5) {
      int var6 = var4 ? ColorUtil.setAlpha(var2, 0.1F) : 0;
      drawShape(var0, var1, var2, var6, var3, var4, var5);
   }

   public static void drawShape(BlockPos var0, VoxelShape var1, int var2, int var3, float var4, boolean var5, boolean var6) {
      Vec3d var7 = Vec3d.of(var0);
      if (ProjectionUtil.canSee(new Box(var0))) {
         if (SHAPE_BOXES.containsKey(var1)) {
            Pair<List<Box>, List<Render3DUtil.Line>> var9 = SHAPE_BOXES.get(var1);
            if (var5 && var3 != 0) {
               var9.getLeft().forEach(var5x -> drawBox(null, var5x.offset(var7), var2, var3, var4, false, true, var6));
            }

            var9.getRight().forEach(var4x -> drawLine(var4x.start.add(var7), var4x.end.add(var7), var2, var4, var6));
            return;
         }

         List<Render3DUtil.Line> var8 = new ArrayList<>();
         var1.forEachEdge(
            (var1x, var3x, var5x, var7x, var9x, var11) -> var8.add(
               new Render3DUtil.Line(null, new Vec3d(var1x, var3x, var5x), new Vec3d(var7x, var9x, var11), 0, 0, 0.0F)
            )
         );
         SHAPE_BOXES.put(var1, new Pair<>(var1.getBoundingBoxes(), var8));
      }
   }

   public static void drawBox(Box var0, int var1, float var2) {
      drawBox(var0, var1, var2, true, true, false);
   }

   public static void drawBox(Box var0, int var1, float var2, boolean var3, boolean var4, boolean var5) {
      drawBox(null, var0, var1, var2, var3, var4, var5);
   }

   public static void drawBox(Entry var0, Box var1, int var2, int var3, float var4, boolean var5, boolean var6, boolean var7) {
      var1 = var1.expand(0.001);
      double var8 = var1.minX;
      double var10 = var1.minY;
      double var12 = var1.minZ;
      double var14 = var1.maxX;
      double var16 = var1.maxY;
      double var18 = var1.maxZ;
      if (var6) {
         drawQuad(
            var0, new Vec3d(var8, var10, var12), new Vec3d(var14, var10, var12), new Vec3d(var14, var10, var18), new Vec3d(var8, var10, var18), var3, var7
         );
         drawQuad(
            var0, new Vec3d(var8, var10, var12), new Vec3d(var8, var16, var12), new Vec3d(var14, var16, var12), new Vec3d(var14, var10, var12), var3, var7
         );
         drawQuad(
            var0, new Vec3d(var14, var10, var12), new Vec3d(var14, var16, var12), new Vec3d(var14, var16, var18), new Vec3d(var14, var10, var18), var3, var7
         );
         drawQuad(
            var0, new Vec3d(var8, var10, var18), new Vec3d(var14, var10, var18), new Vec3d(var14, var16, var18), new Vec3d(var8, var16, var18), var3, var7
         );
         drawQuad(var0, new Vec3d(var8, var10, var12), new Vec3d(var8, var10, var18), new Vec3d(var8, var16, var18), new Vec3d(var8, var16, var12), var3, var7);
         drawQuad(
            var0, new Vec3d(var8, var16, var12), new Vec3d(var8, var16, var18), new Vec3d(var14, var16, var18), new Vec3d(var14, var16, var12), var3, var7
         );
      }

      if (var5) {
         drawLine(var0, var8, var10, var12, var14, var10, var12, var2, var4, var7);
         drawLine(var0, var14, var10, var12, var14, var10, var18, var2, var4, var7);
         drawLine(var0, var14, var10, var18, var8, var10, var18, var2, var4, var7);
         drawLine(var0, var8, var10, var18, var8, var10, var12, var2, var4, var7);
         drawLine(var0, var8, var10, var18, var8, var16, var18, var2, var4, var7);
         drawLine(var0, var8, var10, var12, var8, var16, var12, var2, var4, var7);
         drawLine(var0, var14, var10, var18, var14, var16, var18, var2, var4, var7);
         drawLine(var0, var14, var10, var12, var14, var16, var12, var2, var4, var7);
         drawLine(var0, var8, var16, var12, var14, var16, var12, var2, var4, var7);
         drawLine(var0, var14, var16, var12, var14, var16, var18, var2, var4, var7);
         drawLine(var0, var14, var16, var18, var8, var16, var18, var2, var4, var7);
         drawLine(var0, var8, var16, var18, var8, var16, var12, var2, var4, var7);
      }
   }

   public static void drawBox(Entry var0, Box var1, int var2, float var3, boolean var4, boolean var5, boolean var6) {
      int var7 = var5 ? ColorUtil.setAlpha(var2, 0.1F) : 0;
      drawBox(var0, var1, var2, var7, var3, var4, var5, var6);
   }

   public static void vertexLine(MatrixStack var0, VertexConsumer var1, Vec3d var2, Vec3d var3, int var4, int var5) {
      vertexLine(var0.peek(), var1, var2.toVector3f(), var3.toVector3f(), var4, var5);
   }

   public static void vertexLine(Entry var0, VertexConsumer var1, Vector3f var2, Vector3f var3, int var4, int var5) {
      if (var0 == null) {
         var0 = lastModMat;
      }

      Vector3f var6 = getNormal(var2, var3);
      var1.vertex(var0, var2).color(var4).normal(var0, var6);
      var1.vertex(var0, var3).color(var5).normal(var0, var6);
   }

   public static void quad(Entry var0, VertexConsumer var1, Vec3d var2, Vec3d var3, Vec3d var4, Vec3d var5, int var6) {
      quad(var0, var1, var2.toVector3f(), var3.toVector3f(), var4.toVector3f(), var5.toVector3f(), var6);
   }

   public static void quad(Entry var0, VertexConsumer var1, Vector3f var2, Vector3f var3, Vector3f var4, Vector3f var5, int var6) {
      if (var0 == null) {
         var0 = lastModMat;
      }

      var1.vertex(var0, var2).color(var6);
      var1.vertex(var0, var3).color(var6);
      var1.vertex(var0, var4).color(var6);
      var1.vertex(var0, var5).color(var6);
   }

   public static void quadTexture(Entry var0, BufferBuilder var1, float var2, float var3, float var4, float var5, Vector4i var6) {
      var1.vertex(var0, var2, var3 + var5, 0.0F).texture(0.0F, 0.0F).color(var6.x);
      var1.vertex(var0, var2 + var4, var3 + var5, 0.0F).texture(0.0F, 1.0F).color(var6.y);
      var1.vertex(var0, var2 + var4, var3, 0.0F).texture(1.0F, 1.0F).color(var6.w);
      var1.vertex(var0, var2, var3, 0.0F).texture(1.0F, 0.0F).color(var6.z);
   }

   @NotNull
   public static Vector3f getNormal(Vector3f var0, Vector3f var1) {
      Vector3f var2 = new Vector3f(var0).sub(var1);
      float var3 = MathHelper.sqrt(var2.lengthSquared());
      return var2.div(var3);
   }

   public static void drawSoulsEsp(LivingEntity var0, float var1, float var2) {
      float var3 = 2.2F - var1;
      Camera var4 = mc.getEntityRenderDispatcher().camera;
      Vec3d var5 = MathUtil.interpolate(var0).subtract(var4.getPos());
      MatrixStack var6 = new MatrixStack();
      var6.push();
      var6.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var4.getPitch()));
      var6.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var4.getYaw() + 180.0F));
      var6.translate(var5.x, var5.y + var0.getBoundingBox().getLengthY() / 2.0, var5.z);
      var6.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-var4.getYaw()));
      var6.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var4.getPitch()));
      var6.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(MathUtil.interpolate(prevEspValue, espValue)));
      Entry var7 = var6.peek().copy();
      drawTexture(
         var7,
         captureId,
         -var3 / 2.0F,
         -var3 / 2.0F,
         var3,
         var3,
         ColorUtil.multDark(new Vector4i(ColorUtil.fade(90), ColorUtil.fade(0), ColorUtil.fade(180), ColorUtil.fade(270)), 1.0F + var2 * 10.0F, var1),
         false
      );
      var6.pop();
   }

   public static void drawCube(MatrixStack var0, double var1, double var3, double var5, float var7, int var8) {
      GL11.glEnable(2881);
      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.disableDepthTest();
      RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      BufferBuilder var9 = QuickImports.tessellator().begin(DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
      var9.vertex(var0.peek().getPositionMatrix(), (float)var1, (float)var3, (float)var5).color(var8);
      byte var10 = 32;

      for (int var11 = 0; var11 <= var10; var11++) {
         float var12 = (float)((Math.PI * 2) * var11 / var10);
         float var13 = (float)(var1 + Math.cos(var12) * var7);
         float var14 = (float)(var5 + Math.sin(var12) * var7);
         var9.vertex(var0.peek().getPositionMatrix(), var13, (float)var3, var14).color(var8);
      }

      BufferRenderer.drawWithGlobalProgram(var9.end());
      RenderSystem.enableDepthTest();
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
      GL11.glDisable(2881);
   }

   public static void drawLine(MatrixStack var0, double var1, double var3, double var5, double var7, double var9, double var11, int var13) {
      Box var14 = new Box(var1, var3, var5, var1 + var7, var3 + var9, var5 + var11);
      drawBox(var0.peek(), var14, var13, 1.0F, false, true, false);
   }

   public static void drawCircleEsp(MatrixStack var0, LivingEntity var1, float var2, float var3) {
      double var4 = MathUtil.interpolate(circleStep - 0.15F, circleStep);
      Vec3d var6 = MathUtil.interpolate(var1);
      boolean var7 = Objects.requireNonNull(mc.player).canSee(var1);
      GL11.glEnable(2881);
      if (var7) {
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);
      } else {
         RenderSystem.disableDepthTest();
      }

      RenderSystem.enableBlend();
      RenderSystem.disableCull();
      RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
      BufferBuilder var8 = QuickImports.tessellator().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
      int var9 = 0;

      for (byte var10 = 90; var9 <= var10; var9++) {
         float var11 = var1.getWidth() * 0.9F;
         float var12 = var1.getHeight();
         double var13 = MathUtil.getTimeDelta(var4) * var12;
         double var15 = MathUtil.getTimeDelta(var4 - 0.45) * var12;
         Vec3d var17 = MathUtil.getMousePos(var9, var10, var11);
         Vec3d var18 = MathUtil.getMousePos(var9 + 1, var10, var11);
         int var19 = ColorUtil.saturate(ColorUtil.fade(var9 * 4), 1.0F + var3 * 10.0F);
         vertexLine(
            var0,
            var8,
            var6.add(var17.x, var17.y + var13, var17.z),
            var6.add(var17.x, var17.y + var15, var17.z),
            ColorUtil.setAlpha(var19, 0.6F * var2),
            ColorUtil.setAlpha(var19, 0.0F)
         );
         drawLine(var6.add(var17.x, var17.y + var13, var17.z), var6.add(var18.x, var18.y + var13, var18.z), ColorUtil.setAlpha(var19, var2), 3.0F, var7);
      }

      BufferRenderer.drawWithGlobalProgram(var8.end());
      if (var7) {
         RenderSystem.depthMask(true);
         RenderSystem.disableDepthTest();
      } else {
         RenderSystem.enableDepthTest();
      }

      GL11.glDisable(2881);
   }

   public static void drawGhosts(LivingEntity var0, float var1, float var2, float var3) {
      Camera var4 = mc.getEntityRenderDispatcher().camera;
      Vec3d var5 = MathUtil.interpolate(var0).subtract(var4.getPos());
      boolean var6 = mc.player.canSee(var0);
      double var7 = MathUtil.interpolate((float)(mc.player.age - 1), (float)mc.player.age);
      float var9 = var0.getHeight() / 2.0F + 0.1F;
      float var10 = var0.getWidth();
      short var11 = 255;
      int var12 = (int)(255.0F * (1.0F - var2));
      int var13 = (int)(255.0F * (1.0F - var2));

      for (int var14 = 0; var14 < 3; var14++) {
         int var15 = 0;

         for (byte var16 = 10; var15 <= var16; var15++) {
            double var17 = Math.toRadians(((var15 / 2.0F + var7 * var3) * var16 + var14 * 120) % (var16 * 360));
            double var19 = Math.sin(Math.toRadians(var7 * 2.5 * var3 + var15 * (var14 + var9)) * 2.0) / 2.0;
            float var21 = (float)(var15 + var16) / (var16 + var16);
            MatrixStack var22 = new MatrixStack();
            var22.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var4.getPitch()));
            var22.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(var4.getYaw() + 180.0F));
            var22.translate(var5.x + Math.cos(var17) * var10, var5.y + var9 + var19, var5.z + Math.sin(var17) * var10);
            var22.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-var4.getYaw()));
            var22.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var4.getPitch()));
            Entry var23 = var22.peek().copy();
            int var24 = ColorUtil.getColor(var11, var12, var13, (int)(var21 * var1 * 255.0F));
            float var25 = 0.5F * var21;
            drawTexture(var23, bloomId, -var25 / 2.0F, -var25 / 2.0F, var25, var25, new Vector4i(var24), var6);
         }
      }
   }

   public static void setupGhostsRender() {
      prevEspValue = espValue;
      espValue = espValue + espSpeed;
      if (espSpeed > 25.0F) {
         flipSpeed = true;
      }

      if (espSpeed < -25.0F) {
         flipSpeed = false;
      }

      espSpeed = flipSpeed ? espSpeed - 0.5F : espSpeed + 0.5F;
      circleStep += 0.15F;
   }

   public static void drawLine(Entry var0, double var1, double var3, double var5, double var7, double var9, double var11, int var13, float var14, boolean var15) {
      drawLine(var0, new Vec3d(var1, var3, var5), new Vec3d(var7, var9, var11), var13, var13, var14, var15);
   }

   public static void drawLine(Vec3d var0, Vec3d var1, int var2, float var3, boolean var4) {
      drawLine(null, var0, var1, var2, var2, var3, var4);
   }

   public static void drawLine(Entry var0, Vec3d var1, Vec3d var2, int var3, int var4, float var5, boolean var6) {
      Render3DUtil.Line var7 = new Render3DUtil.Line(var0, var1, var2, var3, var4, var5);
      if (var6) {
         LINE_DEPTH.add(var7);
      } else {
         LINE.add(var7);
      }
   }

   public static void drawQuad(Vec3d var0, Vec3d var1, Vec3d var2, Vec3d var3, int var4, boolean var5) {
      drawQuad(null, var0, var1, var2, var3, var4, var5);
   }

   public static void drawQuad(Entry var0, Vec3d var1, Vec3d var2, Vec3d var3, Vec3d var4, int var5, boolean var6) {
      Render3DUtil.Quad var7 = new Render3DUtil.Quad(var0, var1, var2, var3, var4, var5);
      if (var6) {
         QUAD_DEPTH.add(var7);
      } else {
         QUAD.add(var7);
      }
   }

   public static void drawQuad(Entry var0, Vec3d var1, Vec3d var2, Vec3d var3, Vec3d var4, int var5) {
      SHINE_QUAD.add(new Render3DUtil.Quad(var0, var1, var2, var3, var4, var5));
   }

   public static void drawLine(Entry var0, Vec3d var1, Vec3d var2, int var3, float var4) {
      SHINE_LINE.add(new Render3DUtil.Line(var0, var1, var2, var3, var3, var4));
   }

   public static void drawTexture(Entry var0, Identifier var1, float var2, float var3, float var4, float var5, Vector4i var6, boolean var7) {
      Render3DUtil.Texture var8 = new Render3DUtil.Texture(var0, var1, var2, var3, var4, var5, var6);
      if (var7) {
         TEXTURE_DEPTH.add(var8);
      } else {
         TEXTURE.add(var8);
      }
   }

   public static void renderQueues() {
      if (!TEXTURE.isEmpty()) {
         Set<Identifier> var0 = TEXTURE.stream().map(var0x -> var0x.id).collect(Collectors.toCollection(LinkedHashSet::new));
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
         var0.forEach(
            var0x -> {
               RenderSystem.setShaderTexture(0, var0x);
               RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
               BufferBuilder var1x = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
               TEXTURE.stream()
                  .filter(var1xx -> var1xx.id.equals(var0x))
                  .forEach(var1xx -> quadTexture(var1xx.entry, var1x, var1xx.x, var1xx.y, var1xx.width, var1xx.height, var1xx.color));
               BufferRenderer.drawWithGlobalProgram(var1x.end());
            }
         );
         RenderSystem.disableBlend();
         TEXTURE.clear();
      }

      if (!TEXTURE_DEPTH.isEmpty()) {
         Set<Identifier> var1 = TEXTURE_DEPTH.stream().map(var0x -> var0x.id).collect(Collectors.toCollection(LinkedHashSet::new));
         RenderSystem.enableBlend();
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_CONSTANT_ALPHA);
         var1.forEach(
            var0x -> {
               RenderSystem.setShaderTexture(0, var0x);
               RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
               BufferBuilder var1x = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
               TEXTURE_DEPTH.stream()
                  .filter(var1xx -> var1xx.id.equals(var0x))
                  .forEach(var1xx -> quadTexture(var1xx.entry, var1x, var1xx.x, var1xx.y, var1xx.width, var1xx.height, var1xx.color));
               BufferRenderer.drawWithGlobalProgram(var1x.end());
            }
         );
         RenderSystem.depthMask(true);
         RenderSystem.disableBlend();
         TEXTURE_DEPTH.clear();
      }
   }

   private Render3DUtil() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void setLastProjMat(Matrix4f var0) {
      lastProjMat = var0;
   }

   public static void setLastModMat(Entry var0) {
      lastModMat = var0;
   }

   public record Line(Entry entry, Vec3d start, Vec3d end, int colorStart, int colorEnd, float width) {
   }

   public record Quad(Entry entry, Vec3d x, Vec3d y, Vec3d w, Vec3d z, int color) {
   }

   public record Texture(Entry entry, Identifier id, float x, float y, float width, float height, Vector4i color) {
   }
}
