package project.papus.common.util.task.scripts;

@FunctionalInterface
public interface ScriptAction {
   void perform();
}
