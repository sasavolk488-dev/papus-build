package project.papus.common.util.particle;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4i;
import project.papus.common.util.render.Render3DUtil;

public final class ParticleUtil {
   public static void renderParticles(MatrixStack var0, List<ParticleUtil.Particle> var1, long var2, long var4, double var6) {
      if (!var1.isEmpty()) {
         for (ParticleUtil.Particle var9 : var1) {
            var9.update(true, var6);
            boolean var10 = !var9.getTimer().passed(var2);
            boolean var11 = var9.getTimer().passed(var4);
            if (var10) {
               var9.getAnimation().animate(1.0, 0.4, Easings.CUBIC_BOTH, true);
            } else if (var11) {
               var9.getAnimation().animate(0.0, 0.4, Easings.CUBIC_BOTH, true);
            }

            if (var9.animation.isAlive()) {
               var9.animation.update();
            }

            float var12 = var9.animation.getFloatValue();
            int var13 = (int)(var12 * 255.0F);
            if (var13 > 0) {
               Vec3d var14 = var9.getPos();
               int var15 = withAlpha(var9.getIndex(), var13);
               float var16 = var9.getRotate();
               var0.push();
               var0.translate(var14.x, var14.y, var14.z);
               var0.multiply(var9.mc.gameRenderer.getCamera().getRotation());
               Vector4i var17 = new Vector4i(var15, var15, var15, var15);
               Render3DUtil.drawTexture(var0.peek().copy(), var9.getType().getTexture(), -var16 / 2.0F, -var16 / 2.0F, var16, var16, var17, true);
               var0.pop();
            }
         }
      }
   }

   private static int withAlpha(int var0, int var1) {
      int var2 = var0 >> 16 & 0xFF;
      int var3 = var0 >> 8 & 0xFF;
      int var4 = var0 & 0xFF;
      return var1 << 24 | var2 << 16 | var3 << 8 | var4;
   }

   public static final class Particle {
      final MinecraftClient mc;
      private Box box;
      private final ParticleUtil.ParticleType type;
      private Vec3d pos;
      private Vec3d velocity;
      private final int index;
      private final float rotate;
      private static final double BASE_VELOCITY = 0.05;
      private final double speedMultiplier;
      private final ParticleTimer timer = new ParticleTimer();
      final EaseAnimation animation = new EaseAnimation();

      public Particle(MinecraftClient var1, ParticleUtil.ParticleType var2, Vec3d var3, Vec3d var4, int var5, int var6, int var7, float var8, double var9) {
         this.mc = var1;
         double var11 = var8 / 2.0;
         this.box = new Box(var3.x - var11, var3.y - var11, var3.z - var11, var3.x + var11, var3.y + var11, var3.z + var11);
         this.type = var2;
         this.pos = var3;
         this.velocity = var4.multiply(0.05);
         this.index = var7;
         this.rotate = var8;
         this.speedMultiplier = var9;
         this.timer.reset();
         this.animation.reset(1.0);
      }

      public Box getBox() {
         return this.box;
      }

      public ParticleUtil.ParticleType getType() {
         return this.type;
      }

      public Vec3d getPos() {
         return this.pos;
      }

      public Vec3d getVelocity() {
         return this.velocity;
      }

      public int getIndex() {
         return this.index;
      }

      public float getRotate() {
         return this.rotate;
      }

      public ParticleTimer getTimer() {
         return this.timer;
      }

      public EaseAnimation getAnimation() {
         return this.animation;
      }

      public void update(boolean var1, double var2) {
         if (var1 && this.mc.world != null) {
            double var4 = this.velocity.x * this.velocity.x + this.velocity.y * this.velocity.y + this.velocity.z * this.velocity.z;
            if (var4 > 1.0E-4) {
               if (this.isBlockSolid(this.pos.x, this.pos.y, this.pos.z + this.velocity.z)) {
                  this.velocity = new Vec3d(this.velocity.x * 1.35, this.velocity.y * 1.35, this.velocity.z * -1.1);
               }

               if (this.isBlockSolid(this.pos.x, this.pos.y + this.velocity.y, this.pos.z)) {
                  this.velocity = new Vec3d(this.velocity.x * 1.35, this.velocity.y * -1.1, this.velocity.z * 1.35);
               }

               if (this.isBlockSolid(this.pos.x + this.velocity.x, this.pos.y, this.pos.z)) {
                  this.velocity = new Vec3d(this.velocity.x * -1.1, this.velocity.y * 1.35, this.velocity.z * 1.35);
               }
            }

            double var6 = Math.pow(0.999, var2 * 60.0);
            this.velocity = this.velocity.multiply(var6).subtract(0.0, 2.0E-5, 0.0);
         }

         double var8 = var2 * 60.0 * this.speedMultiplier;
         this.pos = new Vec3d(this.pos.x + this.velocity.x * var8, this.pos.y + this.velocity.y * var8, this.pos.z + this.velocity.z * var8);
         double var9 = this.rotate / 2.0;
         this.box = new Box(this.pos.x - var9, this.pos.y - var9, this.pos.z - var9, this.pos.x + var9, this.pos.y + var9, this.pos.z + var9);
      }

      private boolean isBlockSolid(double var1, double var3, double var5) {
         BlockPos var7 = BlockPos.ofFloored(var1, var3, var5);
         return this.mc.world.getBlockState(var7).isFullCube(this.mc.world, var7);
      }
   }

   public static enum ParticleType {
      CROSS("cross"),
      CROWN("crown"),
      DOLLAR("dollar"),
      HEART("heart"),
      LIGHTNING("lightning"),
      LINE("line"),
      POINT("point"),
      RHOMBUS("rhombus"),
      SNOW("snow"),
      STAR("star"),
      TRIANGLE("triangle");

      private final Identifier texture;

      private ParticleType(String var3) {
         this.texture = Identifier.of("papus", "textures/particles/" + var3 + ".png");
      }

      public Identifier getTexture() {
         return this.texture;
      }
   }
}
