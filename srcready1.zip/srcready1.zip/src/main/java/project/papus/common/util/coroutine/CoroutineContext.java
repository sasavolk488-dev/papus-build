package project.papus.common.util.coroutine;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CoroutineContext {
   private final ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

   public void run(Runnable var1) {
      this.executor.submit(var1);
   }

   public void shutdown() {
      this.executor.shutdown();
   }
}
