package project.papus.common.util.other;

public class ThreadSleepUtil {
   private long startTime = System.currentTimeMillis();

   public void reset() {
      this.startTime = System.currentTimeMillis();
   }

   public boolean hasReached(long var1) {
      return System.currentTimeMillis() - this.startTime >= var1;
   }

   public boolean hasReachedAndReset(long var1) {
      return System.currentTimeMillis() - this.startTime > var1;
   }

   public long getTime() {
      return System.currentTimeMillis() - this.startTime;
   }
}
