package project.papus.common.util.rotation;

public class RotationPlan {
   public boolean isMoveCorrection() {
      return false;
   }

   public boolean isFreeCorrection() {
      return false;
   }
}
