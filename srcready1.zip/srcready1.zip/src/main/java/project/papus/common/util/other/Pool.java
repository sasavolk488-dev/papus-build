package project.papus.common.util.other;

import java.util.ArrayDeque;
import java.util.Queue;
import project.papus.common.util.builders.Builder;

public class Pool<T> {
   private final Queue<T> items = new ArrayDeque<>();
   private final Builder<T> provider;

   public Pool(Builder<T> var1) {
      this.provider = var1;
   }

   public synchronized T get() {
      return !this.items.isEmpty() ? this.items.poll() : this.provider.create();
   }

   public synchronized void free(T var1) {
      this.items.offer((T)var1);
   }
}
