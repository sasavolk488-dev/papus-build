package project.papus.common.util.task.scripts;

import com.google.common.collect.Lists;
import java.util.Collections;
import java.util.List;
import java.util.function.BooleanSupplier;
import project.papus.common.util.other.StopWatch;

public class Script {
   private final StopWatch timeWatch = new StopWatch();
   private final List<Script.TickStep> tickSteps = Lists.newCopyOnWriteArrayList();
   private final List<Script.TimeStep> timeSteps = Lists.newCopyOnWriteArrayList();
   private int currentTickStepIndex;
   private int currentTimeStepIndex;
   private boolean interrupted;
   private Script.LoopTickStrategy loopStrategy = new Script.LoopStrategy(1);

   public Script() {
      this.cleanup();
   }

   public Script addTickStep(int var1, ScriptAction var2) {
      return this.addTickStep(var1, var2, () -> true, 0);
   }

   public Script addTickStep(int var1, ScriptAction var2, BooleanSupplier var3) {
      return this.addTickStep(var1, var2, var3, 0);
   }

   public Script addTickStep(int var1, ScriptAction var2, int var3) {
      return this.addTickStep(var1, var2, () -> true, var3);
   }

   public Script addTickStep(int var1, ScriptAction var2, BooleanSupplier var3, int var4) {
      this.tickSteps.add(new Script.TickStep(var1, var2, var3, var4));
      Collections.sort(this.tickSteps);
      return this;
   }

   public Script addTimeStep(int var1, ScriptAction var2) {
      return this.addTimeStep(var1, var2, () -> true, 0);
   }

   public Script addTimeStep(int var1, ScriptAction var2, BooleanSupplier var3) {
      return this.addTimeStep(var1, var2, var3, 0);
   }

   public Script addTimeStep(int var1, ScriptAction var2, int var3) {
      return this.addTimeStep(var1, var2, () -> true, var3);
   }

   public Script addTimeStep(int var1, ScriptAction var2, BooleanSupplier var3, int var4) {
      this.timeSteps.add(new Script.TimeStep(var1, var2, var3, var4));
      Collections.sort(this.timeSteps);
      return this;
   }

   public void resetTickSteps() {
      this.timeWatch.reset();
   }

   public void resetTimeSteps() {
      this.currentTickStepIndex = 0;
      this.currentTimeStepIndex = 0;
   }

   public Script cleanupIfFinished() {
      if (this.isFinished()) {
         this.cleanup();
      }

      return this;
   }

   public Script cleanup() {
      this.tickSteps.clear();
      this.timeSteps.clear();
      this.resetTickSteps();
      this.resetTimeSteps();
      return this;
   }

   public void update() {
      if ((!this.tickSteps.isEmpty() || !this.timeSteps.isEmpty()) && !this.interrupted) {
         this.tickSteps.forEach(var1 -> {
            if (this.currentTickStepIndex < this.tickSteps.size()) {
               Script.TickStep var2 = this.tickSteps.get(this.currentTickStepIndex);
               if (var2.getCondition().getAsBoolean() && this.timeWatch.every(var2.getTicks())) {
                  var2.getAction().perform();
                  this.currentTickStepIndex++;
                  this.resetTickSteps();
                  if (this.loopStrategy.shouldExecute(this.currentTickStepIndex, this.tickSteps.size())) {
                     this.resetTimeSteps();
                     this.loopStrategy.updateStep();
                  }
               }
            }
         });
         this.timeSteps.forEach(var1 -> {
            if (this.currentTimeStepIndex < this.timeSteps.size()) {
               Script.TimeStep var2 = this.timeSteps.get(this.currentTimeStepIndex);
               if (var2.getCondition().getAsBoolean() && var2.getDelay() <= 0) {
                  var2.getAction().perform();
                  this.currentTimeStepIndex++;
                  this.resetTickSteps();
                  if (this.loopStrategy.shouldExecute(this.currentTimeStepIndex, this.timeSteps.size())) {
                     this.resetTimeSteps();
                     this.loopStrategy.updateStep();
                  }
               }

               var2.startTimer();
            }
         });
         this.currentTickStepIndex = Math.min(this.currentTickStepIndex, this.tickSteps.size());
         this.currentTimeStepIndex = Math.min(this.currentTimeStepIndex, this.timeSteps.size());
      }
   }

   public Script setLoopStrategy(Script.LoopTickStrategy var1) {
      this.loopStrategy = var1;
      return this;
   }

   public boolean isFinished() {
      return this.currentTickStepIndex >= this.tickSteps.size()
         && this.currentTimeStepIndex >= this.timeSteps.size()
         && !this.interrupted
         && this.loopStrategy.isFinished();
   }

   public StopWatch getTimeWatch() {
      return this.timeWatch;
   }

   public List<Script.TickStep> getTickSteps() {
      return this.tickSteps;
   }

   public List<Script.TimeStep> getTimeSteps() {
      return this.timeSteps;
   }

   public int getCurrentTickStepIndex() {
      return this.currentTickStepIndex;
   }

   public int getCurrentTimeStepIndex() {
      return this.currentTimeStepIndex;
   }

   public boolean isInterrupted() {
      return this.interrupted;
   }

   public Script.LoopTickStrategy getLoopStrategy() {
      return this.loopStrategy;
   }

   public void setCurrentTickStepIndex(int var1) {
      this.currentTickStepIndex = var1;
   }

   public void setCurrentTimeStepIndex(int var1) {
      this.currentTimeStepIndex = var1;
   }

   public void setInterrupted(boolean var1) {
      this.interrupted = var1;
   }

   public static class DefaultStrategy implements Script.LoopTickStrategy {
      @Override
      public boolean shouldExecute(int var1, int var2) {
         return var1 >= var2;
      }

      @Override
      public void updateStep() {
      }

      @Override
      public boolean isFinished() {
         return false;
      }
   }

   public static class LoopStrategy implements Script.LoopTickStrategy {
      private final int totalIterations;
      private int currentIteration;

      public LoopStrategy(int var1) {
         this.totalIterations = var1 - 1;
      }

      @Override
      public boolean shouldExecute(int var1, int var2) {
         return var1 >= var2 && this.currentIteration < this.totalIterations;
      }

      @Override
      public void updateStep() {
         this.currentIteration++;
      }

      @Override
      public boolean isFinished() {
         return this.currentIteration >= this.totalIterations;
      }
   }

   public interface LoopTickStrategy {
      boolean shouldExecute(int var1, int var2);

      void updateStep();

      boolean isFinished();
   }

   public static final class TickStep implements Comparable<Script.TickStep> {
      private int ticks;
      private ScriptAction action;
      private BooleanSupplier condition;
      private int priority;

      public TickStep(int var1, ScriptAction var2, BooleanSupplier var3, int var4) {
         this.ticks = var1;
         this.action = var2;
         this.condition = var3;
         this.priority = var4;
      }

      public int compareTo(Script.TickStep var1) {
         return Integer.compare(var1.getPriority(), this.getPriority());
      }

      public int getTicks() {
         return this.ticks;
      }

      public ScriptAction getAction() {
         return this.action;
      }

      public BooleanSupplier getCondition() {
         return this.condition;
      }

      public int getPriority() {
         return this.priority;
      }

      public Script.TickStep setTicks(int var1) {
         this.ticks = var1;
         return this;
      }

      public Script.TickStep setAction(ScriptAction var1) {
         this.action = var1;
         return this;
      }

      public Script.TickStep setCondition(BooleanSupplier var1) {
         this.condition = var1;
         return this;
      }

      public Script.TickStep setPriority(int var1) {
         this.priority = var1;
         return this;
      }
   }

   public static final class TimeStep implements Comparable<Script.TimeStep> {
      private int delay;
      private ScriptAction action;
      private BooleanSupplier condition;
      private int priority;

      public TimeStep(int var1, ScriptAction var2, BooleanSupplier var3, int var4) {
         this.delay = var1;
         this.action = var2;
         this.condition = var3;
         this.priority = var4;
      }

      public int compareTo(Script.TimeStep var1) {
         return Integer.compare(var1.getPriority(), this.getPriority());
      }

      public void startTimer() {
         this.delay--;
      }

      public int getDelay() {
         return this.delay;
      }

      public ScriptAction getAction() {
         return this.action;
      }

      public BooleanSupplier getCondition() {
         return this.condition;
      }

      public int getPriority() {
         return this.priority;
      }

      public Script.TimeStep setDelay(int var1) {
         this.delay = var1;
         return this;
      }

      public Script.TimeStep setAction(ScriptAction var1) {
         this.action = var1;
         return this;
      }

      public Script.TimeStep setCondition(BooleanSupplier var1) {
         this.condition = var1;
         return this;
      }

      public Script.TimeStep setPriority(int var1) {
         this.priority = var1;
         return this;
      }
   }
}
