package project.papus.common.util.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import project.papus.api.system.shape.ShapeProperties;
import project.papus.common.QuickImports;
import project.papus.common.util.color.ColorUtil;

public final class Render2DUtil implements QuickImports {
   private static final List<Render2DUtil.Quad> QUAD_LIST = new ArrayList<>();

   public static void onRender(DrawContext var0) {
      MatrixStack var1 = var0.getMatrices();
      Matrix4f var2 = var1.peek().getPositionMatrix();
      if (!QUAD_LIST.isEmpty()) {
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
         BufferBuilder var3 = QuickImports.tessellator().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
         QUAD_LIST.forEach(var2x -> drawEngine.quad(var2, var3, var2x.x, var2x.y, var2x.width, var2x.height, var2x.color));
         BufferRenderer.drawWithGlobalProgram(var3.end());
         RenderSystem.disableBlend();
         QUAD_LIST.clear();
      }
   }

   public static void defaultDrawStack(DrawContext var0, ItemStack var1, float var2, float var3, boolean var4, boolean var5, float var6) {
      MatrixStack var7 = var0.getMatrices();
      if (var4) {
         blur.render(ShapeProperties.create(var7, var2, var3, 16.0F * var6 + 2.0F, 16.0F * var6 + 2.0F).round(2.0F).color(ColorUtil.HALF_BLACK).build());
      }

      var7.push();
      var7.translate(var2 + 1.0F, var3 + 1.0F, 0.0F);
      var7.scale(var6, var6, 1.0F);
      var0.drawItem(var1, 0, 0);
      if (var5) {
         var0.drawStackOverlay(mc.textRenderer, var1, 0, 0);
      }

      var7.pop();
   }

   public static void drawStack(MatrixStack var0, ItemStack var1, float var2, float var3, boolean var4, float var5) {
      float var6 = var2 + 1.0F;
      float var7 = var3 + 1.0F;
      float var8 = 1.0F;
      var0.push();
      var0.translate(var6, var7, 0.0F);
      if (var4) {
         blur.render(
            ShapeProperties.create(var0, -var8, -var8, 16.0F * var5 + var8 * 2.0F, 16.0F * var5 + var8 * 2.0F).round(1.5F).color(ColorUtil.HALF_BLACK).build()
         );
      }

      var0.scale(var5, var5, 1.0F);
      ItemRender.drawItem(var0, var1, 0.0F, 0.0F, true, true);
      var0.pop();
   }

   public static void drawTexture(DrawContext var0, Identifier var1, float var2, float var3, int var4) {
      MatrixStack var5 = var0.getMatrices();
      if (var1 != null) {
         var5.push();
         var5.translate(var2, var3, 0.0F);
         var5.scale(var4, var4, 1.0F);
         RenderSystem.enableBlend();
         drawTexture(var5, var1, 0, 0, 1.0F, 1.0F, var4, var4, var4, var4, var4, var4, -1);
         RenderSystem.disableBlend();
         var5.translate(-var2, -var3, 0.0F);
         var5.pop();
      }
   }

   public static void drawTexture(DrawContext var0, Identifier var1, float var2, float var3, float var4, float var5, int var6, int var7, int var8, int var9) {
      drawTexture(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, -1);
   }

   public static void drawTexture(
      DrawContext var0, Identifier var1, float var2, float var3, float var4, float var5, int var6, int var7, int var8, int var9, int var10
   ) {
      MatrixStack var11 = var0.getMatrices();
      rectangle.render(ShapeProperties.create(var11, var2, var3, var4, var4).round(var5).color(var9).build());
      if (var1 != null) {
         var11.push();
         var11.translate(var2, var3, 0.0F);
         var11.scale(var4, var4, 1.0F);
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(772, 773);
         drawTexture(var11, var1, 0, 0, 1.0F, 1.0F, var6, var6, var7, var7, var8, var8, var10);
         RenderSystem.disableBlend();
         var11.translate(-var2, -var3, 0.0F);
         var11.pop();
      }
   }

   public static void drawSprite(MatrixStack var0, Sprite var1, float var2, float var3, float var4, int var5) {
      if (var4 != 0.0F && var5 != 0) {
         drawTexturedQuad(var0, var1.getAtlasId(), var2, var2 + var4, var3, var3 + var5, var1.getMinU(), var1.getMaxU(), var1.getMinV(), var1.getMaxV(), -1);
      }
   }

   public static void drawTexture(
      MatrixStack var0,
      Identifier var1,
      int var2,
      int var3,
      float var4,
      float var5,
      float var6,
      float var7,
      int var8,
      int var9,
      int var10,
      int var11,
      int var12
   ) {
      drawTexturedQuad(var0, var1, var2, var2 + var4, var3, var3 + var5, 0.0F, var8, var9, var6, var7, var10, var11, var12);
   }

   public static void drawTexturedQuad(
      MatrixStack var0,
      Identifier var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      int var7,
      int var8,
      float var9,
      float var10,
      int var11,
      int var12,
      int var13
   ) {
      drawTexturedQuad(var0, var1, var2, var3, var4, var5, (var9 + 0.0F) / var11, (var9 + var7) / var11, (var10 + 0.0F) / var12, (var10 + var8) / var12, var13);
   }

   public static void drawTexturedQuad(
      MatrixStack var0, Identifier var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, int var10
   ) {
      RenderSystem.setShaderTexture(0, var1);
      RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
      BufferBuilder var11 = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
      Matrix4f var12 = var0.peek().getPositionMatrix();
      var11.vertex(var12, var2, var4, 0.0F).texture(var6, var8).color(var10);
      var11.vertex(var12, var2, var5, 0.0F).texture(var6, var9).color(var10);
      var11.vertex(var12, var3, var5, 0.0F).texture(var7, var9).color(var10);
      var11.vertex(var12, var3, var4, 0.0F).texture(var7, var8).color(var10);
      BufferRenderer.drawWithGlobalProgram(var11.end());
   }

   public static void drawQuad(float var0, float var1, float var2, float var3, int var4) {
      QUAD_LIST.add(new Render2DUtil.Quad(var0, var1, var2, var3, ColorUtil.setAlpha(var4, RenderSystem.getShaderColor()[3])));
   }

   private Render2DUtil() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public record Quad(float x, float y, float width, float height, int color) {
   }
}
