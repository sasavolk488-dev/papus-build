package project.papus.common.util.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Stack;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import project.papus.common.QuickImports;
import project.papus.common.util.other.Pool;

public class ScissorManager implements QuickImports {
   private final Pool<ScissorManager.Scissor> scissorPool = new Pool<>(ScissorManager.Scissor::new);
   private final Stack<ScissorManager.Scissor> scissorStack = new Stack<>();

   public void push(Matrix4f var1, float var2, float var3, float var4, float var5) {
      ScissorManager.Scissor var6 = this.scissorPool.get().copy();
      Vector3f var7 = var1.transformPosition(var2, var3, 0.0F, new Vector3f());
      Vector3f var8 = var1.getScale(new Vector3f()).mul(var4, var5, 0.0F);
      var6.set(var7.x, var7.y, var8.x, var8.y);
      this.scissorStack.push(var6);
      this.setScissor(var6);
   }

   public void pop() {
      if (!this.scissorStack.isEmpty()) {
         this.scissorPool.free(this.scissorStack.pop());
         if (this.scissorStack.isEmpty()) {
            RenderSystem.disableScissor();
         } else {
            this.setScissor(this.scissorStack.peek());
         }
      }
   }

   private void setScissor(ScissorManager.Scissor var1) {
      int var2 = (int)window.getScaleFactor();
      int var3 = var1.x * var2;
      int var4 = window.getHeight() - (var1.y * var2 + var1.height * var2);
      int var5 = var1.width * var2;
      int var6 = var1.height * var2;
      RenderSystem.enableScissor(var3, var4, var5, var6);
   }

   static class Scissor {
      public int x;
      public int y;
      public int width;
      public int height;

      private Scissor() {
      }

      public void set(double var1, double var3, double var5, double var7) {
         this.x = Math.max(0, (int)Math.round(var1));
         this.y = Math.max(0, (int)Math.round(var3));
         this.width = Math.max(0, (int)Math.round(var5));
         this.height = Math.max(0, (int)Math.round(var7));
      }

      ScissorManager.Scissor copy() {
         ScissorManager.Scissor var1 = new ScissorManager.Scissor();
         var1.set(this.x, this.y, this.width, this.height);
         return var1;
      }
   }
}
