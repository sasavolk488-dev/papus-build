package project.papus.common.util.color;

import java.util.regex.Pattern;
import net.minecraft.component.ComponentMap;
import net.minecraft.item.ItemStack;
import org.apache.commons.lang3.StringUtils;

public class AuctionPriceParser {
   private final Pattern funTimePricePattern = Pattern.compile("\\$(\\d+(?:\\s\\d{3})*(?:\\.\\d{2})?)");

   public int getPrice(ItemStack var1) {
      ComponentMap var2 = var1.getComponents();
      if (var2 == null) {
         return -1;
      } else {
         String var3 = StringUtils.substringBetween(var2.toString(), "literal{ $", "}[style={color=green}]");
         if (var3 != null && !var3.isEmpty()) {
            var3 = var3.replaceAll(" ", "").replaceAll(",", "");
            return Integer.parseInt(var3);
         } else {
            return -1;
         }
      }
   }
}
