package project.papus.common.util.rotation;

import project.papus.common.QuickImports;

public class RotationController implements QuickImports {
   public static final RotationController INSTANCE = new RotationController();
   private Angle currentAngle = new Angle();
   private Angle previousAngle = new Angle();
   private Angle moveAngle = new Angle();
   private Angle serverAngle = new Angle();
   private Angle prevServerAngle = null;
   private RotationPlan currentRotationPlan = null;

   public void update() {
      if (mc.player != null) {
         this.previousAngle = this.currentAngle.adjustSensitivity();
         this.currentAngle.setYaw(mc.player.getYaw());
         this.currentAngle.setPitch(mc.player.getPitch());
         this.moveAngle.setYaw(mc.player.getYaw());
         this.moveAngle.setPitch(mc.player.getPitch());
         this.serverAngle.setYaw(mc.player.getYaw());
         this.serverAngle.setPitch(mc.player.getPitch());
      }
   }

   public void rotateTo(Angle var1, RaytracingUtil var2, Object var3, Object var4) {
   }

   public Angle getCurrentAngle() {
      return this.currentAngle;
   }

   public Angle getPreviousAngle() {
      return this.previousAngle;
   }

   public Angle getMoveAngle() {
      return this.moveAngle;
   }

   public Angle getServerAngle() {
      return this.serverAngle;
   }

   public Angle getPrevServerAngle() {
      return this.prevServerAngle;
   }

   public RotationPlan getCurrentRotationPlan() {
      return this.currentRotationPlan;
   }
}
