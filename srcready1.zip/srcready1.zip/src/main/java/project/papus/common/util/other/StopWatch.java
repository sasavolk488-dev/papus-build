package project.papus.common.util.other;

public class StopWatch {
   private long lastMS;

   public StopWatch() {
      this.reset();
   }

   public boolean every(double var1) {
      return System.currentTimeMillis() - var1 >= this.lastMS;
   }

   public boolean finished(double var1) {
      boolean var3 = this.every(var1);
      if (var3) {
         this.reset();
      }

      return var3;
   }

   public void reset() {
      this.lastMS = System.currentTimeMillis();
   }

   public int elapsedTime() {
      return Math.toIntExact(System.currentTimeMillis() - this.lastMS);
   }

   public StopWatch setMs(long var1) {
      this.lastMS = System.currentTimeMillis() - var1;
      return this;
   }

   public long getLastMS() {
      return this.lastMS;
   }
}
