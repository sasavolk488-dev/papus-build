package project.papus.common.util.render;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;

public interface WorldRenderCallback {
   Event<WorldRenderCallback> EVENT = EventFactory.createArrayBacked(WorldRenderCallback.class, var0 -> (var1, var2) -> {
      for (WorldRenderCallback var6 : var0) {
         var6.onResized(var1, var2);
      }
   });

   void onResized(MinecraftClient var1, Window var2);
}
