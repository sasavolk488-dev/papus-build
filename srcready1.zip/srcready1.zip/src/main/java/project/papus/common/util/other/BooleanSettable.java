package project.papus.common.util.other;

public class BooleanSettable {
   private boolean value;

   public boolean isValue() {
      return this.value;
   }

   public void setValue(boolean var1) {
      this.value = var1;
   }
}
