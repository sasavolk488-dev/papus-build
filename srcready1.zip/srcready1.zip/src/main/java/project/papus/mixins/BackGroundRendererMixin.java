package project.papus.mixins;

import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Fog;
import net.minecraft.client.render.FogShape;
import net.minecraft.client.render.BackgroundRenderer.FogType;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import project.papus.api.event.EventManager;
import project.papus.common.util.color.ColorUtil;
import project.papus.implement.events.render.FogEvent;
import project.papus.implement.features.modules.render.NoRender;

@Mixin(BackgroundRenderer.class)
public class BackGroundRendererMixin {
   @Inject(
      method = "getFogModifier(Lnet/minecraft/entity/Entity;F)Lnet/minecraft/client/render/BackgroundRenderer$StatusEffectFogModifier;",
      at = @At("HEAD"),
      cancellable = true
   )
   private static void onGetFogModifier(Entity var0, float var1, CallbackInfoReturnable<Object> var2) {
      NoRender var3 = NoRender.getInstance();
      if (var3.isState()) {
         var2.setReturnValue(null);
      }
   }

   @Inject(
      method = "getFogColor(Lnet/minecraft/client/render/Camera;FLnet/minecraft/client/world/ClientWorld;IF)Lorg/joml/Vector4f;",
      at = @At("HEAD"),
      cancellable = true
   )
   private static void getFogColorHook(Camera var0, float var1, ClientWorld var2, int var3, float var4, CallbackInfoReturnable<Vector4f> var5) {
      FogEvent var6 = new FogEvent();
      EventManager.callEvent(var6);
      if (var6.isCancelled()) {
         int var7 = var6.getColor();
         var5.setReturnValue(new Vector4f(ColorUtil.redf(var7), ColorUtil.greenf(var7), ColorUtil.bluef(var7), ColorUtil.alphaf(var7)));
      }
   }

   @Inject(
      method = "applyFog(Lnet/minecraft/client/render/Camera;Lnet/minecraft/client/render/BackgroundRenderer$FogType;Lorg/joml/Vector4f;FZF)Lnet/minecraft/client/render/Fog;",
      at = @At("HEAD"),
      cancellable = true
   )
   private static void modifyFog(Camera var0, FogType var1, Vector4f var2, float var3, boolean var4, float var5, CallbackInfoReturnable<Fog> var6) {
      FogEvent var7 = new FogEvent();
      EventManager.callEvent(var7);
      if (var7.isCancelled()) {
         int var8 = var7.getColor();
         var6.setReturnValue(
            new Fog(2.0F, var7.getDistance(), FogShape.CYLINDER, ColorUtil.redf(var8), ColorUtil.greenf(var8), ColorUtil.bluef(var8), ColorUtil.alphaf(var8))
         );
      }
   }
}
