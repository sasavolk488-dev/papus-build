package project.papus.mixins;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.debug.DebugRenderer;
import net.minecraft.client.render.debug.DebugRenderer.Renderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import project.papus.implement.features.modules.render.Esp;

@Mixin(DebugRenderer.class)
public abstract class DebugRendererMixin {
   @Shadow
   @Final
   private Renderer collisionDebugRenderer;

   @Redirect(
      method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/Frustum;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;DDD)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/debug/DebugRenderer$Renderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;DDD)V"
      )
   )
   private void redirectCollisionRender(Renderer var1, MatrixStack var2, VertexConsumerProvider var3, double var4, double var6, double var8) {
      if (var1 != this.collisionDebugRenderer || !Esp.getInstance().isState()) {
         var1.render(var2, var3, var4, var6, var8);
      }
   }
}
