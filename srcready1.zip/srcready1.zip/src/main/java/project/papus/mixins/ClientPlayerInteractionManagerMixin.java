package project.papus.mixins;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult.Success;
import net.minecraft.util.ActionResult.SwingSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import project.papus.api.event.EventManager;
import project.papus.common.util.item.InventoryUpdateWatcher;
import project.papus.implement.events.block.BlockBreakingProgressEvent;
import project.papus.implement.events.block.BreakBlockEvent;
import project.papus.implement.events.item.ClickSlotEvent;
import project.papus.implement.events.item.UsingItemEvent;
import project.papus.implement.events.player.AttackEvent;

@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {
   @Inject(method = "attackEntity(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"), cancellable = true)
   public void attackEntityHook(PlayerEntity var1, Entity var2, CallbackInfo var3) {
      AttackEvent var4 = new AttackEvent(var2);
      EventManager.callEvent(var4);
      if (var4.isCancelled()) {
         var3.cancel();
      }
   }

   @Inject(method = "interactItem(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/Hand;)Lnet/minecraft/util/ActionResult;", at = @At("RETURN"))
   public void interactItemHook(PlayerEntity var1, Hand var2, CallbackInfoReturnable<ActionResult> var3) {
      if (var3.getReturnValue() instanceof Success var4 && !var4.swingSource().equals(SwingSource.CLIENT)) {
         UsingItemEvent var6 = new UsingItemEvent((byte)0);
         EventManager.callEvent(var6);
      }
   }

   @Inject(method = "stopUsingItem(Lnet/minecraft/entity/player/PlayerEntity;)V", at = @At("HEAD"), cancellable = true)
   public void stopUsingItemHook(CallbackInfo var1) {
      UsingItemEvent var2 = new UsingItemEvent((byte)2);
      EventManager.callEvent(var2);
      if (InventoryUpdateWatcher.INSTANCE.isHoldItem()) {
         InventoryUpdateWatcher.INSTANCE.setHoldItem(false);
         var1.cancel();
      }
   }

   @Inject(
      method = "interactItem(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/Hand;)Lnet/minecraft/util/ActionResult;",
      at = @At("HEAD"),
      cancellable = true
   )
   private void gameModeHook(PlayerEntity var1, Hand var2, CallbackInfoReturnable<ActionResult> var3) {
      UsingItemEvent var4 = new UsingItemEvent((byte)-1);
      EventManager.callEvent(var4);
      if (var4.isCancelled()) {
         var3.setReturnValue(ActionResult.PASS);
      }
   }

   @Inject(
      method = "clickSlot(IIILnet/minecraft/screen/slot/SlotActionType;Lnet/minecraft/entity/player/PlayerEntity;)V",
      at = @At("HEAD"),
      cancellable = true
   )
   public void clickSlotHook(int var1, int var2, int var3, SlotActionType var4, PlayerEntity var5, CallbackInfo var6) {
      ClickSlotEvent var7 = new ClickSlotEvent(var1, var2, var3, var4);
      EventManager.callEvent(var7);
      if (var7.isCancelled()) {
         var6.cancel();
      }
   }

   @Inject(method = "updateBlockBreakingProgress(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/Direction;)Z", at = @At("HEAD"))
   private void injectBlockBreaking(BlockPos var1, Direction var2, CallbackInfoReturnable<Boolean> var3) {
      EventManager.callEvent(new BlockBreakingProgressEvent(var1, var2));
   }

   @Inject(method = "breakBlock(Lnet/minecraft/util/math/BlockPos;)Z", at = @At("RETURN"))
   private void injectBreakBlock(BlockPos var1, CallbackInfoReturnable<Boolean> var2) {
      EventManager.callEvent(new BreakBlockEvent(var1));
   }
}
