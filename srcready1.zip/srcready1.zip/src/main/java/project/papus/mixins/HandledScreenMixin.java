package project.papus.mixins;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.implement.events.container.HandledScreenEvent;

@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {
   @Shadow
   public int backgroundWidth;
   @Shadow
   public int backgroundHeight;
   @Shadow
   @Nullable
   protected Slot focusedSlot;

   @Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("RETURN"))
   public void render(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      EventManager.callEvent(new HandledScreenEvent(var1, this.focusedSlot, this.backgroundWidth, this.backgroundHeight));
   }
}
