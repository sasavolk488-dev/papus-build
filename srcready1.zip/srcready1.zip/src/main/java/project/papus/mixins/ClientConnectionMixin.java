package project.papus.mixins;

import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.implement.events.packet.PacketEvent;

@Mixin(ClientConnection.class)
public class ClientConnectionMixin {
   @Inject(
      method = "handlePacket(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;)V",
      at = @At("HEAD"),
      cancellable = true
   )
   private static <T extends PacketListener> void handlePacketPre(Packet<T> var0, PacketListener var1, CallbackInfo var2) {
      PacketEvent var3 = new PacketEvent(var0, PacketEvent.Type.RECEIVE);
      EventManager.callEvent(var3);
      if (var3.isCancelled()) {
         var2.cancel();
      }
   }

   @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
   private void sendPre(Packet<?> var1, CallbackInfo var2) {
      PacketEvent var3 = new PacketEvent(var1, PacketEvent.Type.SEND);
      EventManager.callEvent(var3);
      if (var3.isCancelled()) {
         var2.cancel();
      }
   }
}
