package project.papus.mixins;

import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.file.exception.FileProcessingException;
import project.papus.common.util.logger.LoggerUtil;
import project.papus.core.Main;

@Mixin(MinecraftServer.class)
public class MinecraftServerMixin {
   @Inject(method = "shutdown()V", at = @At("HEAD"))
   public void shutdown(CallbackInfo var1) {
      if (Main.getInstance().isInitialized()) {
         try {
            Main.getInstance().getFileController().saveFiles();
         } catch (FileProcessingException var3) {
            LoggerUtil.error("Error occurred while saving files: " + var3.getMessage());
         }
      }
   }
}
