package project.papus.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.common.QuickImports;
import project.papus.common.util.rotation.RotationController;
import project.papus.implement.events.render.EntityColorEvent;
import project.papus.implement.features.modules.render.SeeInvisible;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin implements QuickImports {
   @Shadow
   @Nullable
   protected abstract RenderLayer getRenderLayer(LivingEntityRenderState var1, boolean var2, boolean var3, boolean var4);

   @Redirect(
      method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/entity/LivingEntityRenderer;getRenderLayer(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/render/RenderLayer;"
      )
   )
   private RenderLayer renderHook(LivingEntityRenderer var1, LivingEntityRenderState var2, boolean var3, boolean var4, boolean var5) {
      if (!var4 && var2.width == 0.6F) {
         EntityColorEvent var6 = new EntityColorEvent(-1);
         EventManager.callEvent(var6);
         if (var6.isCancelled()) {
            var4 = true;
         }
      }

      return this.getRenderLayer(var2, var3, var4, var5);
   }

   @Redirect(
      method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/entity/model/EntityModel;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V"
      )
   )
   private void renderModelHook(
      EntityModel<?> var1,
      MatrixStack var2,
      VertexConsumer var3,
      int var4,
      int var5,
      int var6,
      @Local(ordinal = 0, argsOnly = true) LivingEntityRenderState var7
   ) {
      EntityColorEvent var8 = new EntityColorEvent(var6);
      if (var7.invisibleToPlayer) {
         EventManager.callEvent(var8);
      }

      var1.render(var2, var3, var4, var5, var8.getColor());
   }

   @ModifyExpressionValue(
      method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;lerpAngleDegrees(FFF)F")
   )
   private float lerpAngleDegreesHook(float var1, @Local(ordinal = 0, argsOnly = true) LivingEntity var2, @Local(ordinal = 0, argsOnly = true) float var3) {
      if (var2.equals(mc.player) && mc.currentScreen == null) {
         RotationController var4 = RotationController.INSTANCE;
         return MathHelper.lerpAngleDegrees(var3, var4.getPreviousAngle().getYaw(), var4.getCurrentAngle().getYaw());
      } else {
         return var1;
      }
   }

   @ModifyExpressionValue(
      method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getLerpedPitch(F)F")
   )
   private float getLerpedPitchHook(float var1, @Local(ordinal = 0, argsOnly = true) LivingEntity var2, @Local(ordinal = 0, argsOnly = true) float var3) {
      if (var2.equals(mc.player) && mc.currentScreen == null) {
         RotationController var4 = RotationController.INSTANCE;
         return MathHelper.lerp(var3, var4.getPreviousAngle().getPitch(), var4.getCurrentAngle().getPitch());
      } else {
         return var1;
      }
   }

   @Inject(
      method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
      at = @At("TAIL")
   )
   private void seeInvisibleHook(LivingEntity var1, LivingEntityRenderState var2, float var3, CallbackInfo var4) {
      SeeInvisible var5 = SeeInvisible.getInstance();
      if (var5 != null && var5.isState() && var5.shouldSee(var1)) {
         var2.invisibleToPlayer = false;
      }
   }

   @ModifyConstant(
      method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
      constant = @Constant(intValue = 654311423)
   )
   private int seeInvisibleAlphaHook(int var1) {
      SeeInvisible var2 = SeeInvisible.getInstance();
      if (var2 != null && var2.isState()) {
         int var3 = (int)(var2.getAlpha() * 255.0F) & 0xFF;
         return var3 << 24 | 16777215;
      } else {
         return var1;
      }
   }
}
