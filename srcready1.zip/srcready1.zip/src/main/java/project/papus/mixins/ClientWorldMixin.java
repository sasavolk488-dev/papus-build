package project.papus.mixins;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.common.QuickImports;
import project.papus.common.util.entity.PlayerHealthUtil;
import project.papus.implement.events.player.EntitySpawnEvent;
import project.papus.implement.events.render.WorldLoadEvent;

@Mixin(ClientWorld.class)
public class ClientWorldMixin implements QuickImports {
   @Inject(
      method = "<init>(Lnet/minecraft/client/network/ClientPlayNetworkHandler;Lnet/minecraft/client/world/ClientWorld$Properties;Lnet/minecraft/registry/RegistryKey;Lnet/minecraft/registry/entry/RegistryEntry;IILnet/minecraft/client/render/WorldRenderer;ZJI)V",
      at = @At("RETURN")
   )
   public void initHook(CallbackInfo var1) {
      EventManager.callEvent(new WorldLoadEvent());
   }

   @Inject(method = "addEntity(Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"), cancellable = true)
   public void addEntityHook(Entity var1, CallbackInfo var2) {
      if (!PlayerHealthUtil.nullCheck()) {
         EntitySpawnEvent var3 = new EntitySpawnEvent(var1);
         EventManager.callEvent(var3);
         if (var3.isCancelled()) {
            var2.cancel();
         }
      }
   }
}
