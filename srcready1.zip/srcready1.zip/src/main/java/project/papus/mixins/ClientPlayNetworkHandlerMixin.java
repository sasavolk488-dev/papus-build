package project.papus.mixins;

import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.UnloadChunkS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.common.QuickImports;
import project.papus.implement.events.block.BlockUpdateEvent;
import project.papus.implement.events.chat.ChatEvent;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin implements QuickImports {
   @Inject(method = "onChunkData(Lnet/minecraft/network/packet/s2c/play/ChunkDataS2CPacket;)V", at = @At("RETURN"))
   private void onChunkDataHook(ChunkDataS2CPacket var1, CallbackInfo var2) {
      if (mc.world != null) {
         this.scanChunk(mc.world.getChunk(var1.getChunkX(), var1.getChunkZ()), BlockUpdateEvent.Type.LOAD);
      }
   }

   @Inject(method = "onUnloadChunk(Lnet/minecraft/network/packet/s2c/play/UnloadChunkS2CPacket;)V", at = @At("HEAD"))
   private void onUnloadChunkHook(UnloadChunkS2CPacket var1, CallbackInfo var2) {
      if (mc.world != null) {
         this.scanChunk(mc.world.getChunk(var1.pos().x, var1.pos().z), BlockUpdateEvent.Type.UNLOAD);
      }
   }

   @Inject(method = "sendChatMessage(Ljava/lang/String;)V", at = @At("HEAD"), cancellable = true)
   private void sendChatMessage(String var1, CallbackInfo var2) {
      ChatEvent var3 = new ChatEvent(var1);
      EventManager.callEvent(var3);
      if (var3.isCancelled()) {
         var2.cancel();
      }
   }

   @Unique
   private void scanChunk(WorldChunk var1, BlockUpdateEvent.Type var2) {
      int var3 = var1.getPos().getStartX();
      int var4 = var1.getPos().getStartZ();
      ArrayList<CompletableFuture<Void>> var5 = new ArrayList<>();

      for (int var6 = 0; var6 <= var1.getHighestNonEmptySection(); var6++) {
         int var7 = var6;
         var5.add(CompletableFuture.runAsync(() -> {
            ChunkSection var5x = var1.getSection(var7);

            for (int var6x = 0; var6x < 16; var6x++) {
               int var7x = var7 + (var1.getBottomY() >> 4) << 4 | var6x;

               for (int var8 = 0; var8 < 16; var8++) {
                  for (int var9 = 0; var9 < 16; var9++) {
                     BlockState var10 = var2.equals(BlockUpdateEvent.Type.LOAD) ? var5x.getBlockState(var8, var6x, var9) : Blocks.AIR.getDefaultState();
                     BlockPos var11 = new BlockPos(var3 | var8, var7x, var4 | var9);
                     EventManager.callEvent(new BlockUpdateEvent(var10, var11, var2));
                  }
               }
            }
         }));
      }

      CompletableFuture.allOf(var5.toArray(new CompletableFuture[0])).join();
   }
}
