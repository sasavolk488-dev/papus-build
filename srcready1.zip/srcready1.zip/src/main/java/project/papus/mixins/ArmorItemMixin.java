package project.papus.mixins;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item.Settings;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.interfaces.IArmorItem;

@Mixin(ArmorItem.class)
public abstract class ArmorItemMixin implements IArmorItem {
   @Unique
   private ArmorMaterial armorMaterial;
   @Unique
   private EquipmentType type;

   @Inject(
      method = "<init>(Lnet/minecraft/item/equipment/ArmorMaterial;Lnet/minecraft/item/equipment/EquipmentType;Lnet/minecraft/item/Item$Settings;)V",
      at = @At("RETURN")
   )
   public void hookCatchArgs(ArmorMaterial var1, EquipmentType var2, Settings var3, CallbackInfo var4) {
      this.armorMaterial = var1;
      this.type = var2;
   }

   @Override
   public ArmorMaterial getArmorMaterial() {
      return this.armorMaterial;
   }

   @Override
   public EquipmentType getArmorType() {
      return this.type;
   }
}
