package project.papus.mixins;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil.Type;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.implement.events.keyboard.HotBarScrollEvent;
import project.papus.implement.events.keyboard.KeyEvent;
import project.papus.implement.events.keyboard.MouseRotationEvent;
import project.papus.implement.events.render.FovEvent;

@Mixin(Mouse.class)
public class MouseMixin {
   @Final
   @Shadow
   private MinecraftClient client;
   @Shadow
   public double cursorDeltaX;
   @Shadow
   public double cursorDeltaY;

   @Inject(method = "onMouseButton(JIII)V", at = @At("HEAD"))
   public void onMouseButtonHook(long var1, int var3, int var4, int var5, CallbackInfo var6) {
      if (var3 != -1 && var1 == this.client.getWindow().getHandle()) {
         EventManager.callEvent(new KeyEvent(this.client.currentScreen, Type.MOUSE, var3, var4));
      }
   }

   @Inject(
      method = "onMouseScroll(JDD)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getInventory()Lnet/minecraft/entity/player/PlayerInventory;"),
      cancellable = true
   )
   public void onMouseScrollHook(long var1, double var3, double var5, CallbackInfo var7) {
      HotBarScrollEvent var8 = new HotBarScrollEvent(var3, var5);
      EventManager.callEvent(var8);
      if (var8.isCancelled()) {
         var7.cancel();
      }
   }

   @Inject(method = "updateMouse(D)V", at = @At("HEAD"))
   private void onUpdateMouse(double var1, CallbackInfo var3) {
      FovEvent var4 = new FovEvent();
      EventManager.callEvent(var4);
      if (var4.isCancelled()) {
         double var5 = (double)var4.getFov() / ((Integer)this.client.options.getFov().getValue()).intValue();
         this.cursorDeltaX *= var5;
         this.cursorDeltaY *= var5;
      }
   }

   @WrapWithCondition(
      method = "updateMouse(D)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"),
      require = 1,
      allow = 1
   )
   private boolean modifyMouseRotationInput(ClientPlayerEntity var1, double var2, double var4) {
      MouseRotationEvent var6 = new MouseRotationEvent((float)var2, (float)var4);
      EventManager.callEvent(var6);
      if (var6.isCancelled()) {
         return false;
      } else {
         var1.changeLookDirection(var6.getCursorDeltaX(), var6.getCursorDeltaY());
         return false;
      }
   }
}
