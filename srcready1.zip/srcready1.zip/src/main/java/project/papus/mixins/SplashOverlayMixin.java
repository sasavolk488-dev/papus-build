package project.papus.mixins;

import java.util.function.IntSupplier;
import net.minecraft.client.gui.screen.SplashOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(SplashOverlay.class)
public class SplashOverlayMixin {
   @Redirect(method = "render(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At(value = "INVOKE", target = "Ljava/util/function/IntSupplier;getAsInt()I"))
   private int forceBlackBackground(IntSupplier var1) {
      return 0;
   }
}
