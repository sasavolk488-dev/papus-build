package project.papus.mixins;

import net.minecraft.client.option.ServerList;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(ServerList.class)
public class ServerListMixin {
}
