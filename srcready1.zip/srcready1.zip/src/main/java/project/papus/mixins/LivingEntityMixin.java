package project.papus.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectUtil;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import project.papus.api.event.EventManager;
import project.papus.common.util.rotation.RotationController;
import project.papus.implement.events.block.PushEvent;
import project.papus.implement.events.item.SwingDurationEvent;
import project.papus.implement.events.player.KeepSprintEvent;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
   @Shadow
   public float bodyYaw;

   @Unique
   private MinecraftClient getClient() {
      return MinecraftClient.getInstance();
   }

   @Shadow
   public abstract boolean hasStatusEffect(RegistryEntry<StatusEffect> var1);

   @Shadow
   @Nullable
   public abstract StatusEffectInstance getStatusEffect(RegistryEntry<StatusEffect> var1);

   @Inject(method = "isPushable()Z", at = @At("HEAD"), cancellable = true)
   public void isPushable(CallbackInfoReturnable<Boolean> var1) {
      PushEvent var2 = new PushEvent(PushEvent.Type.COLLISION);
      EventManager.callEvent(var2);
      if (var2.isCancelled()) {
         var1.setReturnValue(false);
      }
   }

   @Inject(method = "jump()V", at = @At("HEAD"), cancellable = true)
   private void jump(CallbackInfo var1) {
      if ((Object)this instanceof PlayerEntity var2) {
         KeepSprintEvent var3 = new KeepSprintEvent(var2);
         EventManager.callEvent(var3);
         if (var3.isCancelled() && (Object)this instanceof ClientPlayerEntity) {
            var1.cancel();
         }
      }
   }

   @ModifyExpressionValue(method = "jump()V", at = @At(value = "NEW", target = "(DDD)Lnet/minecraft/util/math/Vec3d;"))
   private Vec3d hookFixRotation(Vec3d var1) {
      if ((Object)this != this.getClient().player) {
         return var1;
      } else {
         float var2 = RotationController.INSTANCE.getMoveAngle().getYaw() * (float) (Math.PI / 180.0);
         return new Vec3d(-MathHelper.sin(var2) * 0.2F, 0.0, MathHelper.cos(var2) * 0.2F);
      }
   }

   @ModifyExpressionValue(
      method = "calcGlidingVelocity(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getPitch()F")
   )
   private float hookModifyFallFlyingPitch(float var1) {
      return (Object)this != this.getClient().player ? var1 : RotationController.INSTANCE.getMoveAngle().getPitch();
   }

   @ModifyExpressionValue(
      method = "calcGlidingVelocity(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;")
   )
   private Vec3d hookModifyFallFlyingRotationVector(Vec3d var1) {
      return (Object)this != this.getClient().player ? var1 : RotationController.INSTANCE.getMoveAngle().toVector();
   }

   @Inject(method = "getHandSwingDuration()I", at = @At("HEAD"), cancellable = true)
   private void swingProgressHook(CallbackInfoReturnable<Integer> var1) {
      if ((Object)this == this.getClient().player) {
         SwingDurationEvent var2 = new SwingDurationEvent();
         EventManager.callEvent(var2);
         if (var2.isCancelled()) {
            float var3 = var2.getAnimation();
            if (StatusEffectUtil.hasHaste(this.getClient().player)) {
               var3 *= 6 - (1 + StatusEffectUtil.getHasteAmplifier(this.getClient().player));
            } else {
               var3 *= this.hasStatusEffect(StatusEffects.MINING_FATIGUE)
                  ? 6 + (1 + this.getStatusEffect(StatusEffects.MINING_FATIGUE).getAmplifier()) * 2
                  : 6.0F;
            }

            var1.setReturnValue((int)var3);
         }
      }
   }

   @ModifyExpressionValue(method = "turnHead(FF)F", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;wrapDegrees(F)F", ordinal = 1))
   private float wrapDegreesHook(float var1) {
      return (Object)this == this.getClient().player ? MathHelper.wrapDegrees(RotationController.INSTANCE.getCurrentAngle().getYaw() - this.bodyYaw) : var1;
   }
}
