package project.papus.mixins;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.SharedConstants;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.RunArgs;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.Icons;
import net.minecraft.client.util.MacWindowUtil;
import net.minecraft.client.util.Window;
import net.minecraft.resource.ResourcePack;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import project.papus.api.event.EventManager;
import project.papus.api.file.exception.FileProcessingException;
import project.papus.api.system.font.Fonts;
import project.papus.common.QuickImports;
import project.papus.common.util.logger.LoggerUtil;
import project.papus.common.util.other.BufferUtil;
import project.papus.core.Main;
import project.papus.implement.events.container.SetScreenEvent;
import project.papus.implement.events.player.JumpEvent;

@Environment(EnvType.CLIENT)
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin implements QuickImports {
   @Shadow
   @Nullable
   public ClientPlayerInteractionManager interactionManager;
   @Shadow
   @Nullable
   public ClientPlayerEntity player;
   @Shadow
   @Final
   public GameRenderer gameRenderer;
   @Shadow
   @Nullable
   public Screen currentScreen;

   @Shadow
   @Nullable
   public abstract ClientPlayNetworkHandler getNetworkHandler();

   @Inject(at = @At("TAIL"), method = "<init>(Lnet/minecraft/client/RunArgs;)V")
   private void onInit(RunArgs var1, CallbackInfo var2) {
      Fonts.init();
   }

   @Inject(at = @At("HEAD"), method = "stop()V")
   private void stop(CallbackInfo var1) {
      LoggerUtil.info("Stopping for MinecraftClient");
      if (Main.getInstance().isInitialized()) {
         try {
            Main.getInstance().getFileController().saveCurrentConfig();
            Main.getInstance().getFileController().saveFiles();
         } catch (FileProcessingException var6) {
            LoggerUtil.error("Error occurred while saving files: " + var6.getMessage() + " " + var6.getCause());
         } finally {
            Main.getInstance().getFileController().stopAutoSave();
         }
      }
   }

   @Inject(method = "setScreen(Lnet/minecraft/client/gui/screen/Screen;)V", at = @At("HEAD"), cancellable = true)
   public void setScreenHook(Screen var1, CallbackInfo var2) {
      SetScreenEvent var3 = new SetScreenEvent(var1);
      EventManager.callEvent(var3);
      Main.getInstance().getDraggableRepository().draggable().forEach(var1x -> var1x.onSetScreen(var3));
      Screen var4 = var3.getScreen();
      if (var1 != var4) {
         mc.setScreen(var4);
         var2.cancel();
      }
   }

   @Redirect(
      method = "<init>(Lnet/minecraft/client/RunArgs;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/Window;setIcon(Lnet/minecraft/resource/ResourcePack;Lnet/minecraft/client/util/Icons;)V")
   )
   private void onChangeIcon(Window var1, ResourcePack var2, Icons var3) throws java.io.IOException {
      if (GLFW.glfwGetPlatform() == 393218) {
         MacWindowUtil.setApplicationIconImage(var3.getMacIcon(var2));
      } else {
         BufferUtil.setWindowIcon(Main.class.getResourceAsStream("/zov.png"), Main.class.getResourceAsStream("/zov.png"));
      }
   }

   @Inject(method = "getWindowTitle()Ljava/lang/String;", at = @At("HEAD"), cancellable = true)
   private void onWindowTitle(CallbackInfoReturnable<String> var1) {
      var1.setReturnValue("Minecraft  " + SharedConstants.getGameVersion().getName());
   }

   @Inject(
      method = "handleInputEvents()V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getInventory()Lnet/minecraft/entity/player/PlayerInventory;"),
      cancellable = true
   )
   public void handleInputEventsHook(CallbackInfo var1) {
      JumpEvent var2 = new JumpEvent();
      EventManager.callEvent(var2);
      if (var2.isCancelled()) {
         var1.cancel();
      }
   }
}
