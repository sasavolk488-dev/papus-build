package project.papus.mixins;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockCollisionSpliterator;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import project.papus.api.event.EventManager;
import project.papus.implement.events.block.BlockCollisionEvent;

@Mixin(BlockCollisionSpliterator.class)
public abstract class BlockCollisionSpliteratorMixin {
   @Redirect(
      method = "computeNext()Ljava/lang/Object;",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/world/BlockView;getBlockState(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/BlockState;")
   )
   private BlockState computeNext(BlockView var1, BlockPos var2) {
      BlockCollisionEvent var3 = new BlockCollisionEvent(var2, var1.getBlockState(var2));
      EventManager.callEvent(var3);
      return var3.state();
   }
}
