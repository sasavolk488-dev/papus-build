package project.papus.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import project.papus.api.event.EventManager;
import project.papus.common.QuickImports;
import project.papus.implement.events.block.PushEvent;
import project.papus.implement.events.player.ListsCheckEvent;
import project.papus.implement.events.player.SwimmingEvent;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin implements QuickImports {
   @Inject(method = "isPushedByFluids()Z", at = @At("HEAD"), cancellable = true)
   public void isPushedByFluids(CallbackInfoReturnable<Boolean> var1) {
      PushEvent var2 = new PushEvent(PushEvent.Type.WATER);
      EventManager.callEvent(var2);
      if (var2.isCancelled()) {
         var1.setReturnValue(false);
      }
   }

   @Inject(
      method = "attack(Lnet/minecraft/entity/Entity;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;setSprinting(Z)V", shift = Shift.AFTER)
   )
   public void attackHook(CallbackInfo var1) {
      EventManager.callEvent(new ListsCheckEvent());
   }

   @ModifyExpressionValue(
      method = "travel(Lnet/minecraft/util/math/Vec3d;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;")
   )
   public Vec3d travelHook(Vec3d var1) {
      SwimmingEvent var2 = new SwimmingEvent(var1);
      EventManager.callEvent(var2);
      return var2.getVector();
   }
}
