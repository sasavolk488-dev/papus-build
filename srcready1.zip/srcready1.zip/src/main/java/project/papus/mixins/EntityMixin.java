package project.papus.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import project.papus.api.event.EventManager;
import project.papus.common.QuickImports;
import project.papus.implement.events.player.BoundingBoxControlEvent;
import project.papus.implement.events.player.PlayerTravelEvent;

@Mixin(Entity.class)
public abstract class EntityMixin implements QuickImports {
   @Shadow
   private Box boundingBox;

   @Redirect(
      method = "updateVelocity(FLnet/minecraft/util/math/Vec3d;)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/entity/Entity;movementInputToVelocity(Lnet/minecraft/util/math/Vec3d;FF)Lnet/minecraft/util/math/Vec3d;"
      )
   )
   public Vec3d hookVelocity(Vec3d var1, float var2, float var3) {
      if ((Object)this == mc.player) {
         PlayerTravelEvent var4 = new PlayerTravelEvent(var1, var2, var3, Entity.movementInputToVelocity(var1, var2, var3));
         EventManager.callEvent(var4);
         return var4.getVelocity();
      } else {
         return Entity.movementInputToVelocity(var1, var2, var3);
      }
   }

   @Inject(method = "getBoundingBox()Lnet/minecraft/util/math/Box;", at = @At("HEAD"), cancellable = true)
   public final void getBoundingBox(CallbackInfoReturnable<Box> var1) {
      BoundingBoxControlEvent var2 = new BoundingBoxControlEvent(this.boundingBox, (Entity)(Object)this);
      EventManager.callEvent(var2);
      var1.setReturnValue(var2.getBox());
   }

   @ModifyExpressionValue(
      method = "move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isControlledByPlayer()Z")
   )
   public boolean isControlledByPlayerHook(boolean var1) {
      return (Object)this == mc.player ? false : var1;
   }
}
