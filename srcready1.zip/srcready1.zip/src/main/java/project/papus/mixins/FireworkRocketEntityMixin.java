package project.papus.mixins;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import project.papus.api.event.EventManager;
import project.papus.common.QuickImports;
import project.papus.common.util.rotation.RotationController;
import project.papus.implement.events.player.FovMultiplierEvent;

@Mixin(FireworkRocketEntity.class)
public class FireworkRocketEntityMixin implements QuickImports {
   @Shadow
   @Nullable
   private LivingEntity shooter;

   @WrapOperation(
      method = "tick()V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;")
   )
   public Vec3d getRotationVectorHook(LivingEntity var1, Operation<Vec3d> var2) {
      return this.shooter == mc.player ? RotationController.INSTANCE.getMoveAngle().toVector() : (Vec3d)var2.call(new Object[]{var1});
   }

   @WrapOperation(
      method = "tick()V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getVelocity()Lnet/minecraft/util/math/Vec3d;", ordinal = 0)
   )
   public Vec3d getVelocityHook(LivingEntity var1, Operation<Vec3d> var2) {
      if (this.shooter == mc.player) {
         FovMultiplierEvent var3 = new FovMultiplierEvent((Vec3d)var2.call(new Object[]{var1}));
         EventManager.callEvent(var3);
         return var3.getVelocity();
      } else {
         return (Vec3d)var2.call(new Object[]{var1});
      }
   }
}
