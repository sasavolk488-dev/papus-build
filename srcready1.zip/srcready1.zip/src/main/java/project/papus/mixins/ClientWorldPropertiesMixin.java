package project.papus.mixins;

import net.minecraft.client.world.ClientWorld.Properties;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.common.QuickImports;
import project.papus.implement.features.modules.render.TimeChanger;

@Mixin(Properties.class)
public class ClientWorldPropertiesMixin implements QuickImports {
   @Shadow
   private long timeOfDay;

   @Inject(method = "setTimeOfDay(J)V", at = @At("HEAD"), cancellable = true)
   public void setTimeOfDayHook(long var1, CallbackInfo var3) {
      TimeChanger var4 = TimeChanger.getInstance();
      if (var4 != null && var4.isState()) {
         String var5 = var4.timeSetting.getSelected();

         long var6 = switch (var5) {
            case "\u0414\u0435\u043d\u044c" -> 6000L;
            case "\u041d\u043e\u0447\u044c" -> 18000L;
            case "\u0412\u0435\u0447\u0435\u0440" -> 13000L;
            case "\u0420\u0430\u0441\u0441\u0432\u0435\u0442" -> 23000L;
            case "\u0417\u0430\u043a\u0430\u0442" -> 12000L;
            default -> 6000L;
         };
         this.timeOfDay = var6;
         var3.cancel();
      }
   }
}
