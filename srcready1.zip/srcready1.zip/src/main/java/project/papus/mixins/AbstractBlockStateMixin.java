package project.papus.mixins;

import net.minecraft.block.Block;
import net.minecraft.block.AbstractBlock.AbstractBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.common.QuickImports;
import project.papus.implement.events.player.PlaceObsidianEvent;

@Mixin(AbstractBlockState.class)
public abstract class AbstractBlockStateMixin implements QuickImports {
   @Shadow
   public abstract Block getBlock();

   @Inject(
      method = "onEntityCollision(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/Entity;)V",
      at = @At("HEAD"),
      cancellable = true
   )
   public void onEntityCollision(World var1, BlockPos var2, Entity var3, CallbackInfo var4) {
      if (var3 == mc.player) {
         PlaceObsidianEvent var5 = new PlaceObsidianEvent(this.getBlock());
         EventManager.callEvent(var5);
         if (var5.isCancelled()) {
            var4.cancel();
         }
      }
   }
}
