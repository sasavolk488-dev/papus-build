package project.papus.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import project.papus.api.event.EventManager;
import project.papus.common.util.entity.PlayerInventoryComponent;
import project.papus.common.util.rotation.Angle;
import project.papus.common.util.rotation.RotationController;
import project.papus.common.util.rotation.RotationPlan;
import project.papus.implement.events.player.KeyboardInputEvent;

@Mixin(KeyboardInput.class)
public class KeyboardInputMixin extends InputMixin {
   @ModifyExpressionValue(method = "tick()V", at = @At(value = "NEW", target = "(ZZZZZZZ)Lnet/minecraft/util/PlayerInput;"))
   private PlayerInput tickHook(PlayerInput var1) {
      KeyboardInputEvent var2 = new KeyboardInputEvent(var1);
      EventManager.callEvent(var2);
      PlayerInventoryComponent.onKeyboardInput(var2);
      return this.transformInput(var2.getPlayerInput());
   }

   @Unique
   private PlayerInput transformInput(PlayerInput var1) {
      RotationController var2 = RotationController.INSTANCE;
      Angle var3 = var2.getPrevServerAngle();
      RotationPlan var4 = var2.getCurrentRotationPlan();
      if (mc.player != null && var3 != null && var4 != null && var4.isMoveCorrection() && var4.isFreeCorrection()) {
         float var5 = mc.player.getYaw() - var3.getYaw();
         float var6 = KeyboardInput.getMovementMultiplier(var1.forward(), var1.backward());
         float var7 = KeyboardInput.getMovementMultiplier(var1.left(), var1.right());
         float var8 = var7 * MathHelper.cos(var5 * (float) (Math.PI / 180.0)) - var6 * MathHelper.sin(var5 * (float) (Math.PI / 180.0));
         float var9 = var6 * MathHelper.cos(var5 * (float) (Math.PI / 180.0)) + var7 * MathHelper.sin(var5 * (float) (Math.PI / 180.0));
         int var10 = Math.round(var8);
         int var11 = Math.round(var9);
         return new PlayerInput(var11 > 0.0F, var11 < 0.0F, var10 > 0.0F, var10 < 0.0F, var1.jump(), var1.sneak(), var1.sprint());
      } else {
         return var1;
      }
   }
}
