package project.papus.mixins;

import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil.Type;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.implement.events.keyboard.KeyEvent;
import project.papus.implement.screens.menu.MenuScreen;

@Mixin(Keyboard.class)
public class KeyboardMixin {
   @Final
   @Shadow
   private MinecraftClient client;

   @Inject(method = "onKey(JIIII)V", at = @At("HEAD"))
   private void onKey(long var1, int var3, int var4, int var5, int var6, CallbackInfo var7) {
      if (var3 != -1 && var1 == this.client.getWindow().getHandle()) {
         if (var5 == 0 && var3 == 344 && this.client.currentScreen == null) {
            MenuScreen.getInstance().openGui();
         }

         EventManager.callEvent(new KeyEvent(this.client.currentScreen, Type.KEYSYM, var3, var5));
      }
   }
}
