package project.papus.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import project.papus.api.event.EventManager;
import project.papus.common.util.entity.PlayerHealthUtil;
import project.papus.common.util.render.Render3DUtil;
import project.papus.implement.events.render.AspectRatioEvent;
import project.papus.implement.events.render.FovEvent;
import project.papus.implement.events.render.WorldRenderEvent;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
   @Final
   @Shadow
   private MinecraftClient client;
   @Shadow
   private float zoom;
   @Shadow
   private float zoomX;
   @Shadow
   private float zoomY;

   @Shadow
   public abstract float getFarPlaneDistance();

   @Inject(
      method = "updateCrosshairTarget(F)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/GameRenderer;findCrosshairTarget(Lnet/minecraft/entity/Entity;DDF)Lnet/minecraft/util/hit/HitResult;"
      ),
      cancellable = true
   )
   private void onUpdateTargetedEntity(float var1, CallbackInfo var2) {
      if (!PlayerHealthUtil.nullCheck()) {
      }
   }

   @Redirect(
      method = "findCrosshairTarget(Lnet/minecraft/entity/Entity;DDF)Lnet/minecraft/util/hit/HitResult;",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;raycast(DFZ)Lnet/minecraft/util/hit/HitResult;")
   )
   private HitResult hookRaycast(Entity var1, double var2, float var4, boolean var5) {
      return var1.raycast(var2, var4, var5);
   }

   @Redirect(
      method = "findCrosshairTarget(Lnet/minecraft/entity/Entity;DDF)Lnet/minecraft/util/hit/HitResult;",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getRotationVec(F)Lnet/minecraft/util/math/Vec3d;")
   )
   private Vec3d hookRotationVector(Entity var1, float var2) {
      return var1.getRotationVec(var2);
   }

   @Inject(method = "getBasicProjectionMatrix(F)Lorg/joml/Matrix4f;", at = @At("TAIL"), cancellable = true)
   public void getBasicProjectionMatrixHook(float var1, CallbackInfoReturnable<Matrix4f> var2) {
      AspectRatioEvent var3 = new AspectRatioEvent();
      EventManager.callEvent(var3);
      if (var3.isCancelled()) {
         Matrix4f var4 = new Matrix4f();
         if (this.zoom != 1.0F) {
            var4.translate(this.zoomX, -this.zoomY, 0.0F);
            var4.scale(this.zoom, this.zoom, 1.0F);
         }

         var4.perspective(var1 * (float) (Math.PI / 180.0), var3.getRatio(), 0.05F, this.getFarPlaneDistance());
         var2.setReturnValue(var4);
      }
   }

   @ModifyExpressionValue(
      method = "getFov(Lnet/minecraft/client/render/Camera;FZ)F",
      at = @At(value = "INVOKE", target = "Ljava/lang/Integer;intValue()I", remap = false)
   )
   private int hookGetFov(int var1) {
      FovEvent var2 = new FovEvent();
      EventManager.callEvent(var2);
      return var2.isCancelled() ? var2.getFov() : var1;
   }

   @Inject(
      method = "renderWorld(Lnet/minecraft/client/render/RenderTickCounter;)V",
      at = @At(value = "FIELD", target = "Lnet/minecraft/client/render/GameRenderer;renderHand:Z", opcode = 180, ordinal = 0)
   )
   public void hookWorldRender(RenderTickCounter var1, CallbackInfo var2, @Local(ordinal = 2) Matrix4f var3) {
      if (this.client.world != null && this.client.getEntityRenderDispatcher().camera != null) {
         Matrix4f var4 = new Matrix4f(var3);
         MatrixStack var5 = new MatrixStack();
         var5.multiplyPositionMatrix(var4);
         var5.translate(this.client.getEntityRenderDispatcher().camera.getPos().negate());
         Render3DUtil.setLastProjMat(RenderSystem.getProjectionMatrix());
         Render3DUtil.setLastModMat(var5.peek());
         WorldRenderEvent var6 = new WorldRenderEvent(var5, var1.getTickDelta(false));
         EventManager.callEvent(var6);
         Render3DUtil.onWorldRender(var6);
      }
   }

   @Inject(method = "renderWorld(Lnet/minecraft/client/render/RenderTickCounter;)V", at = @At("RETURN"))
   public void hookWorldRenderEnd(RenderTickCounter var1, CallbackInfo var2) {
      Render3DUtil.onWorldRenderEnd();
   }
}
