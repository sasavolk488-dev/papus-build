package project.papus.mixins;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.implement.events.item.HandAnimationEvent;
import project.papus.implement.events.item.HandOffsetEvent;
import project.papus.implement.events.render.ItemRendererEvent;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
   @Inject(
      method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;push()V", shift = Shift.AFTER)
   )
   private void renderFirstPersonItemHook(
      AbstractClientPlayerEntity var1,
      float var2,
      float var3,
      Hand var4,
      float var5,
      ItemStack var6,
      float var7,
      MatrixStack var8,
      VertexConsumerProvider var9,
      int var10,
      CallbackInfo var11
   ) {
      HandOffsetEvent var12 = new HandOffsetEvent(var8, var6, var4);
      EventManager.callEvent(var12);
   }

   @WrapOperation(
      method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"
      )
   )
   private void itemRenderHook(
      HeldItemRenderer var1,
      AbstractClientPlayerEntity var2,
      float var3,
      float var4,
      Hand var5,
      float var6,
      ItemStack var7,
      float var8,
      MatrixStack var9,
      VertexConsumerProvider var10,
      int var11,
      Operation<Void> var12
   ) {
      ItemRendererEvent var13 = new ItemRendererEvent(var2, var7, var5);
      EventManager.callEvent(var13);
      var12.call(new Object[]{var1, var13.getPlayer(), var3, var4, var13.getHand(), var6, var13.getStack(), var8, var9, var10, var11});
   }

   @WrapOperation(
      method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/item/HeldItemRenderer;swingArm(FFLnet/minecraft/client/util/math/MatrixStack;ILnet/minecraft/util/Arm;)V",
         ordinal = 2
      )
   )
   private void handAnimationHook(
      HeldItemRenderer var1,
      float var2,
      float var3,
      MatrixStack var4,
      int var5,
      Arm var6,
      Operation<Void> var7,
      @Local(ordinal = 0, argsOnly = true) AbstractClientPlayerEntity var8,
      @Local(ordinal = 0, argsOnly = true) Hand var9
   ) {
      HandAnimationEvent var10 = new HandAnimationEvent(var4, var9, var2);
      EventManager.callEvent(var10);
      if (!var10.isCancelled()) {
         var7.call(new Object[]{var1, var2, var3, var4, var5, var6});
      }
   }
}
