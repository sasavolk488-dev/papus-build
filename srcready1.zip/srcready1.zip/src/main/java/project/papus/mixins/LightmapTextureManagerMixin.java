package project.papus.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import project.papus.implement.features.modules.render.FullBright;

@Mixin(LightmapTextureManager.class)
public class LightmapTextureManagerMixin {
   @ModifyExpressionValue(method = "update(F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;"))
   private Object injectXRayFullBright(Object var1) {
      FullBright var2 = FullBright.getInstance();
      return var2 != null && var2.isState() ? Math.max((Double)var1, 10.0) : var1;
   }
}
