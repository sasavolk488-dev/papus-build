package project.papus.mixins;

import java.util.ConcurrentModificationException;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.common.QuickImports;
import project.papus.common.util.math.MathUtil;
import project.papus.common.util.render.Render2DUtil;
import project.papus.core.Main;
import project.papus.implement.events.render.DrawEvent;
import project.papus.implement.features.modules.render.CrossHair;
import project.papus.implement.features.modules.render.Hud;
import project.papus.implement.features.modules.render.NoRender;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin implements QuickImports {
   @Final
   @Shadow
   private MinecraftClient client;

   @Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", at = @At("RETURN"))
   public void onRender(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      blur.setup();
      DrawEvent var4 = new DrawEvent(var1, drawEngine, var2.getTickDelta(false));
      EventManager.callEvent(var4);
      Render2DUtil.onRender(var1);
      if (!this.client.options.hudHidden) {
         Main.getInstance().getDraggableRepository().draggable().forEach(var1x -> {
            if (var1x.canDraw(var1x)) {
               var1x.startAnimation();
            } else {
               var1x.stopAnimation();
            }

            float var2x = var1x.getScaleAnimation().getOutput().floatValue();
            if (!var1x.isCloseAnimationFinished()) {
               var1x.validPosition();

               try {
                  MathUtil.setAlpha(var2x, () -> var1x.drawDraggable(var1));
               } catch (ConcurrentModificationException var4x) {
               }
            }
         });
      }
   }

   @Inject(
      method = "renderCrosshair(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V",
      at = @At("HEAD"),
      cancellable = true,
      require = 0
   )
   public void renderCrosshairHook(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      CrossHair var4 = CrossHair.getInstance();
      if (var4.isState()) {
         var4.renderCrossHair();
         var3.cancel();
      }
   }

   @Inject(
      method = "renderStatusEffectOverlay(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V",
      at = @At("HEAD"),
      cancellable = true
   )
   public void renderStatusEffectOverlayHook(DrawContext var1, RenderTickCounter var2, CallbackInfo var3) {
      NoRender var4 = NoRender.getInstance();
      if (var4 != null && var4.isState()) {
         var3.cancel();
      } else {
         Hud var5 = Hud.getInstance();
         if (var5 != null && var5.isState() && var5.elementsSetting.isSelected("Potions")) {
            var3.cancel();
         }
      }
   }
}
