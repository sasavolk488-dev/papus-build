package project.papus.mixins;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.implement.events.block.BlockEntityProgressEvent;

@Mixin(BlockEntity.class)
public class BlockEntityMixin {
   @Inject(
      method = "<init>(Lnet/minecraft/block/entity/BlockEntityType;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;)V",
      at = @At("RETURN")
   )
   public void initHook(BlockEntityType<?> var1, BlockPos var2, BlockState var3, CallbackInfo var4) {
      BlockEntity var5 = (BlockEntity)(Object)this;
      if (var5 != null) {
         EventManager.callEvent(new BlockEntityProgressEvent(var5, BlockEntityProgressEvent.Type.ADD));
      }
   }

   @Inject(method = "markRemoved()V", at = @At("HEAD"))
   private void markRemovedHook(CallbackInfo var1) {
      BlockEntity var2 = (BlockEntity)(Object)this;
      if (var2 != null) {
         EventManager.callEvent(new BlockEntityProgressEvent(var2, BlockEntityProgressEvent.Type.REMOVE));
      }
   }
}
