package project.papus.mixins;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.common.QuickImports;
import project.papus.implement.events.block.BlockUpdateEvent;

@Mixin(World.class)
public abstract class WorldMixin implements QuickImports {
   @Inject(method = "onBlockChanged(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;Lnet/minecraft/block/BlockState;)V", at = @At("RETURN"))
   private void onBlockChangedHook(BlockPos var1, BlockState var2, BlockState var3, CallbackInfo var4) {
      if (mc.world == (Object)this) {
         EventManager.callEvent(new BlockUpdateEvent(var3, var1.toImmutable(), BlockUpdateEvent.Type.UPDATE));
      }
   }
}
