package project.papus.mixins;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.DeathScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.implement.events.player.DeathScreenEvent;

@Mixin(DeathScreen.class)
public class DeathScreenMixin {
   @Shadow
   private int ticksSinceDeath;

   @Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("HEAD"))
   public void render(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      EventManager.callEvent(new DeathScreenEvent(this.ticksSinceDeath));
   }
}
