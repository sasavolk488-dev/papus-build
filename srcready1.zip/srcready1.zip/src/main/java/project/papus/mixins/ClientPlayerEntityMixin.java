package project.papus.mixins;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import project.papus.api.event.EventManager;
import project.papus.common.util.entity.PlayerInventoryComponent;
import project.papus.implement.events.block.PushEvent;
import project.papus.implement.events.container.CloseScreenEvent;
import project.papus.implement.events.item.UsingItemEvent;
import project.papus.implement.events.player.MotionEvent;
import project.papus.implement.events.player.MoveEvent;
import project.papus.implement.events.player.PostMotionEvent;
import project.papus.implement.events.player.PostTickEvent;
import project.papus.implement.events.player.TickEvent;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin extends AbstractClientPlayerEntity {
   @Final
   @Shadow
   protected MinecraftClient client;
   @Shadow
   public Input input;

   @Shadow
   public abstract float getPitch(float var1);

   @Shadow
   public abstract float getYaw(float var1);

   @Shadow
   protected abstract void autoJump(float var1, float var2);

   public ClientPlayerEntityMixin(ClientWorld var1, GameProfile var2) {
      super(var1, var2);
   }

   @Inject(method = "tick()V", at = @At("HEAD"))
   public void tick(CallbackInfo var1) {
      if (this.client.player != null && this.client.world != null) {
         EventManager.callEvent(new TickEvent());
      }
   }

   @Inject(method = "tick()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;tick()V", shift = Shift.AFTER))
   public void postTick(CallbackInfo var1) {
      if (this.client.player != null && this.client.world != null) {
         EventManager.callEvent(new PostTickEvent());
      }
   }

   @ModifyExpressionValue(
      method = {"sendMovementPackets", "tick"},
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F")
   )
   private float hookSilentRotationYaw(float var1) {
      return var1;
   }

   @ModifyExpressionValue(
      method = {"sendMovementPackets", "tick"},
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getPitch()F")
   )
   private float hookSilentRotationPitch(float var1) {
      return var1;
   }

   @Inject(method = "closeHandledScreen()V", at = @At("HEAD"), cancellable = true)
   private void closeHandledScreenHook(CallbackInfo var1) {
      CloseScreenEvent var2 = new CloseScreenEvent(this.client.currentScreen);
      EventManager.callEvent(var2);
      if (var2.isCancelled()) {
         var1.cancel();
      }
   }

   @ModifyExpressionValue(method = "tickMovement()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"))
   private boolean usingItemHook(boolean var1) {
      if (var1) {
         UsingItemEvent var2 = new UsingItemEvent((byte)1);
         EventManager.callEvent(var2);
         if (var2.isCancelled()) {
            return false;
         }
      }

      return var1;
   }

   @WrapOperation(method = "canSprint()Z", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/HungerManager;getFoodLevel()I"))
   private int canSprintHook(HungerManager var1, Operation<Integer> var2) {
      return (Integer)var2.call(new Object[]{var1});
   }

   @Inject(method = "sendMovementPackets()V", at = @At("HEAD"))
   private void preMotion(CallbackInfo var1) {
      MotionEvent var2 = new MotionEvent(this.getX(), this.getY(), this.getZ(), this.getYaw(1.0F), this.getPitch(1.0F), this.isOnGround());
      EventManager.callEvent(var2);
   }

   @Inject(
      method = "move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;move(Lnet/minecraft/entity/MovementType;Lnet/minecraft/util/math/Vec3d;)V"
      ),
      cancellable = true
   )
   public void onMoveHook(MovementType var1, Vec3d var2, CallbackInfo var3) {
      MoveEvent var4 = new MoveEvent(var2);
      EventManager.callEvent(var4);
      double var5 = this.getX();
      double var7 = this.getZ();
      super.move(var1, var4.getMovement());
      this.autoJump((float)(this.getX() - var5), (float)(this.getZ() - var7));
      var3.cancel();
   }

   @Inject(method = "sendMovementPackets()V", at = @At("RETURN"))
   private void postMotion(CallbackInfo var1) {
      PostMotionEvent var2 = new PostMotionEvent();
      EventManager.callEvent(var2);
      PlayerInventoryComponent.postMotion();
   }

   @Inject(method = "pushOutOfBlocks(DD)V", at = @At("HEAD"), cancellable = true)
   public void pushOutOfBlocks(double var1, double var3, CallbackInfo var5) {
      PushEvent var6 = new PushEvent(PushEvent.Type.BLOCK);
      EventManager.callEvent(var6);
      if (var6.isCancelled()) {
         var5.cancel();
      }
   }
}
