package project.papus.mixins;

import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import project.papus.common.QuickImports;

@Mixin(Input.class)
public class InputMixin implements QuickImports {
}
