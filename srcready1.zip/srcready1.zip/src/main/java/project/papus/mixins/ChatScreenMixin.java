package project.papus.mixins;

import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import project.papus.api.feature.draggable.AbstractDraggable;
import project.papus.common.QuickImports;
import project.papus.core.Main;
import project.papus.implement.features.modules.misc.Panic;

@Mixin(ChatScreen.class)
public class ChatScreenMixin extends Screen implements QuickImports {
   protected ChatScreenMixin() {
      super(Text.empty());
   }

   @Unique
   private List<AbstractDraggable> getDraggables() {
      return Main.getInstance().getDraggableRepository().draggable();
   }

   @Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("HEAD"))
   private void onRender(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      this.getDraggables()
         .stream()
         .filter(var0 -> var0.canDraw(var0) && var0.isDragging())
         .reduce((var0, var1x) -> var1x)
         .ifPresent(var5x -> this.getDraggables().forEach(var5xx -> {
            if (var5x == var5xx) {
               var5xx.render(var1, var2, var3, var4);
            }
         }));
   }

   @Inject(method = "mouseClicked(DDI)Z", at = @At("TAIL"))
   private void onMouseClicked(double var1, double var3, int var5, CallbackInfoReturnable<Boolean> var6) {
      this.getDraggables().forEach(var5x -> var5x.mouseClicked(var1, var3, var5));
   }

   public boolean mouseReleased(double var1, double var3, int var5) {
      this.getDraggables().forEach(var5x -> var5x.mouseReleased(var1, var3, var5));
      return super.mouseReleased(var1, var3, var5);
   }

   @Inject(method = "sendMessage(Ljava/lang/String;Z)V", at = @At("HEAD"), cancellable = true)
   private void onSendMessage(String var1, boolean var2, CallbackInfo var3) {
      if (var1 != null && !var1.isEmpty()) {
         if (Panic.handleChatMessage(var1)) {
            var3.cancel();
         }
      }
   }
}
