package project.papus.mixins;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public class TitleScreenBackgroundMixin {
   @Inject(method = "renderPanoramaBackground(Lnet/minecraft/client/gui/DrawContext;F)V", at = @At("HEAD"), cancellable = true)
   private void allBlackBackground(DrawContext var1, float var2, CallbackInfo var3) {
      MinecraftClient var4 = MinecraftClient.getInstance();
      int var5 = var4.getWindow().getScaledWidth();
      int var6 = var4.getWindow().getScaledHeight();
      var1.fill(0, 0, var5, var6, -16777216);
      var3.cancel();
   }
}
