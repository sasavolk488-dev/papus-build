package project.papus.mixins;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import project.papus.api.event.EventManager;
import project.papus.implement.events.chat.ChatEvent;
import project.papus.implement.screens.menu.MenuScreen;

@Mixin(Screen.class)
public class ScreenMixin {
   @Inject(
      at = @At(value = "INVOKE", target = "Lorg/slf4j/Logger;error(Ljava/lang/String;Ljava/lang/Object;)V", remap = false, ordinal = 1),
      method = "handleTextClick(Lnet/minecraft/text/Style;)Z",
      cancellable = true
   )
   public void handleCustomClickEvent(Style var1, CallbackInfoReturnable<Boolean> var2) {
      ClickEvent var3 = var1.getClickEvent();
      if (var3 != null) {
         EventManager.callEvent(new ChatEvent(var3.getValue()));
         var2.setReturnValue(true);
         var2.cancel();
      }
   }

   @Inject(method = "renderBackground(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("HEAD"), cancellable = true)
   private void allBlackOrMenuBackground(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      if ((Object)this instanceof MenuScreen) {
         var5.cancel();
      } else {
         MinecraftClient var6 = MinecraftClient.getInstance();
         if (var6.world == null) {
            int var7 = var6.getWindow().getScaledWidth();
            int var8 = var6.getWindow().getScaledHeight();
            var1.fill(0, 0, var7, var8, -16777216);
            var5.cancel();
         }
      }
   }
}
