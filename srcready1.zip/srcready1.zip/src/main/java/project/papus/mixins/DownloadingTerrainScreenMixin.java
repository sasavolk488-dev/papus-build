package project.papus.mixins;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.DownloadingTerrainScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DownloadingTerrainScreen.class)
public class DownloadingTerrainScreenMixin {
   @Inject(method = "renderBackground(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("HEAD"), cancellable = true)
   private void allBlackBackground(DrawContext var1, int var2, int var3, float var4, CallbackInfo var5) {
      MinecraftClient var6 = MinecraftClient.getInstance();
      int var7 = var6.getWindow().getScaledWidth();
      int var8 = var6.getWindow().getScaledHeight();
      var1.fill(0, 0, var7, var8, -16777216);
      var5.cancel();
   }
}
