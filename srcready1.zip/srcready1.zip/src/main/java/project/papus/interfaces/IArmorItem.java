package project.papus.interfaces;

import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentType;

public interface IArmorItem {
   ArmorMaterial getArmorMaterial();

   EquipmentType getArmorType();
}
