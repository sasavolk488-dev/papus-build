package project.papus.core.listener.impl;

import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import project.papus.api.event.EventHandler;
import project.papus.api.feature.draggable.AbstractDraggable;
import project.papus.api.feature.module.Module;
import project.papus.common.util.entity.PlayerInventoryComponent;
import project.papus.common.util.rotation.RotationController;
import project.papus.common.util.world.ServerUtil;
import project.papus.core.Main;
import project.papus.core.listener.Listener;
import project.papus.implement.events.item.UsingItemEvent;
import project.papus.implement.events.packet.PacketEvent;
import project.papus.implement.events.player.TickEvent;
import project.papus.implement.events.render.WorldLoadEvent;

public class EventListener implements Listener {
   public static boolean serverSprint;
   public static int selectedSlot;

   @EventHandler
   public void onWorldLoad(WorldLoadEvent var1) {
      for (Module var3 : Main.getInstance().getModuleRepository().modules()) {
         if (var3.isState()) {
            Main.getInstance().getEventManager().register(var3);
         }
      }
   }

   @EventHandler
   public void onTick(TickEvent var1) {
      ServerUtil.tick();
      RotationController.INSTANCE.update();
      PlayerInventoryComponent.tick();
      Main.getInstance().getDraggableRepository().draggable().forEach(AbstractDraggable::tick);
   }

   @EventHandler
   public void onPacket(PacketEvent var1) {
      switch (var1.getPacket()) {
         case ClientCommandC2SPacket var4:
            serverSprint = switch (var4.getMode()) {
               case START_SPRINTING -> true;
               case STOP_SPRINTING -> false;
               default -> serverSprint;
            };
            break;
         case UpdateSelectedSlotC2SPacket var5:
            selectedSlot = var5.getSelectedSlot();
            break;
         default:
      }

      ServerUtil.onPacket(var1);
      Main.getInstance().getDraggableRepository().draggable().forEach(var1x -> var1x.onPacket(var1));
   }

   @EventHandler
   public void onUsingItem(UsingItemEvent var1) {
   }
}
