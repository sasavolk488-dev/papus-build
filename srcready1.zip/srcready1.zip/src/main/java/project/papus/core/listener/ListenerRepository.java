package project.papus.core.listener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import project.papus.core.Main;
import project.papus.core.listener.impl.EventListener;

public class ListenerRepository {
   private final List<Listener> listeners = new ArrayList<>();

   public void setup() {
      this.register(new EventListener());
   }

   public void register(Listener... var1) {
      this.listeners.addAll(List.of(var1));
      Arrays.stream(var1).forEach(var0 -> Main.getInstance().getEventManager().register(var0));
   }

   public List<Listener> getListeners() {
      return this.listeners;
   }
}
