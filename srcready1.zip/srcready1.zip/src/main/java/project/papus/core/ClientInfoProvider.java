package project.papus.core;

import java.io.File;

public interface ClientInfoProvider {
   String clientName();

   String userName();

   String role();

   String getFullInfo();

   File clientDir();

   File filesDir();

   File configsDir();
}
