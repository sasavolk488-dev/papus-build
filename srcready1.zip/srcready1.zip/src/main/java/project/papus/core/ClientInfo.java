package project.papus.core;

import java.io.File;
import project.papus.common.util.other.StringUtil;

public record ClientInfo(String clientName, String userName, String role, File clientDir, File filesDir, File configsDir) implements ClientInfoProvider {
   @Override
   public String getFullInfo() {
      return String.format("Welcome! Client: %s Version: %s Branch: %s", this.clientName, this.userName, StringUtil.getUserRole());
   }
}
