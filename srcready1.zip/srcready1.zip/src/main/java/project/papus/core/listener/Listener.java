package project.papus.core.listener;

import project.papus.common.QuickLogger;

public interface Listener extends QuickLogger {
}
