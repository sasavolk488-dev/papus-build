package project.papus.core;

import java.io.File;
import net.fabricmc.api.ModInitializer;
import net.minecraft.client.MinecraftClient;
import project.papus.api.event.EventManager;
import project.papus.api.feature.draggable.DraggableRepository;
import project.papus.api.feature.module.ModuleProvider;
import project.papus.api.feature.module.ModuleRepository;
import project.papus.api.feature.module.ModuleSwitcher;
import project.papus.api.file.DirectoryCreator;
import project.papus.api.file.FileController;
import project.papus.api.file.FileRepository;
import project.papus.api.file.exception.FileProcessingException;
import project.papus.api.system.sound.SoundManager;
import project.papus.common.util.logger.LoggerUtil;
import project.papus.common.util.render.ScissorManager;
import project.papus.core.listener.ListenerRepository;

public class Main implements ModInitializer {
   static Main instance;
   private EventManager eventManager = new EventManager();
   private ModuleRepository moduleRepository;
   private ModuleSwitcher moduleSwitcher;
   private ModuleProvider moduleProvider;
   private DraggableRepository draggableRepository;
   private FileRepository fileRepository;
   private FileController fileController;
   private ScissorManager scissorManager = new ScissorManager();
   private ClientInfoProvider clientInfoProvider;
   private ListenerRepository listenerRepository;
   private boolean initialized;

   public void onInitialize() {
      instance = this;
      this.initClientInfoProvider();
      this.initModules();
      this.initDraggable();
      this.initFileManager();
      this.initListeners();
      SoundManager.init();
      this.initialized = true;
   }

   private void initListeners() {
      this.listenerRepository = new ListenerRepository();
      this.listenerRepository.setup();
   }

   private void initDraggable() {
      this.draggableRepository = new DraggableRepository();
      this.draggableRepository.setup();
   }

   private void initModules() {
      this.moduleRepository = new ModuleRepository();
      this.moduleRepository.setup();
      this.moduleProvider = new ModuleProvider(this.moduleRepository.modules());
      this.moduleSwitcher = new ModuleSwitcher(this.moduleRepository.modules(), this.eventManager);
   }

   private void initClientInfoProvider() {
      File var1 = new File(MinecraftClient.getInstance().runDirectory, "\\papus\\");
      File var2 = new File(var1, "\\files\\");
      File var3 = new File(var2, "\\config\\");
      this.clientInfoProvider = new ClientInfo("PAPUS", "FABOS", "ADMIN", var1, var2, var3);
   }

   private void initFileManager() {
      DirectoryCreator var1 = new DirectoryCreator();
      var1.createDirectories(this.clientInfoProvider.clientDir(), this.clientInfoProvider.filesDir(), this.clientInfoProvider.configsDir());
      this.fileRepository = new FileRepository();
      this.fileRepository.setup(this);
      this.fileController = new FileController(this.fileRepository.getClientFiles(), this.clientInfoProvider.filesDir(), this.clientInfoProvider.configsDir());

      try {
         this.fileController.loadFiles();
      } catch (FileProcessingException var3) {
         LoggerUtil.error("Error occurred while loading files: " + var3.getMessage() + " " + var3.getCause());
      }
   }

   public EventManager getEventManager() {
      return this.eventManager;
   }

   public ModuleRepository getModuleRepository() {
      return this.moduleRepository;
   }

   public ModuleSwitcher getModuleSwitcher() {
      return this.moduleSwitcher;
   }

   public ModuleProvider getModuleProvider() {
      return this.moduleProvider;
   }

   public DraggableRepository getDraggableRepository() {
      return this.draggableRepository;
   }

   public FileRepository getFileRepository() {
      return this.fileRepository;
   }

   public FileController getFileController() {
      return this.fileController;
   }

   public ScissorManager getScissorManager() {
      return this.scissorManager;
   }

   public ClientInfoProvider getClientInfoProvider() {
      return this.clientInfoProvider;
   }

   public ListenerRepository getListenerRepository() {
      return this.listenerRepository;
   }

   public boolean isInitialized() {
      return this.initialized;
   }

   public void setEventManager(EventManager var1) {
      this.eventManager = var1;
   }

   public void setModuleRepository(ModuleRepository var1) {
      this.moduleRepository = var1;
   }

   public void setModuleSwitcher(ModuleSwitcher var1) {
      this.moduleSwitcher = var1;
   }

   public void setModuleProvider(ModuleProvider var1) {
      this.moduleProvider = var1;
   }

   public void setDraggableRepository(DraggableRepository var1) {
      this.draggableRepository = var1;
   }

   public void setFileRepository(FileRepository var1) {
      this.fileRepository = var1;
   }

   public void setFileController(FileController var1) {
      this.fileController = var1;
   }

   public void setScissorManager(ScissorManager var1) {
      this.scissorManager = var1;
   }

   public void setClientInfoProvider(ClientInfoProvider var1) {
      this.clientInfoProvider = var1;
   }

   public void setListenerRepository(ListenerRepository var1) {
      this.listenerRepository = var1;
   }

   public void setInitialized(boolean var1) {
      this.initialized = var1;
   }

   public static Main getInstance() {
      return instance;
   }
}
