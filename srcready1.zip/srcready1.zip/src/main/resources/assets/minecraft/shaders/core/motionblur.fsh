#version 150

uniform sampler2D CurrentFrame;
uniform sampler2D PreviousFrame;
uniform float BlurStrength;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 currentColor = texture(CurrentFrame, texCoord);
    vec4 previousColor = texture(PreviousFrame, texCoord);
    
    // Смешиваем текущий и предыдущий кадр
    fragColor = mix(currentColor, previousColor, BlurStrength);
}
